// XIF coprocessor wrapper -- KALMAN-FILTER variant.
//
// Same external port list as before (so cv32e40x_tb_wrapper / mm_ram are unchanged), but
// internally it flattens the XIF interface and instantiates kf_copro -- the single-opcode
// linear Kalman-filter coprocessor (altimeter denoising). This is a SOFT coprocessor (not
// the eFPGA), so the eFPGA reconfiguration OBI master / config_busy are unused here and
// are tied off.

module xif_copro #(
  parameter int unsigned XLEN  = 32,
  parameter int unsigned INPUT_BUFFER_DEPTH = 1,
  parameter bit          FORWARDING = 1
) (
  // Clock and Reset
  input logic clk_i,
  input logic rst_ni,

  // eFPGA reconfiguration OBI master -- UNUSED for the soft Kalman coprocessor (tied off)
  output logic        cfgm_req_o,
  input  logic        cfgm_gnt_i,
  output logic [31:0] cfgm_addr_o,
  input  logic        cfgm_rvalid_i,
  input  logic [31:0] cfgm_rdata_i,
  output logic        config_busy_o,

  // eXtension interface
  cv32e40x_if_xif.coproc_compressed xif_compressed_if,
  cv32e40x_if_xif.coproc_issue      xif_issue_if,
  cv32e40x_if_xif.coproc_commit     xif_commit_if,
  cv32e40x_if_xif.coproc_mem        xif_mem_if,
  cv32e40x_if_xif.coproc_mem_result xif_mem_result_if,
  cv32e40x_if_xif.coproc_result     xif_result_if
);

  localparam int unsigned X_NUM_RS = 2;

  // GENERIC reconfigurable eFPGA coprocessor: the WHOLE coprocessor lives in the fabric.
  // Decodes 4 custom opcodes (0x0B=Kalman, 0x2B=AND, 0x5B=OR, 0x7B=XOR), OBI-streams that slot's
  // bitstream from RAM, configures eFPGA_top, and packs/unpacks the XIF through UIN_top/UOUT_top.
  xif_copro_efpga_kf #(
    .XLEN              (XLEN),
    .INPUT_BUFFER_DEPTH(INPUT_BUFFER_DEPTH),
    .FORWARDING        (FORWARDING),
    .BITS_BASE         (32'h0010_0000),   // slot s at BITS_BASE + s*BITS_STRIDE in system RAM
    .BITS_STRIDE       (32'h0001_0000),   // 64 KiB per slot (KF bitstream = 32664 B = 8166 words)
    .NWORDS            (8166)
  ) kf_copro_i (
    // Clock and Reset
    .clk_i (clk_i),
    .rst_ni(rst_ni),
    // OBI config master (streams the bitstream from RAM)
    .cfgm_req_o   (cfgm_req_o),
    .cfgm_gnt_i   (cfgm_gnt_i),
    .cfgm_addr_o  (cfgm_addr_o),
    .cfgm_rvalid_i(cfgm_rvalid_i),
    .cfgm_rdata_i (cfgm_rdata_i),
    .config_busy_o(config_busy_o),

    // ---- Compressed interface ----
    .compressed_valid_i      (xif_compressed_if.compressed_valid),
    .compressed_ready_o      (xif_compressed_if.compressed_ready),
    .compressed_resp_instr_o (xif_compressed_if.compressed_resp.instr),
    .compressed_resp_accept_o(xif_compressed_if.compressed_resp.accept),

    // ---- Issue interface ----
    .issue_valid_i         (xif_issue_if.issue_valid),
    .issue_ready_o         (xif_issue_if.issue_ready),
    .issue_req_instr_i     (xif_issue_if.issue_req.instr),
    .issue_req_mode_i      (xif_issue_if.issue_req.mode),
    .issue_req_id_i        (xif_issue_if.issue_req.id),
    .issue_req_rs_i        (xif_issue_if.issue_req.rs[X_NUM_RS-1:0]),
    .issue_req_rs_valid_i  (xif_issue_if.issue_req.rs_valid[X_NUM_RS-1:0]),
    .issue_resp_accept_o   (xif_issue_if.issue_resp.accept),
    .issue_resp_writeback_o(xif_issue_if.issue_resp.writeback),
    .issue_resp_dualwrite_o(xif_issue_if.issue_resp.dualwrite),
    .issue_resp_dualread_o (xif_issue_if.issue_resp.dualread),
    .issue_resp_loadstore_o(xif_issue_if.issue_resp.loadstore),
    .issue_resp_ecswrite_o (xif_issue_if.issue_resp.ecswrite),
    .issue_resp_exc_o      (xif_issue_if.issue_resp.exc),

    // ---- Commit interface ----
    .commit_valid_i(xif_commit_if.commit_valid),
    .commit_kill_i (xif_commit_if.commit.commit_kill),
    .commit_id_i   (xif_commit_if.commit.id),

    // ---- Memory request/response interface (unused by the KF) ----
    .mem_valid_o      (xif_mem_if.mem_valid),
    .mem_ready_i      (xif_mem_if.mem_ready),
    .mem_req_id_o     (xif_mem_if.mem_req.id),
    .mem_req_mode_o   (xif_mem_if.mem_req.mode),
    .mem_req_we_o     (xif_mem_if.mem_req.we),
    .mem_req_size_o   (xif_mem_if.mem_req.size),
    .mem_req_be_o     (xif_mem_if.mem_req.be),
    .mem_req_attr_o   (xif_mem_if.mem_req.attr),
    .mem_req_wdata_o  (xif_mem_if.mem_req.wdata),
    .mem_req_last_o   (xif_mem_if.mem_req.last),
    .mem_req_spec_o   (xif_mem_if.mem_req.spec),
    .mem_req_addr_o   (xif_mem_if.mem_req.addr),
    .mem_resp_exc_i   (xif_mem_if.mem_resp.exc),
    .mem_resp_exccode_i(xif_mem_if.mem_resp.exccode),
    .mem_resp_dbg_i   (xif_mem_if.mem_resp.dbg),

    // ---- Memory result interface (unused) ----
    .mem_result_valid_i(xif_mem_result_if.mem_result_valid),
    .mem_result_rdata_i(xif_mem_result_if.mem_result.rdata),
    .mem_result_err_i  (xif_mem_result_if.mem_result.err),
    .mem_result_dbg_i  (xif_mem_result_if.mem_result.dbg),

    // ---- Result interface ----
    .result_valid_o  (xif_result_if.result_valid),
    .result_ready_i  (xif_result_if.result_ready),
    .result_id_o     (xif_result_if.result.id),
    .result_data_o   (xif_result_if.result.data),
    .result_rd_o     (xif_result_if.result.rd),
    .result_we_o     (xif_result_if.result.we),
    .result_ecsdata_o(xif_result_if.result.ecsdata),
    .result_ecswe_o  (xif_result_if.result.ecswe),
    .result_exc_o    (xif_result_if.result.exc),
    .result_exccode_o(xif_result_if.result.exccode),
    .result_err_o    (xif_result_if.result.err),
    .result_dbg_o    (xif_result_if.result.dbg)
  );

endmodule  // xif_copro

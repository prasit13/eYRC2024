// =====================================================================================
// xif_copro_efpga  --  runtime-reconfigurable, multi-operation eFPGA coprocessor.
//
// The SINGLE FABulous fabric (eFPGA_top) is reconfigured at run time depending on which
// custom opcode the CPU offloads over the eXtension interface (XIF):
//
//     custom-0 (opcode 0x0B)  ->  slot 0   (e.g. NOT)
//     custom-1 (opcode 0x2B)  ->  slot 1   (e.g. BITREV)
//     custom-2 (opcode 0x5B)  ->  slot 2   (e.g. BSWAP)
//     custom-3 (opcode 0x7B)  ->  slot 3   (e.g. XOR)
//
// Each slot's bitstream lives in the SoC's system memory.  When a custom instruction is
// offloaded whose bitstream is NOT the one currently in the fabric, the reconfig
// controller:
//   1) stalls the XIF issue handshake (issue_ready=0) and holds the mapped coproc in reset,
//   2) bursts the slot's bitstream out of memory through a dedicated OBI read master
//      (cfgm_*), streaming each 32-bit word into the fabric's SelfWrite config port,
//   3) lets the freshly-configured fabric settle, then releases it and completes the XIF
//      handshake so the fabric computes the result.
//
// If the requested op is ALREADY loaded, no reconfiguration happens -- the instruction
// runs immediately (so a run of the same opcode reconfigures only once).
//
// Nothing here touches the CV32E40X core: this is a drop-in replacement for the previous
// xif_copro_efpga, with the SPI config ports replaced by an OBI read master.  It is plain
// synthesizable Verilog (no behavioural memories); the bitstreams come from real memory.
// =====================================================================================
module xif_copro_efpga_kf #(
  parameter XLEN = 32, parameter INPUT_BUFFER_DEPTH = 1, parameter FORWARDING = 1,
  // bitstream geometry in system memory: slot s starts at BITS_BASE + s*BITS_STRIDE
  parameter [31:0] BITS_BASE   = 32'h0010_0000,
  parameter [31:0] BITS_STRIDE = 32'h0001_0000,   // 64 KiB per slot (KF bitstream is 8166 words)
  parameter integer NWORDS     = 8166,
  parameter integer RESET_CYCLES = 4,             // fabric config-FSM reset pulse width
  parameter integer HOLD_CYCLES = 16
) (
  input  wire        clk_i,
  input  wire        rst_ni,

  // ---- dedicated OBI read master: streams bitstreams out of system memory ----
  output wire        cfgm_req_o,     // request valid
  input  wire        cfgm_gnt_i,     // address phase accepted
  output wire [31:0] cfgm_addr_o,    // byte address
  input  wire        cfgm_rvalid_i,  // read data valid
  input  wire [31:0] cfgm_rdata_i,   // read data
  output wire        config_busy_o,  // high while (re)configuring the fabric

  // ---- XIF (eXtension interface), flattened ----
  input  wire        compressed_valid_i,
  input  wire        issue_valid_i,
  input  wire [31:0] issue_req_instr_i,
  input  wire  [1:0] issue_req_mode_i,
  input  wire  [3:0] issue_req_id_i,
  input  wire [63:0] issue_req_rs_i,
  input  wire  [1:0] issue_req_rs_valid_i,
  input  wire        commit_valid_i,
  input  wire        commit_kill_i,
  input  wire  [3:0] commit_id_i,
  input  wire        mem_ready_i,
  input  wire        mem_resp_exc_i,
  input  wire  [5:0] mem_resp_exccode_i,
  input  wire        mem_resp_dbg_i,
  input  wire        mem_result_valid_i,
  input  wire [31:0] mem_result_rdata_i,
  input  wire        mem_result_err_i,
  input  wire        mem_result_dbg_i,
  input  wire        result_ready_i,
  output wire        compressed_ready_o,
  output wire [31:0] compressed_resp_instr_o,
  output wire        compressed_resp_accept_o,
  output wire        issue_ready_o,
  output wire        issue_resp_accept_o,
  output wire        issue_resp_writeback_o,
  output wire        issue_resp_dualwrite_o,
  output wire  [2:0] issue_resp_dualread_o,
  output wire        issue_resp_loadstore_o,
  output wire        issue_resp_ecswrite_o,
  output wire        issue_resp_exc_o,
  output wire        mem_valid_o,
  output wire  [3:0] mem_req_id_o,
  output wire  [1:0] mem_req_mode_o,
  output wire        mem_req_we_o,
  output wire  [2:0] mem_req_size_o,
  output wire  [3:0] mem_req_be_o,
  output wire  [1:0] mem_req_attr_o,
  output wire [31:0] mem_req_wdata_o,
  output wire        mem_req_last_o,
  output wire        mem_req_spec_o,
  output wire [31:0] mem_req_addr_o,
  output wire        result_valid_o,
  output wire  [3:0] result_id_o,
  output wire [31:0] result_data_o,
  output wire  [4:0] result_rd_o,
  output wire        result_we_o,
  output wire  [5:0] result_ecsdata_o,
  output wire  [2:0] result_ecswe_o,
  output wire        result_exc_o,
  output wire  [5:0] result_exccode_o,
  output wire        result_err_o,
  output wire        result_dbg_o
);

  wire [255:0] UIN_top;
  wire [319:0] UOUT_top;
  // unused fabric IO (W_IO bidirectional pads + config-access taps)
  wire [31:0] eF_I_top, eF_T_top;
  wire [63:0] eF_A_cfg, eF_B_cfg;
  wire        eF_ComActive, eF_ReceiveLED;

  // ==========================================================================
  // opcode -> slot pre-decode (combinational, always live)
  // ==========================================================================
  wire [6:0] opcode  = issue_req_instr_i[6:0];
  wire is_c0 = (opcode == 7'h0B);   // custom-0
  wire is_c1 = (opcode == 7'h2B);   // custom-1
  wire is_c2 = (opcode == 7'h5B);   // custom-2
  wire is_c3 = (opcode == 7'h7B);   // custom-3
  wire is_ours = is_c0 | is_c1 | is_c2 | is_c3;
  wire [1:0] req_slot = is_c1 ? 2'd1 : is_c2 ? 2'd2 : is_c3 ? 2'd3 : 2'd0;

  // ==========================================================================
  // reconfiguration controller FSM
  // ==========================================================================
  localparam [1:0] S_RUN = 2'd0, S_RESET = 2'd1, S_FETCH = 2'd2, S_HOLD = 2'd3;
  localparam [2:0] FP_REQ = 3'd0, FP_WAIT = 3'd1, FP_SET = 3'd2, FP_STR = 3'd3, FP_NXT = 3'd4;

  reg  [1:0]  state;
  reg         loaded_valid;
  reg  [1:0]  loaded_slot;
  reg  [1:0]  target_slot;
  reg  [31:0] cfg_base;
  reg  [15:0] widx;        // word index into the bitstream
  reg  [2:0]  fphase;      // per-word streaming phase
  reg  [7:0]  hold_cnt;
  reg  [7:0]  rst_cnt;     // fabric reset-pulse counter
  reg         in_flight;   // an offloaded instruction is being processed by the fabric

  reg         cfg_strobe;  // -> eFPGA_top.SelfWriteStrobe
  reg  [31:0] cfg_data;    // -> eFPGA_top.SelfWriteData

  // fabric is usable (out of reset, settled, configured) only in S_RUN with a valid load
  wire run_ready    = (state == S_RUN) & loaded_valid;
  wire slot_match   = run_ready & (loaded_slot == req_slot);
  wire need_reconfig = issue_valid_i & is_ours & (~loaded_valid | (loaded_slot != req_slot));

  // start a (re)configuration only when idle (no instruction in flight)
  wire launch = (state == S_RUN) & need_reconfig & ~in_flight;

  // base address of a slot's bitstream
  function [31:0] slot_base; input [1:0] s; begin
    slot_base = BITS_BASE + (s * BITS_STRIDE);
  end endfunction

  // ---- OBI read master (single outstanding transfer) ----
  assign cfgm_req_o  = (state == S_FETCH) & (fphase == FP_REQ);
  assign cfgm_addr_o = cfg_base + (widx << 2);

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state        <= S_RUN;
      loaded_valid <= 1'b0;
      loaded_slot  <= 2'd0;
      target_slot  <= 2'd0;
      cfg_base     <= 32'd0;
      widx         <= 16'd0;
      fphase       <= FP_REQ;
      hold_cnt     <= 8'd0;
      rst_cnt      <= 8'd0;
      in_flight    <= 1'b0;
      cfg_strobe   <= 1'b0;
      cfg_data     <= 32'd0;
    end else begin
      cfg_strobe <= 1'b0;   // default: strobe low

      // track an in-flight offloaded instruction (accepted -> result consumed)
      if (issue_valid_i & issue_ready_o & issue_resp_accept_o) in_flight <= 1'b1;
      if (result_valid_o & result_ready_i)                     in_flight <= 1'b0;

      case (state)
        // ----------------------------------------------------------------
        S_RUN: begin
          if (launch) begin
            target_slot <= req_slot;
            cfg_base    <= slot_base(req_slot);
            rst_cnt     <= 8'd0;
            state       <= S_RESET;
          end
        end

        // ----------------------------------------------------------------
        // pulse the fabric's config FSM reset so each (re)configuration starts
        // from the same clean state as the very first one (FSM resync from idle)
        S_RESET: begin
          if (rst_cnt >= RESET_CYCLES[7:0]) begin
            widx   <= 16'd0;
            fphase <= FP_REQ;
            state  <= S_FETCH;
          end else begin
            rst_cnt <= rst_cnt + 8'd1;
          end
        end

        // ----------------------------------------------------------------
        // stream one bitstream from memory into the fabric SelfWrite port
        S_FETCH: begin
          case (fphase)
            FP_REQ:  if (cfgm_gnt_i)    fphase <= FP_WAIT;        // address accepted
            FP_WAIT: if (cfgm_rvalid_i) begin
                       cfg_data <= cfgm_rdata_i;                  // capture config word
                       fphase   <= FP_SET;
                     end
            FP_SET:  fphase <= FP_STR;                            // let data settle
            FP_STR:  begin cfg_strobe <= 1'b1; fphase <= FP_NXT; end  // 1-cycle strobe
            FP_NXT:  begin
                       if (widx == NWORDS-1) begin
                         hold_cnt <= 8'd0;
                         state    <= S_HOLD;
                       end else begin
                         widx   <= widx + 16'd1;
                         fphase <= FP_REQ;
                       end
                     end
            default: fphase <= FP_REQ;
          endcase
        end

        // ----------------------------------------------------------------
        // fabric released; let its config FFs settle before accepting work
        S_HOLD: begin
          if (hold_cnt >= HOLD_CYCLES[7:0]) begin
            loaded_valid <= 1'b1;
            loaded_slot  <= target_slot;
            state        <= S_RUN;
          end else begin
            hold_cnt <= hold_cnt + 8'd1;
          end
        end

        default: state <= S_RUN;
      endcase
    end
  end

  // Keep the mapped coproc (user logic) in reset throughout (re)configuration AND the
  // settle window, releasing it only once we reach S_RUN. Releasing it during S_HOLD
  // (while a just-overwritten fabric is still settling) can sustain combinational-loop
  // oscillation on a live reconfiguration; this mirrors the proven direct-drive
  // sequence which holds the user logic in reset until after the fabric has settled.
  wire coproc_rstn = run_ready;

  // Fabric infrastructure reset: held low at chip reset AND pulsed at the start of
  // every reconfiguration (S_RESET) so the fabric's config FSM resyncs from idle,
  // exactly as it does on the first power-on configuration.
  wire fab_resetn = rst_ni & (state != S_RESET);

  // ==========================================================================
  // input packing: coproc inputs -> UIN_top
  //  - rst_ni bit is the controller-managed functional reset
  //  - issue_valid into the fabric is GATED so the fabric never starts an issue
  //    handshake until we are in S_RUN with the matching bitstream loaded
  // ==========================================================================
  wire fab_issue_valid = issue_valid_i & slot_match;
  // Drive the fabric's data inputs to 0 except while actually running. During (re)config
  // a non-zero operand fed into the half-overwritten datapath drives the switch-matrix
  // combinational loops and sustains oscillation; holding inputs at 0 (as the proven
  // direct-drive sequence does) lets the fabric settle cleanly between configurations.
  wire fab_on = run_ready;

  assign UIN_top[255:158] = 98'b0;            // spare fabric inputs            // spare fabric inputs
  assign UIN_top[0]       = coproc_rstn;
  assign UIN_top[1]       = fab_on & compressed_valid_i;
  assign UIN_top[2]       = fab_issue_valid;
  assign UIN_top[34:3]    = fab_on ? issue_req_instr_i   : 32'b0;
  assign UIN_top[36:35]   = fab_on ? issue_req_mode_i    : 2'b0;
  assign UIN_top[40:37]   = fab_on ? issue_req_id_i      : 4'b0;
  assign UIN_top[104:41]  = fab_on ? issue_req_rs_i      : 64'b0;
  assign UIN_top[106:105] = fab_on ? issue_req_rs_valid_i: 2'b0;
  assign UIN_top[107]     = fab_on & commit_valid_i;
  assign UIN_top[108]     = fab_on & commit_kill_i;
  assign UIN_top[112:109] = fab_on ? commit_id_i         : 4'b0;
  assign UIN_top[113]     = fab_on & mem_ready_i;
  assign UIN_top[114]     = fab_on & mem_resp_exc_i;
  assign UIN_top[120:115] = fab_on ? mem_resp_exccode_i  : 6'b0;
  assign UIN_top[121]     = fab_on & mem_resp_dbg_i;
  assign UIN_top[122]     = fab_on & mem_result_valid_i;
  assign UIN_top[154:123] = fab_on ? mem_result_rdata_i  : 32'b0;
  assign UIN_top[155]     = fab_on & mem_result_err_i;
  assign UIN_top[156]     = fab_on & mem_result_dbg_i;
  assign UIN_top[157]     = fab_on & result_ready_i;

  // ==========================================================================
  // output mapping: live from eFPGA (gated by run/slot), dead hard-tied
  // ==========================================================================
  assign compressed_ready_o       = compressed_valid_i;
  assign compressed_resp_instr_o  = 32'b0;
  assign compressed_resp_accept_o = 1'b0;

  // Issue handshake to the CPU:
  //  - one of our custom opcodes: forward the fabric's response, but only once the
  //    matching bitstream is loaded (otherwise stall = reconfiguration in progress).
  //  - anything else: reject immediately (ready=1, accept=0) so the core never stalls
  //    on us and handles it as an illegal instruction.
  assign issue_ready_o          = is_ours ? (slot_match & UOUT_top[34]) : 1'b1;
  assign issue_resp_accept_o    = is_ours ? (slot_match & UOUT_top[35]) : 1'b0;
  assign issue_resp_writeback_o = slot_match & UOUT_top[36];
  assign issue_resp_dualwrite_o = 1'b0;
  assign issue_resp_dualread_o  = 3'b0;
  assign issue_resp_loadstore_o = 1'b0;
  assign issue_resp_ecswrite_o  = 1'b0;
  assign issue_resp_exc_o       = 1'b0;

  // XIF memory interface unused (the OBI read master is separate)
  assign mem_valid_o    = 1'b0;
  assign mem_req_id_o   = 4'b0;
  assign mem_req_mode_o = 2'b0;
  assign mem_req_we_o   = 1'b0;
  assign mem_req_size_o = 3'b0;
  assign mem_req_be_o   = 4'b0;
  assign mem_req_attr_o = 2'b0;
  assign mem_req_wdata_o= 32'b0;
  assign mem_req_last_o = 1'b0;
  assign mem_req_spec_o = 1'b0;
  assign mem_req_addr_o = 32'b0;

  // Result handshake: valid only while running with a configured fabric.
  assign result_valid_o   = run_ready & UOUT_top[127];
  assign result_id_o      = UOUT_top[131:128];
  assign result_data_o    = UOUT_top[163:132];
  assign result_rd_o      = UOUT_top[168:164];
  assign result_we_o      = 1'b1;
  assign result_ecsdata_o = 6'b0;
  assign result_ecswe_o   = 3'b0;
  assign result_exc_o     = 1'b0;
  assign result_exccode_o = 6'b0;
  assign result_err_o     = 1'b0;
  assign result_dbg_o     = 1'b0;

  assign config_busy_o = (state != S_RUN) | ~loaded_valid;

  // Present the config word/strobe to the fabric on the opposite clock edge from the
  // one the fabric's config FSM samples on. In simulation this gives clean half-cycle
  // setup (matching the proven direct-drive sequence) and avoids a same-edge race that,
  // combined with the switch-matrix combinational loops, makes a live reconfiguration
  // unstable. Synthesis keeps the plain synchronous path (real gate delays remove the
  // race), so the RTL-to-GDS flow is unaffected.
`ifdef SYNTHESIS
  wire        sw_strobe = cfg_strobe;
  wire [31:0] sw_data   = cfg_data;
`else
  reg        sw_strobe;
  reg [31:0] sw_data;
  always @(negedge clk_i) begin
    sw_strobe <= cfg_strobe;
    sw_data   <= cfg_data;
  end
`endif

  // ---- the FABulous eFPGA fabric ----
  eFPGA_top efpga_i (
    .A_config_C(eF_A_cfg), .B_config_C(eF_B_cfg),
    .I_top(eF_I_top), .O_top(32'b0), .T_top(eF_T_top),
    .UIN_top(UIN_top), .UOUT_top(UOUT_top),
    .CLK(clk_i), .resetn(fab_resetn),
    .SelfWriteStrobe(sw_strobe), .SelfWriteData(sw_data),
    .Rx(1'b1), .ComActive(eF_ComActive), .ReceiveLED(eF_ReceiveLED),
    .s_clk(1'b0), .s_data(1'b0)
  );
endmodule

# Building the Fast Spatial Kalman‑Filter eFPGA Coprocessor — From Scratch

This is the **complete, unambiguous** build recipe: from `FABulous create-project` all the way to
running the coprocessor benchmark in the CV32E40X SoC. Every command is exact. Every non‑obvious
step has a **WHY** note explaining the gotcha it avoids (each was learned the hard way).

The end product: the whole 34‑multiply pipelined `kf_copro` mapped **spatially** into a FABulous
eFPGA, routed on a normal laptop, bitstreamed, integrated over the CV32E40X eXtension Interface, and
delivering **9 cycles/sample (~73× vs software; 3.48× was the old time‑shared version)**.

There are two ways to use this document:
- **Fast path** — the finished sources are in this deliverable, so you can just run the one‑shot
  scripts (`fabric_project/build_supertile.sh`, then the SoC integration). Jump to §D.
- **Understand‑everything path** — §A–§C reproduce every file and every command from an empty
  `FABulous create-project`. Read top to bottom.

---

## Part 0 — Prerequisites & toolchain

### 0.1 Install the tools

```bash
# FABulous (via uv) + the OSS-CAD-Suite (Yosys, nextpnr-generic, iverilog, ...)
curl -LsSf https://astral.sh/uv/install.sh | sh
export PATH="$HOME/.local/bin:$PATH"
uv tool install fabulous-fpga
FABulous install oss-cad-suite
```

### 0.2 The PATH you need in every shell

```bash
export PATH="$HOME/.fabulous/oss-cad-suite/bin:$HOME/.local/share/uv/tools/fabulous-fpga/bin:$PATH"
# Verify:
FABulous --version                 # 2.0.0b3 or newer
yosys --version                    # 0.4x
nextpnr-generic --version
which bit_gen                      # $HOME/.local/share/uv/tools/fabulous-fpga/bin/bit_gen
iverilog -V | head -1              # 10.x
```

> **WHY:** `bit_gen` and the OSS‑CAD tools are **not** on `PATH` by default. Forgetting this is the
> #1 cause of "command not found" mid‑build.

### 0.3 For the SoC step (Part C/D) you also need

```bash
# RISC-V GCC (builds the test firmware)
export PATH="/home/prasit/riscv/xpack-riscv-none-elf-gcc-15.2.0-1/bin:$PATH"
riscv-none-elf-gcc --version | head -1
# A Verilog simulator for the full SoC:
#   /home/prasit/intelFPGA/20.1/modelsim_ase/bin/vsim   <- 32-bit, see the WARNING in §D.
```

> **WARNING (read before §D):** the free **`modelsim_ase` is 32‑bit** and **cannot elaborate** the
> 1920‑tile fast fabric (`eFPGA.v` is ~126 000 lines → `mmap()` fails). The 384‑tile *time‑shared*
> fabric fits, but the fast one needs a **64‑bit ModelSim/Questa**. On a laptop, verify with the
> cycle‑accurate soft sim in §B instead (it gives the identical numbers in seconds).

---

## Part A — The FABulous eFPGA fabric

Directory for this part: `fabric_project/`. The finished version is included; the steps below
rebuild it from an empty project.

### A.1 Create the project

```bash
cd ~/Downloads/fastkf_final          # or wherever you keep this
FABulous create-project fabric_project -w verilog
cd fabric_project
```

(`-w verilog` selects the Verilog writer; the default project name is `demo`.)

**Exactly what `create-project` gives you — and what it does NOT.** After the command, `ls Tile/`
shows *only* these auto‑generated tiles:

```
DSP  (DSP_top + DSP_bot, a supertile)     LUT4AB     RAM_IO     RegFile     W_IO
N_term_single   N_term_single2   N_term_DSP   N_term_RAM_IO       (north terminators)
S_term_single   S_term_single2   S_term_DSP   S_term_RAM_IO       (south terminators)
include/  ->  Base.csv (wire definitions) + Base.list (jump-wire matrix)
```
and a demo `fabric.csv` wired from `W_IO / LUT4AB / RegFile / DSP / RAM_IO`.

**It does NOT create `CIO` or `qmul`/`QMUL`.** Those two you add yourself:

| tile | what it is | how you add it (below) |
|---|---|---|
| **CIO** | the XIF bus in/out of the fabric (8 ext‑in + 10 ext‑out per BEL) | copy 2 source files (§A.5) |
| **qmul (QMUL supertile)** | the 32×32 Booth‑Wallace multiplier as a 4‑row supertile | run the generator (§A.2–A.4) |

You will also **replace the demo `fabric.csv`** with ours (§A.6) and **delete the models‑pack env line**:

```bash
sed -i '/FAB_MODELS_PACK/d' .FABulous/.env
```
> **WHY delete it:** with `FAB_MODELS_PACK` unset, FABulous auto‑guesses `Fabric/models_pack.v` and
> only *warns* if missing; left pointing at a stale path it hard‑errors before it even loads the fabric.

**The custom pieces you copy into the fresh project** (all provided in this deliverable's
`fabric_project/`; each is detailed in the section noted). If you named your fresh project the same
as ours, copy from a second copy of the deliverable — set `SRC=/path/to/fastkf_final/fabric_project`:

```bash
SRC=/path/to/fastkf_final/fabric_project      # the finished project (source of the custom files)
cp   $SRC/boothmult.v            .            # §A.2  Booth-Wallace BEL (project root)
cp   $SRC/gen_qmul_supertile.py  .            # §A.3  qmul supertile generator
cp   $SRC/widen_fabric.py        .            # §A.6  (optional) wider-fabric generator
cp   $SRC/fabric.csv             .            # §A.6  the 60x32 grid (replaces the demo fabric.csv)
mkdir -p Tile/CIO script user_design Test
cp   $SRC/Tile/CIO/CIO.csv  $SRC/Tile/CIO/CIO_GenIO.v   Tile/CIO/          # §A.5  CIO source (2 files)
cp   $SRC/script/gen_copro.py                            script/            # §A.9  wrapper/integration gen
cp   $SRC/Test/makehex.py                                Test/             # §A.12 hex converter
cp   $SRC/user_design/{kf_copro.v,qmw.v,xif_copro_sync.v,custom_prims.v}  user_design/   # §A.8
```
Then generate the supertile + terminators (§A.3–A.4) and run the fabric (§A.7).

### A.2 The Booth‑Wallace multiplier BEL — `boothmult.v`

The 32×32 signed Booth‑Wallace multiplier, output `q = (a*b) >> 16` (Q16.16). Provided at
`fabric_project/boothmult.v`.

Three rules that make it a valid FABulous BEL (each is a gotcha):
1. **One self‑contained module, fully unrolled** — *no* `genvar`/`generate`/`` `define `` macros.
   (When FABulous flattens the BEL, macros/generates become RTLIL processes and the re‑read chokes.)
2. **The BEL module name must differ from the tile name.** BEL is `boothmult`; the tile is `qmul`.
   (Two `module qmul` — the generated tile *and* the BEL — collide in gate‑sim.)
3. **Keep it at the project root** (`fabric_project/boothmult.v`), *not* under `Tile/qmul/`.
   > **WHY:** the generator also creates `Tile/QMUL/…`. Having both `Tile/qmul/` and `Tile/QMUL/`
   > (differ only by case) makes them collide on case‑insensitive extraction/filesystems and the BEL
   > gets lost. Root path avoids that.

### A.3 The qmul **SUPERTILE** — `gen_qmul_supertile.py`  ← the key idea

A single tile has one switch matrix, so a 96‑pin multiplier (64 in + 32 out) overwhelms the
channel width and **nextpnr oscillates forever** (7500–8500 overused, even on 64 GB). FABulous's
own answer (docs §Supertiles, used by the shipped DSP) is a **supertile**: several basic tiles, each
with its own switch matrix + JUMP network, so the pins are spread out.

`gen_qmul_supertile.py` builds a **4‑row** qmul supertile modelled on `DSP_top`/`DSP_bot`:

```
row (top→bottom)   local BEL pins (fabric-facing)   inter-tile buses
qmul_r3 (top)      b16..b31 in,  q24..q31 out        ↓dA(16)  ↑uC(8)
qmul_r2            b0..b15  in,  q16..q23 out        ↓dB(32)  ↑uB(16)
qmul_r1            a16..a31 in,  q8..q15  out        ↓dC(48)  ↑uA(24)
qmul_r0 (BEL)      a0..a15  in,  q0..q7   out        boothmult here
```
Each row feeds its 16 inputs from its **own JUMP network** and drives its 8 outputs onto its **own
BEG wires** — only ~24 fabric‑facing pins/tile (≈ the DSP's proven density), the rest chained
through the `top2bot`/`bot2top`‑style buses (down `dA/dB/dC` = 16/32/48, up `uA/uB/uC` = 24/16/8) to
the `boothmult` BEL in `qmul_r0`.

```bash
python3 gen_qmul_supertile.py
# -> Tile/QMUL/{qmul_r0,qmul_r1,qmul_r2,qmul_r3}/ + Tile/QMUL/QMUL.csv
```

Four gotchas the generator already handles (documented here so a manual edit doesn't reintroduce them):
- **CSV rows padded to 18 columns.** FABulous's parser indexes `temp[6]` on every direction row; a
  short row → `IndexError`.
- **Tile CSV keeps `INCLUDE,../../include/Base.csv`** (that *defines* the wires N1BEG…). The
  *matrix* `.list` does **not** `INCLUDE Base.list` — we wire the matrix ourselves.
- **Every `*BEG` sink needs a driver** ("rule 1": each `*BEG` ← `*END` sources). `Base.list` only
  connects the JUMP‑internal wires; the directional wires must be through‑routed by the tile matrix.
- **Wire filter uses `"BEG"`/`"END"` *in* the name**, so it catches the `N2BEGb`/`*ENDb` variants.
- Result: each sub‑tile = **300–316 config bits** (well under the 640/tile limit).

### A.4 The supertile terminators

The DSP supertile column is capped by `N_term_DSP`/`S_term_DSP`; ours needs `N_term_QMUL`/
`S_term_QMUL` (functionally identical to the single‑tile terminators):

```bash
for d in N_term S_term; do
  cp -r "Tile/${d}_single" "Tile/${d}_QMUL"
  mv "Tile/${d}_QMUL/${d}_single.csv" "Tile/${d}_QMUL/${d}_QMUL.csv"
  [ -f "Tile/${d}_QMUL/${d}_single_switch_matrix.list" ] && \
     mv "Tile/${d}_QMUL/${d}_single_switch_matrix.list" "Tile/${d}_QMUL/${d}_QMUL_switch_matrix.list"
  sed -i "s/${d}_single/${d}_QMUL/g" \
     "Tile/${d}_QMUL/${d}_QMUL.csv" "Tile/${d}_QMUL/${d}_QMUL_switch_matrix.list"
done
```

### A.5 The CIO tile — add it (2 source files)

`create-project` has no `CIO`. It carries the flattened XIF across the fabric boundary (8 external
in + 10 external out per `CIO_GenIO` BEL). You only need **two source files** — everything else
(`CIO_switch_matrix.v`, `CIO_ConfigMem.v`, `CIO.v`, …) is auto‑generated by `run_FABulous_fabric`:

```bash
mkdir -p Tile/CIO
# from this deliverable (or the original efpga_kalman project):
cp ../fabric_project/Tile/CIO/CIO.csv       Tile/CIO/     # the tile definition
cp ../fabric_project/Tile/CIO/CIO_GenIO.v   Tile/CIO/     # the IO BEL
```
`CIO.csv` is just:
```
TILE,CIO
INCLUDE,../include/Base.csv
BEL,./CIO_GenIO.v,,ADD_AS_CUSTOM_PRIM      # CIO_GenIO exposes EXTERNAL ports -> UIN_top/UOUT_top
MATRIX,GENERATE                            # CIO uses the AUTO-generated switch matrix (unlike qmul)
EndTILE
```
> **The number of CIO columns fixes the fabric's IO width:** 2 CIO columns × 32 rows = 64 BELs →
> **`UIN_top[511:0]`, `UOUT_top[639:0]`**. Keep it at 2 so the CV wrapper's widths don't change.

### A.6 The fabric grid — `fabric.csv`

60 cols × 32 rows. Column 0 = `W_IO`; cols 1–2 = `CIO`; **5 spread columns** are full stacks of the
`qmul` supertile (`qmul_r3,qmul_r2,qmul_r1,qmul_r0` repeating, 8 supertiles/column = 40 total, we
need 34); the rest are `LUT4AB` (~71 % utilisation → routing headroom). Provided as
`fabric_project/fabric.csv`. Its `ParametersBegin…End` block must include:

```
Supertile,./Tile/QMUL/QMUL.csv
Tile,./Tile/QMUL/qmul_r0/qmul_r0.csv          (…r1, r2, r3)
Tile,./Tile/N_term_QMUL/N_term_QMUL.csv       (+ S_term_QMUL, and the single/W_IO/CIO/LUT4AB tiles)
```
> The qmul columns are **spread out** ("checkerboard"), not clustered, so their congestion doesn't
> overlap. To widen further use `python3 widen_fabric.py 84 32 6` (keeps 2 CIO cols → IO width fixed).

### A.7 Generate the fabric — the exact FABulous shell commands

Enter the FABulous shell for this project (working directory becomes the project):

```bash
FABulous fabric_project            # or, if already inside it:  FABulous .
```

At the `FABulous>` prompt run **two** commands:

```tcl
FABulous> load_fabric              # parse fabric.csv + every Tile/*/*.csv (incl. QMUL supertile + CIO)
FABulous> run_FABulous_fabric      # build everything (see the 6 sub-steps below)
FABulous> exit
```

**`run_FABulous_fabric` is exactly this pipeline** (you can also run the steps individually at the
prompt, in this order, for debugging):

```tcl
FABulous> gen_io_fabric            # (no-op here; we define IO via the CIO tile, not auto IO tiles)
FABulous> gen_fabric               # = gen_all_tile (gen_switch_matrix + gen_config_mem for EVERY
                                   #   tile: qmul_r0..r3, CIO, LUT4AB, W_IO, terminators) then
                                   #   stitches them -> Fabric/eFPGA.v
FABulous> gen_bitStream_spec       # -> .FABulous/bitStreamSpec.bin (+ .csv)  [needed by bit_gen]
FABulous> gen_top_wrapper          # -> Fabric/eFPGA_top.v  (UIN_top[511:0]/UOUT_top[639:0], SelfWrite…)
FABulous> gen_model_npnr           # -> .FABulous/pips.txt, bel.txt, bel.v2.txt  [the nextpnr model]
FABulous> gen_geometry             # -> eFPGA_geometry.csv (FABulator view; not needed for sim)
```

Non‑interactive equivalent (what the scripts use):
```bash
printf 'load_fabric\nrun_FABulous_fabric\nexit\n' > gen.tcl
FABulous . -fs gen.tcl
```

> **WHY it doesn't choke on the custom tiles:** `load_fabric` reads the `Supertile,` /`Tile,` lines
> you added to `fabric.csv` (§A.6); `gen_fabric` sees `MATRIX,./qmul_matrix.list` for the qmul
> sub‑tiles (custom matrix → bypasses the 32‑in/8‑out auto‑gen limit) and `MATRIX,GENERATE` for CIO.

**Verify the generation succeeded:**
```bash
grep -oE '(UIN_top|UOUT_top)[[:space:]]*\[[0-9]+:0\]' Fabric/eFPGA_top.v | sort -u   # [511:0]/[639:0]
grep -c boothmult .FABulous/bel.txt                                                  # 40 placeable BELs
ls Fabric/eFPGA.v Fabric/eFPGA_top.v .FABulous/bitStreamSpec.bin .FABulous/pips.txt   # all present
```

### A.8 The user design (the whole spatial KF)

Four files under `user_design/` (provided):
- **`kf_copro.v`** — the 8‑stage pipelined KF, **34 `qmul_booth_wallace` instances** (its *own*
  `qmul`/`mul` module definitions removed — they come from the tile mapping).
- **`qmw.v`** — `module qmul_booth_wallace(a,b,q)` that instantiates the **`boothmult`** BEL (this is
  what maps each multiply onto a qmul supertile).
- **`xif_copro_sync.v`** — `module xif_copro_verilog` (the flattened XIF port list) instantiating
  `kf_copro`. This module name/port list is the contract `gen_copro.py` parses.
- **`custom_prims.v`** — blackbox declarations of `boothmult` and `CIO_GenIO` for synthesis.

### A.9 Generate the wrapper + integration RTL

```bash
python3 script/gen_copro.py wrapper                                   # -> user_design/top_wrapper.v + Test/tb_copro_map.vh
python3 script/gen_copro.py integration user_design/xif_copro_efpga.v # -> the synthesizable bit-packing wrapper
```
`Test/tb_copro_map.vh` is the single source of truth for the XIF↔`UIN_top`/`UOUT_top` bit packing
(`issue_ready`=UOUT[34], `result_valid`=UOUT[127], `result_data`=UOUT[163:132], …).

### A.10 Synthesize the design

```bash
mkdir -p build
yosys -p "synth_fabulous -top top_wrapper -json build/kf.json -extra-plib user_design/custom_prims.v" \
  user_design/top_wrapper.v user_design/xif_copro_sync.v user_design/kf_copro.v user_design/qmw.v
```
Result: **34 `boothmult` + 20 `CIO_GenIO` + ~9390 LUT/FF cells.**

### A.11 Place & route  (this is where the supertile pays off)

```bash
FAB_ROOT="$(pwd)" nextpnr-generic --uarch fabulous --router router2 \
  --json build/kf.json -o fasm=build/kf.fasm 2>&1 | tee build/pnr.log
```
Watch the `remaining arcs` column reach **0** → `Info: Routing complete`. (The single‑tile version
oscillated at ~9000 forever; the supertile routes on a 7.4 GB laptop.) The "Max frequency … FAIL at
12 MHz" line is **non‑fatal** and expected for a routing‑limited fabric — the FASM is still written.

### A.12 Bitstream

```bash
bit_gen -genBitstream build/kf.fasm .FABulous/bitStreamSpec.bin build/kf.bin
# byte-per-line hex for the FABRIC-LEVEL sim (§B). nbytes must be >= the .bin size (158 KB here):
python3 Test/makehex.py build/kf.bin 163840 build/kf.hex
echo "NWORDS = $(( $(stat -c%s build/kf.bin) / 4 ))"      # 39606  <- needed by the CV wrapper (§C)
```

> **One‑shot for A.3–A.12:** `bash build_supertile.sh` runs generate‑supertile → clean → fabric →
> synth → router2 → bit_gen in one go.

---

## Part B — Verify the fabric on this machine

Two levels, both included in `verify/`:

```bash
cd ~/Downloads/fastkf_final/verify

# (1) CYCLE-ACCURATE, runs in SECONDS — the practical on-laptop check.
bash verify_cycles.sh
#   Drives the real xif_copro_verilog XIF handshake into the soft kf_copro. A FABulous fabric
#   preserves every pipeline register, so this gives the IDENTICAL cycles/sample and numeric
#   result as the routed fabric. Expect: 9 cycles/sample, step output 69177744 (matches golden).

# (2) FULL FABRIC — definitive but slow (~30-60 min iverilog compile of the 126k-line eFPGA.v).
bash verify_fabric.sh
#   Configures the REAL bitstream (build/kf.hex) into the routed fabric and runs KF steps through it.
#   modelsim_ase (32-bit) CANNOT do this (mmap fails); iverilog can, with patience.
```

---

## Part C — Integrate into the CV32E40X SoC

Directory: `cv32e40x_kf_test/`. The finished integration is included; here is exactly how it was
produced from the working *time‑shared* SoC.

### C.1 Assemble the fast fabric RTL directory

```bash
cd cv32e40x_kf_test
FF=rtl/efpga/fabric_fastkf ; rm -rf "$FF"; mkdir -p "$FF"
FP=../fabric_project           # the Part-A project
find "$FP/Fabric" -name '*.v' -exec cp -n {} "$FF/" \;
find "$FP/Tile"   -name '*.v' -exec cp -n {} "$FF/" \;
# static infra FABulous doesn't regenerate into the project (config FSM + primitive library):
TPL=$HOME/.local/share/uv/tools/fabulous-fpga/lib/python3.12/site-packages/FABulous/fabric_files/FABulous_project_template_verilog
for f in eFPGA_Config.v Frame_Data_Reg.v Frame_Select.v ConfigFSM.v config_UART.v bitbang.v; do
  [ -f "$FF/$f" ] || cp -n "$TPL/Fabric/$f" "$FF/"; done
# models_pack.v: use the SoC's known-good one (avoids an ifdef-guarded LHQD1 double-def edge case)
cp rtl/efpga/fabric_kf2/models_pack.v "$FF/models_pack.v"
```
> **WHY the fabric_kf2 models_pack:** it's fabric‑independent (just primitives: LUT4, muxes, latch)
> and already known to compile in this SoC.

### C.2 The reconfig wrapper — `xif_copro_efpga_fastkf.v`

Copy the time‑shared wrapper and change **only** the fabric‑facing geometry (the FSM, XIF packing,
and half‑cycle SelfWrite are byte‑identical):

```bash
cd rtl/efpga
cp xif_copro_efpga_kf.v xif_copro_efpga_fastkf.v ; F=xif_copro_efpga_fastkf.v
sed -i 's/module xif_copro_efpga_kf /module xif_copro_efpga_fastkf /' "$F"
sed -i "s/parameter integer NWORDS     = 8166,/parameter integer NWORDS     = 39606,/" "$F"
sed -i "s/parameter \[31:0\] BITS_STRIDE = 32'h0001_0000,.*/parameter [31:0] BITS_STRIDE = 32'h0004_0000,/" "$F"
sed -i 's/wire \[255:0\] UIN_top;/wire [511:0] UIN_top;/'       "$F"
sed -i 's/wire \[319:0\] UOUT_top;/wire [639:0] UOUT_top;/'     "$F"
sed -i 's/wire \[31:0\] eF_I_top, eF_T_top;/wire [63:0] eF_I_top, eF_T_top;/'   "$F"
sed -i 's/wire \[63:0\] eF_A_cfg, eF_B_cfg;/wire [127:0] eF_A_cfg, eF_B_cfg;/'  "$F"
sed -i "s/assign UIN_top\[255:158\] = 98'b0;.*/assign UIN_top[511:158] = 354'b0;/" "$F"
sed -i "s/\.I_top(eF_I_top), \.O_top(32'b0), \.T_top(eF_T_top),/.I_top(eF_I_top), .O_top(64'b0), .T_top(eF_T_top),/" "$F"
cd ../..
```
| change | from | to | why |
|---|---|---|---|
| `UIN_top`/`UOUT_top` | `[255:0]`/`[319:0]` | `[511:0]`/`[639:0]` | 2 CIO cols on the bigger fabric |
| `A/B_config_C` | `[63:0]` | `[127:0]` | more config columns |
| `I/T_top`,`O_top` | `[31:0]`,`32'b0` | `[63:0]`,`64'b0` | more W_IO pads |
| `NWORDS` | `8166` | `39606` | fast bitstream is bigger |
| `BITS_STRIDE` | 64 KiB | **256 KiB** | fast bitstream is 158 KB > 64 KB |

### C.3 Repoint `rtl/xif_copro.sv`

```bash
sed -i 's/  xif_copro_efpga_kf #(/  xif_copro_efpga_fastkf #(/' rtl/xif_copro.sv
sed -i "s/\.BITS_STRIDE       (32'h0001_0000),.*/.BITS_STRIDE       (32'h0004_0000),/" rtl/xif_copro.sv
sed -i "s/\.NWORDS            (8166)/.NWORDS            (39606)/" rtl/xif_copro.sv
```

### C.4 Swap the fabric filelist in the manifest

```bash
M=cv32e40x_manifest.flist ; cp "$M" "$M.bak_timeshared"
head -77 "$M" > "$M.new"
for f in $(ls rtl/efpga/fabric_fastkf/*.v | sort); do
  echo '${DESIGN_RTL_DIR}/efpga/fabric_fastkf/'"$(basename $f)" >> "$M.new"; done
echo '${DESIGN_RTL_DIR}/efpga/xif_copro_efpga_fastkf.v' >> "$M.new"
tail -n +129 "$M" >> "$M.new"          # keeps xif_copro.sv + the CV core files
mv "$M.new" "$M"
grep -c fabric_kf2 "$M"                 # must be 0
```

### C.5 Testbench slot stride

```bash
sed -i "s/localparam int unsigned BITS_STRIDE = 32'h0001_0000;.*/localparam int unsigned BITS_STRIDE = 32'h0004_0000;/" tb/tb_top.sv
```

### C.6 The bitstream in the tb's byte order  ← easy to get wrong

The SoC's byte‑addressable RAM + the OBI config master need a **specific byte order** (little‑endian
32‑bit read), which is **not** what `makehex` produces. Use the provided converter:

```bash
python3 tools/bin2hex.py ../fabric_project/build/kf.bin bitstreams/kf_kf
head -4 bitstreams/kf_kf.bytes.hex     # 01 ff aa 00  (word 0x00aaff01, LSB first)
```
> **WHY:** `makehex`'s `kf.hex` is `00 aa ff 01` (raw bin order). `bin2hex.py` reorders each word to
> `01 ff aa 00` so `{mem[a+3],mem[a+2],mem[a+1],mem[a]}` reconstructs the word. Wrong order → the
> fabric silently mis‑configures.

### C.7 The benchmark program

`sw/kfperf/perf.c` times the pure‑software KF vs the coprocessor with the `mcycle` CSR (opcode
`0x0B` = the KF custom instruction). It configures the fabric once, then times N samples each. To
change the sample count edit the two loops (`for(k=0;k<64;k++)`) and the two `/64` divisors.

### C.8 Compile check

```bash
cd sw
export PATH="/home/prasit/intelFPGA/20.1/modelsim_ase/bin:/home/prasit/riscv/xpack-riscv-none-elf-gcc-15.2.0-1/bin:$PATH"
make tb-clean
make vsim-all          # vlog the whole SoC + fast fabric. Expect "Errors: 0".
vdir -lib work | grep -E 'boothmult|qmul_r0|eFPGA_top|xif_copro_efpga_fastkf'   # all present
```

---

## Part D — Run the simulation

```bash
cd cv32e40x_kf_test/sw
export PATH="/home/prasit/intelFPGA/20.1/modelsim_ase/bin:/home/prasit/riscv/xpack-riscv-none-elf-gcc-15.2.0-1/bin:$PATH"

make kfperf-vsim-run     # SW-vs-coprocessor cycle benchmark (prints cycles/sample + speed-up)
# or:
make kf-vsim-run         # streams the noisy altitude trace through the KF coprocessor
```

> **On this laptop:** `make …-vsim-run` **compiles** fine but **`modelsim_ase` (32‑bit) fails to
> elaborate** the 1920‑tile fabric (`mmap()` EPERM). Options:
> 1. Run the **cycle‑accurate verification** from §B — `bash ../../verify/verify_cycles.sh` — it
>    gives the identical **9 cycles/sample** and the correct output in seconds.
> 2. Run `make kfperf-vsim-run` on a machine with a **64‑bit ModelSim/Questa** for the full
>    end‑to‑end SW‑vs‑coproc numbers.

---

## Part E — Expected result

```
step y=69180207 -> 69177744   [9 cycles]     <- matches the golden reference (correctness)
...
AVG 9 CYCLES/SAMPLE
```

| implementation | cycles/sample | speed‑up vs software |
|---|---|---|
| pure software KF (rv32im) | ~661 | 1× |
| time‑shared eFPGA KF (1 shared multiplier) | ~190 | 3.48× |
| **fast spatial eFPGA KF (34 qmul supertiles)** | **9** | **~73×** |

---

## Appendix — the gotcha checklist (all already handled in the provided files)

1. **`bit_gen`/tools not on PATH** → export the FABulous + oss‑cad‑suite bins (§0.2).
2. **`FAB_MODELS_PACK` set to a bad path** → delete the line in `.FABulous/.env` (§A.1).
3. **BEL must be one unrolled module, name ≠ tile name, at project root** (§A.2).
4. **Single 96‑pin tile never routes** → use the 4‑row **supertile** (§A.3).
5. **CSV direction rows must be padded to 18 columns** (parser reads `temp[6]`).
6. **Tile CSV `INCLUDE Base.csv` (defines wires); matrix does NOT `INCLUDE Base.list`** (wire it).
7. **Through‑route every `*BEG` (rule 1); filter wires by `"BEG"`/`"END"` in‑name** (catches `*b` variants).
8. **Supertile needs `N_term_QMUL`/`S_term_QMUL` + a `Supertile,` line in `fabric.csv`** (§A.4, A.6).
9. **2 CIO columns → `UIN_top[511:0]`/`UOUT_top[639:0]`** (don't change the column count).
10. **`nextpnr` timing FAIL is non‑fatal** — the FASM is still written (§A.11).
11. **`makehex` `nbytes` must be ≥ the `.bin` size** (158 KB → use 163840) (§A.12).
12. **SoC bitstream needs `bin2hex.py`, not `makehex`** (byte order) (§C.6).
13. **`NWORDS=39606`, `BITS_STRIDE=256 KiB`** in the wrapper + `xif_copro.sv` + `tb_top.sv` (§C.2–C.5).
14. **`modelsim_ase` is 32‑bit** — can't elaborate the fast fabric; use the soft sim or 64‑bit tool (§D).
```

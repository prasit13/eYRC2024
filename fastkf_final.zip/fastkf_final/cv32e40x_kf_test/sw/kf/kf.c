// =====================================================================================
// kf.c -- exercise the Kalman-filter coprocessor's TWO operations on the CV32E40X.
//
// The single custom opcode (0x0B, funct3=0) does two things, selected by funct7:
//
//   kf_step  -> .insn r 0x0B,0x0,0x00,rd,rs1,zero    filter one sample (rs1 -> rd)
//   kf_cfg   -> .insn r 0x0B,0x0,0x01,rd,rs1,rs2     write model coefficient[rs2] = rs1
//
// This program is just a functional check that BOTH work: it writes the model parameters
// with a batch of kf_cfg calls, streams the noisy trace through kf_step, then re-runs the
// trace after changing ONE parameter (R) with kf_cfg to confirm the change takes effect.
// No adaptive/decision logic here -- that lives in a separate algorithm later.
// =====================================================================================
#include <stdint.h>
#include "trace.h"     // #define N ; static const int NOISY[N], TRUTH[N]  (all Q16.16)

#define MM_PRINT  (*(volatile uint32_t *)0x00800000u)   // write a byte -> stdout
#define MM_STATUS (*(volatile uint32_t *)0x008000c0u)   // 123456789 = pass, 1 = fail
#define MM_EXIT   (*(volatile uint32_t *)0x008000c4u)   // write -> $finish(value)

// ---- the single custom opcode, two operations ----
static inline int kf_step(int y){                       // raw altitude -> denoised
  int r; asm volatile(".insn r 0x0B,0x0,0x00,%0,%1,zero" : "=r"(r) : "r"(y)); return r;
}
static inline int kf_cfg(int value, int index){         // coefficient[index] = value
  int r; asm volatile(".insn r 0x0B,0x0,0x01,%0,%1,%2" : "=r"(r) : "r"(value), "r"(index)); return r;
}

// ---- kf_cfg coefficient indices (see kf_copro.v) ----
#define CFG_R    0
#define CFG_Q00  1
#define CFG_Q11  4
#define CFG_Q22  6
#define CFG_P0H  7
#define CFG_P0V  8
#define CFG_P0A  9
#define CFG_DT   10
#define CFG_DT2  11
#define CFG_REINIT 15

// ---- parameter values (Q16.16) ----
#define Q16(i)   ((int)((i) << 16))   // integer -> Q16.16
#define R_DEF    Q16(8)               // nominal measurement-noise variance
#define R_ALT    Q16(30)              // a different R, to prove kf_cfg takes effect
#define P0_DEF   Q16(200)             // initial state covariance (diagonal)
#define Q00_DEF  3277                 // 0.05  (fractional Q16.16 literal)
#define Q11_DEF  36045                // 0.55
#define Q22_DEF  66                   // 0.001
#define DT_DEF   1311                 // 0.02  (50 Hz)
#define DT2_DEF  13                   // 0.0002

static void putc_(char c){ MM_PRINT = (uint32_t)c; }
static void puts_(const char *s){ while(*s) putc_(*s++); }
static void putdec(int v){
  char b[12]; int i=0; unsigned u;
  if(v<0){ putc_('-'); u=(unsigned)(-v); } else u=(unsigned)v;
  if(u==0){ putc_('0'); return; }
  while(u){ b[i++]='0'+(u%10); u/=10; }
  while(i) putc_(b[--i]);
}
static int ipart(int q){ return q>>16; }     // Q16.16 -> integer
static int absq(int q){ return q<0 ? -q : q; }

// stream the whole trace through kf_step; return total |estimate - truth| (Q16.16)
static long long run_trace(int print){
  long long err = 0; int k, est;
  for(k=0; k<N; k++){
    est = kf_step(NOISY[k]);
    err += absq(est - TRUTH[k]);
    if(print && (k<10 || (k%8)==0)){
      puts_("  "); putdec(k);
      puts_("  "); putdec(ipart(NOISY[k]));
      puts_("  "); putdec(ipart(est));
      puts_("  "); putdec(ipart(TRUTH[k]));
      putc_('\n');
    }
  }
  return err;
}

int main(void){
  long long raw_err = 0, errA, errB;
  int k;

  for(k=0; k<N; k++) raw_err += absq(NOISY[k] - TRUTH[k]);

  puts_("KF coprocessor opcode check: kf_step + kf_cfg\n");

  // ---- write the full model with kf_cfg, then run kf_step over the trace ----
  puts_("config A: R=8, Q=diag(.05,.55,.001), P0=200, dt=0.02\n");
  kf_cfg(R_DEF,   CFG_R);
  kf_cfg(Q00_DEF, CFG_Q00);
  kf_cfg(Q11_DEF, CFG_Q11);
  kf_cfg(Q22_DEF, CFG_Q22);
  kf_cfg(P0_DEF,  CFG_P0H);
  kf_cfg(P0_DEF,  CFG_P0V);
  kf_cfg(P0_DEF,  CFG_P0A);
  kf_cfg(DT_DEF,  CFG_DT);
  kf_cfg(DT2_DEF, CFG_DT2);
  kf_cfg(0,       CFG_REINIT);          // re-seed filter for a clean start

  puts_("  k  raw   kf  true\n");
  errA = run_trace(1);

  // ---- change ONE parameter via kf_cfg and re-run: result must differ ----
  puts_("config B: same model but R=30 (via kf_cfg)\n");
  kf_cfg(R_ALT, CFG_R);
  kf_cfg(0,     CFG_REINIT);
  errB = run_trace(0);

  puts_("total |error| (m):  raw="); putdec((int)(raw_err>>16));
  puts_("  kf(R=8)=");               putdec((int)(errA>>16));
  puts_("  kf(R=30)=");              putdec((int)(errB>>16));
  putc_('\n');

  // PASS = both configs denoise (kf < raw) AND kf_cfg(R) demonstrably changed the output
  if(errA < raw_err && errB < raw_err && errA != errB){
    puts_("PASS: kf_step filters and kf_cfg changes a parameter\n");
    MM_STATUS = 123456789u; MM_EXIT = 0u;
  } else {
    puts_("FAIL\n");
    MM_STATUS = 1u; MM_EXIT = 1u;
  }
  for(;;);
  return 0;
}

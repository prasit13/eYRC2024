# Building the eFPGA Kalman-Filter Accelerator from Scratch
### CV32E40X + a FABulous eFPGA fabric whose DSP tile performs the Kalman-filter multiplies

This is a single, self-contained guide that takes you from the **baseline CV32E40X project**
(`/home/prasit/Downloads/cv32e40x_kf_test`, which contains only the RISC-V core and a *software*
Kalman-filter coprocessor) all the way to a working system in which a **configured FABulous eFPGA
fabric performs the filter's 32x32 fixed-point multiplies**, driven by the core over the CORE-V
eXtension Interface (XIF), with the bitstream streamed out of system RAM at boot.

Everything that was developed interactively, one step at a time, is collected here. Nothing is
omitted: every file you must create is listed in full, every command is given verbatim, every
expected output is shown, and a dedicated troubleshooting section records every trap that cost
real debugging time.

---

## 0. What you will build (the big picture)

```
 tb_top  (loads firmware + bitstream into RAM)
  └─ cv32e40x_tb_wrapper
       ├─ cv32e40x_core            the RISC-V CPU
       │     ▲  │   XIF (issue / commit / result)
       │     │  ▼
       ├─ xif_copro                flattens XIF, exposes the OBI config master (cfgm_*)
       │     └─ kf_copro_fab       the Kalman-filter ENGINE
       │            │  ├─ OBI master  ── streams the bitstream from RAM ──┐
       │            │  ├─ 8x RegFile_soft   (the filter's register array) │
       │            │  └─ eFPGA_top  ◄──────────── SelfWriteData ─────────┘
       │            │        (configured FABulous fabric; the KFMUL tile multiplies A*B>>16)
       └─ mm_ram / dp_ram          instruction+data memory; also holds the bitstream @0x00100000
```

The CPU executes ordinary C. A custom instruction (`kf_step`) is offloaded to `kf_copro_fab`,
which runs a ~56-microinstruction Kalman-filter schedule. Every multiply in that schedule is sent
to the **hard KFMUL tile inside the configured eFPGA fabric** and the product is read back. The
filter's coefficients can be changed at run time with a second custom instruction (`kf_cfg`).

**Final measured result** (ModelSim, fabric in the loop):

```
KF performance: pure software vs coprocessor (cycles via mcycle)
software  total : 42342 cyc  (661 /sample)
coproc    total :  6319 cyc  ( 98 /sample)        => 6.7x faster
ALL TESTS PASSED
```

The document is organised so you can read it top-to-bottom and build as you go:

| Part | Topic |
|---|---|
| 1 | Prerequisites and toolchain (exact versions and paths) |
| 2 | The baseline project and the directory layout |
| 3 | Background: the Kalman filter and Q16.16 fixed point |
| 4 | Fast hardware arithmetic: Booth-Wallace multiply, Newton-Raphson divide |
| 5 | The time-shared software-RTL coprocessor (`kf_copro_ts`) |
| 6 | The register-file coprocessor (`kf_copro_rf`) - making it fabric-shaped |
| 7 | Building the FABulous eFPGA project from scratch |
| 8 | The fabric-KFMUL coprocessor (`kf_copro_fab`) |
| 9 | Integrating into the CV32E40X SoC |
| 10 | The software (`kf.c`, `perf.c`) |
| 11 | Building and running |
| 12 | Results and performance |
| 13 | Troubleshooting: every trap, and the fix |
| 14 | Future work: pipelining the multiply (`OUT_reg=1`) |
| A | Appendix: command cheat-sheet and file tree |

> Throughout, the **working reference copies** of every file produced below live in
> `/home/prasit/fabulous_self/cv32e40x_kf_test` (the integrated project) and
> `/home/prasit/fabulous_self/efpga_kf_self` (the FABulous project). If a listing ever drifts
> from your build, diff against those.

---

## 1. Prerequisites and toolchain

These are the exact tools/versions this flow was validated with. Other recent versions usually
work, but the FABulous + yosys + nextpnr trio is version-sensitive, so prefer the oss-cad-suite
bundle that FABulous installs.

| Tool | Version | Location used here | Purpose |
|---|---|---|---|
| RISC-V GCC | xpack riscv-none-elf-gcc 15.2.0 | `/home/prasit/riscv/xpack-riscv-none-elf-gcc-15.2.0-1` | compile the C firmware |
| FABulous | (uv tool `fabulous-fpga`) | `/home/prasit/.local/bin/FABulous` | generate the eFPGA fabric, P&R, bitstream |
| oss-cad-suite | yosys 0.63+188, nextpnr-0.10 | `/home/prasit/.fabulous/oss-cad-suite/bin` | synthesis + place&route for the fabric |
| Icarus Verilog | iverilog/vvp (any 11+) | system `iverilog` | fast RTL unit sims |
| ModelSim | Intel FPGA Starter Edition 2020.1 | `/home/prasit/intelFPGA/20.1/modelsim_ase/bin` | full SoC simulation |
| Python 3 | 3.10+ | system | helper scripts (bitstream conversion, codegen) |

Install FABulous and its oss-cad-suite (one time):

```bash
pip install --user fabulous-fpga          # or: uv tool install fabulous-fpga
FABulous install-oss-cad-suite            # installs ~/.fabulous/oss-cad-suite
```

**Critical PATH rule.** When you run any FABulous / yosys / nextpnr / bit_gen step, the
oss-cad-suite bin must come *first* on PATH (its yosys/nextpnr are the ones FABulous expects), then
the FABulous bin:

```bash
export PATH="/home/prasit/.fabulous/oss-cad-suite/bin:/home/prasit/.local/share/uv/tools/fabulous-fpga/bin:$PATH"
```

Mixing a system yosys (e.g. 0.40) with this flow is a common cause of mysterious failures.

---

## 2. The baseline project and directory layout

Start from the baseline at `/home/prasit/Downloads/cv32e40x_kf_test`. It is a normal CV32E40X
verification project (OpenHW Group layout) plus a *software* Kalman coprocessor:

```
cv32e40x_kf_test/
  rtl/                      CV32E40X core RTL (cv32e40x_*.sv) + the soft coprocessor:
      cv32e40x_if_xif.sv       the XIF SystemVerilog interface definition
      kf_copro.v               soft single-opcode Kalman coprocessor (combinational datapath)
      xif_copro.sv             XIF wrapper; instantiates the coprocessor; carries cfgm_* ports
  tb/                       testbench: tb_top.sv, cv32e40x_tb_wrapper.sv, mm_ram.sv, dp_ram.sv
  sw/                       firmware: Makefile, kf/ (kf.c, trace.h), multiop/, bsp/, ...
  bitstreams/              pre-built eFPGA bitstreams (multiop demo) - we add kf_mul_ext here
  cv32e40x_manifest.flist  the file list compiled by ModelSim
  tools/                    helpers (bin2hex.py is added/used here)
```

Everything we add lands in `rtl/` (the new coprocessor + the fabric under `rtl/efpga/fabric_kf/`),
in `bitstreams/` (the KF bitstream), in `sw/` (perf measurement), plus three small edits to
`xif_copro.sv`, `cv32e40x_manifest.flist`, and `tb/tb_top.sv`. The FABulous fabric itself is built
in a **separate** project directory (we call it `efpga_kf`), then its generated `.v` files are
copied into `rtl/efpga/fabric_kf/`.

A handy scratch convention used below: keep unit-test benches and generated helpers in a
`_dbg/` folder inside the CV project so they never pollute the manifest.

> **Sandbox note that will save you hours:** run all `iverilog`/`vvp` simulations in the
> **foreground** with files kept **inside the project tree**, not in `/tmp` or an external scratch
> dir. Background jobs and `/tmp` can live on a different/ephemeral filesystem, which silently
> leaves stale compiled binaries and makes a passing test look like a hang. See Part 13.

---

## 3. Background: the Kalman filter and Q16.16 fixed point

We implement a textbook **constant-acceleration linear Kalman filter** with a 3-element state
`x = [position, velocity, acceleration]`, a scalar measurement (noisy altitude), and a 3x3
covariance `P`. One `kf_step(y)` performs the standard predict + update:

```
predict:  x  = F x                      F = [[1, dt, dt^2/2],[0,1,dt],[0,0,1]]
          P  = F P F^T + Q              Q = diag(Q00, Q11, Q22)
update:   S  = P00 + R                  (innovation covariance, scalar)
          K  = P[:,0] / S               (Kalman gain, 3x1; one reciprocal shared by all three)
          e  = y - x0                   (innovation)
          x  = x + K e
          P  = P - K P[0,:]
```

All arithmetic is **Q16.16 fixed point**: a 32-bit signed integer represents `value * 2^16`.
Multiply is `(a*b) >> 16`; divide is `(n << 16) / d`. Default model coefficients (these are the
values baked into the coprocessor and matched by the C):

| Symbol | Meaning | Q16.16 int | Real |
|---|---|---|---|
| DT | dt | 1311 | 0.02 (50 Hz) |
| DT2 | dt^2/2 | 13 | 0.0002 |
| R | measurement variance | 524288 | 8.0 |
| Q00 | process noise (pos) | 3277 | 0.05 |
| Q11 | process noise (vel) | 36045 | 0.55 |
| Q22 | process noise (acc) | 66 | 0.001 |
| P0 | initial covariance diag | 13107200 | 200.0 |

The single most important optimisation for hardware: the three Kalman gains
`K0 = P00/S, K1 = P10/S, K2 = P20/S` **share one division** - compute `recip = 1/S` once, then
`Ki = Pi0 * recip`. That turns three divides into one reciprocal plus three multiplies.

---

## 4. Fast hardware arithmetic

To beat software we need a fast multiply and a fast reciprocal.

### 4.1 Booth-Wallace multiplier (`mul_booth_wallace.v`)

Signed 32x32 -> 64 using radix-4 Booth recoding (17 partial products) and a Wallace 3:2
carry-save tree, fully combinational. The Q16.16 wrapper returns bits `[47:16]` of the product.
Create `rtl/mul_booth_wallace.v`:

_File: `rtl/mul_booth_wallace.v`_

```verilog
// =====================================================================================
// mul_booth_wallace.v  --  signed 32x32 -> 64 multiplier, radix-4 Booth + Wallace tree.
//
// This is the "fast multiply" custom primitive for the eFPGA KF coprocessor. Instead of
// letting the FPGA synthesise an unsigned shift-add array out of LUTs (huge + slow), this
// module is:
//   * radix-4 Booth encoded  -> 17 partial products instead of 32  (halves the rows)
//   * Wallace (carry-save) reduced -> log-depth 3:2 compression to two vectors
//   * one final carry-propagate add
// Purely combinational (single-cycle); register the I/O outside for pipelining/throughput.
//
//  qmul (Q16.16): result = (a*b) >>> 16  == p[47:16]  -- matches kf_copro.v fmul exactly.
// =====================================================================================
`default_nettype none

// ---- signed 32x32 -> 64 full product ----
module mul_booth_wallace (
    input  wire signed [31:0] a,
    input  wire signed [31:0] b,
    output wire signed [63:0] p
);
    // ---------------------------------------------------------------------------------
    // 1) operand multiples (sign-extended to 64 bits): a, 2a, and their negations
    // ---------------------------------------------------------------------------------
    wire [63:0] a64  = {{32{a[31]}}, a};                 //  a
    wire [63:0] a264 = {{31{a[31]}}, a, 1'b0};           //  2a  (a<<1, sign-extended)

    // ---------------------------------------------------------------------------------
    // 2) radix-4 Booth recoding -> 17 partial products
    //    group i looks at (b[2i+1], b[2i], b[2i-1]); b[-1]=0, b sign-extended at the top.
    //    B[0]=0 (=b[-1]); B[j]=b[j-1] for j>=1; top sign-extended so B has 35 bits.
    // ---------------------------------------------------------------------------------
    wire [34:0] B = {b[31], b[31], b, 1'b0};

    wire [63:0] pp [0:16];
    genvar i;
    generate
        for (i = 0; i < 17; i = i + 1) begin : PPG
            wire [2:0] sel = B[2*i+2 -: 3];              // {b[2i+1],b[2i],b[2i-1]}
            wire [63:0] base =
                (sel == 3'b001 || sel == 3'b010) ?  a64           :  // +1
                (sel == 3'b011)                  ?  a264          :  // +2
                (sel == 3'b100)                  ? (~a264 + 64'd1):  // -2
                (sel == 3'b101 || sel == 3'b110) ? (~a64  + 64'd1):  // -1
                                                    64'd0;           //  0
            assign pp[i] = base << (2*i);
        end
    endgenerate

    // ---------------------------------------------------------------------------------
    // 3) Wallace tree: 3:2 carry-save compressors, 17 -> 2 rows (carry pre-shifted <<1)
    // ---------------------------------------------------------------------------------
    `define CSA(S,C,X,Y,Z) \
        wire [63:0] S = (X) ^ (Y) ^ (Z); \
        wire [63:0] C = (((X)&(Y)) | ((X)&(Z)) | ((Y)&(Z))) << 1;

    // L1: 17 -> 12
    `CSA(s10,c10, pp[0],  pp[1],  pp[2])
    `CSA(s11,c11, pp[3],  pp[4],  pp[5])
    `CSA(s12,c12, pp[6],  pp[7],  pp[8])
    `CSA(s13,c13, pp[9],  pp[10], pp[11])
    `CSA(s14,c14, pp[12], pp[13], pp[14])
    // pass: pp[15], pp[16]
    // L2: 12 -> 8
    `CSA(s20,c20, s10, c10, s11)
    `CSA(s21,c21, c11, s12, c12)
    `CSA(s22,c22, s13, c13, s14)
    `CSA(s23,c23, c14, pp[15], pp[16])
    // L3: 8 -> 6
    `CSA(s30,c30, s20, c20, s21)
    `CSA(s31,c31, c21, s22, c22)
    // pass: s23, c23
    // L4: 6 -> 4
    `CSA(s40,c40, s30, c30, s31)
    `CSA(s41,c41, c31, s23, c23)
    // L5: 4 -> 3
    `CSA(s50,c50, s40, c40, s41)
    // pass: c41
    // L6: 3 -> 2
    `CSA(s60,c60, s50, c50, c41)

    `undef CSA

    // ---------------------------------------------------------------------------------
    // 4) final carry-propagate add
    // ---------------------------------------------------------------------------------
    assign p = s60 + c60;
endmodule

// ---- Q16.16 wrapper: (a*b) >>> 16, returned as 32-bit (matches kf_copro.v fmul) ----
module qmul_booth_wallace (
    input  wire signed [31:0] a,
    input  wire signed [31:0] b,
    output wire signed [31:0] q
);
    wire signed [63:0] p;
    mul_booth_wallace u_mul (.a(a), .b(b), .p(p));
    assign q = p[47:16];
endmodule

`default_nettype wire
```

Unit-test it against the native `*` operator (run in the project root, foreground):

```bash
cd cv32e40x_kf_test
cat > _dbg/tb_mul.sv <<'EOF'
`timescale 1ns/1ps
module tb_mul; reg signed [31:0] a,b; wire signed [63:0] p;
  mul_booth_wallace u(.a(a),.b(b),.p(p)); integer i,e;
  initial begin e=0; for(i=0;i<200000;i=i+1) begin a=$random; b=$random; #1;
    if(p!==a*b) e=e+1; end
    $display(e==0 ? "MUL: PASS" : "MUL: FAIL %0d", e); $finish; end
endmodule
EOF
iverilog -g2012 -s tb_mul -o _dbg/tb_mul.vvp rtl/mul_booth_wallace.v _dbg/tb_mul.sv
vvp _dbg/tb_mul.vvp        # -> MUL: PASS
```

### 4.2 Newton-Raphson reciprocal (used for the gains)

We do not divide three times; we compute one reciprocal `1/S` with Newton-Raphson
`x <- x*(2 - S*x)`, seeded `x0 = 1 << (31 - msb(S))` so that `S*x0` lands in `[0.5, 1)` and the
iteration converges monotonically. **Four iterations** reach the fixed-point reciprocal's
quantisation floor (iterations 4 and 5 are identical). In the coprocessor the reciprocal is folded
directly into the microprogram (it reuses the one shared multiplier), so there is no separate
divider module to instantiate - see the `RECIP` opcode and the `NR` state in Part 5.

The standalone divider that proves the algorithm (optional, for understanding) is
`div_nr.v` in the reference tree; the coprocessor uses the inline `NR` schedule instead.

---

## 5. The time-shared coprocessor (`kf_copro_ts`)

A fully combinational KF does ~24 multiplies and 3 divides in one clock - far too large/slow.
Instead we use **one shared multiplier** and a small **microcoded engine** that walks a fixed
56-microinstruction schedule (predict, update, and the inline Newton-Raphson reciprocal), keeping
all intermediates in a register array `Rg[0:34]`. This is `kf_copro_ts` ("time-shared").

Opcode map (R-type, custom-0 `0x0B`, funct3 = 0):
* `funct7 = 0` -> `kf_step` : `rd = filter(rs1)`
* `funct7 = 1` -> `kf_cfg`  : `coefficient[rs2] = rs1`

The microinstruction format is `{op[2:0], dst[5:0], a[5:0], b[5:0]}` with
`op in {MUL, MAC, MSUB, ADD, MOV, SUB, RECIP, HALT}`. The register map inside `Rg`:

```
Rg[0..2]  = state x (pos,vel,acc)         Rg[3..8]  = covariance P (P00,P01,P02,P11,P12,P22)
Rg[9..14] = DT,DT2,R,Q00,Q11,Q22          Rg[15..17]= predicted x (nx)
Rg[18..22]= gains/temporaries             Rg[23..28]= predicted P column terms
Rg[29]    = innovation e                  Rg[30]= S      Rg[31]= recip=1/S
Rg[32]    = measurement y                 Rg[33]= P0
```

Create `rtl/kf_copro_ts.v` (this is the golden model that all later versions are checked against):

_File: `rtl/kf_copro_ts.v`_

```verilog
// kf_copro_ts.v -- TIME-SHARED Kalman coprocessor for CV32E40X (the efficient eFPGA
// architecture: ONE shared Booth-Wallace multiplier + a 35-entry register array that maps to
// a hard RegFile/BRAM on silicon). Same single-opcode XIF interface as kf_copro (drop-in), but
// the full predict+update+NR-reciprocal step runs as a ~60-cycle microprogram instead of a
// huge combinational datapath. Output = denoised x0 (Q16.16). funct7=1 = kf_cfg run-time retune.
module kf_copro_ts #(
  parameter XLEN=32, parameter INPUT_BUFFER_DEPTH=1, parameter FORWARDING=1,
  parameter signed [31:0] DEF_DT=32'sd1311, DEF_DT2=32'sd13, DEF_R=32'sd524288,
  parameter signed [31:0] DEF_Q00=32'sd3277, DEF_Q01=0, DEF_Q02=0,
  parameter signed [31:0] DEF_Q11=32'sd36045, DEF_Q12=0, DEF_Q22=32'sd66,
  parameter signed [31:0] DEF_P0H=32'sd13107200, DEF_P0V=32'sd13107200, DEF_P0A=32'sd13107200
) (
  input  wire        clk_i,
  input  wire        rst_ni,
  input  wire        compressed_valid_i,
  output wire        compressed_ready_o,
  output wire [31:0] compressed_resp_instr_o,
  output wire        compressed_resp_accept_o,
  input  wire        issue_valid_i,
  output wire        issue_ready_o,
  input  wire [31:0] issue_req_instr_i,
  input  wire [1:0]  issue_req_mode_i,
  input  wire [3:0]  issue_req_id_i,
  input  wire [63:0] issue_req_rs_i,
  input  wire [1:0]  issue_req_rs_valid_i,
  output wire        issue_resp_accept_o,
  output wire        issue_resp_writeback_o,
  output wire        issue_resp_dualwrite_o,
  output wire [2:0]  issue_resp_dualread_o,
  output wire        issue_resp_loadstore_o,
  output wire        issue_resp_ecswrite_o,
  output wire        issue_resp_exc_o,
  input  wire        commit_valid_i,
  input  wire        commit_kill_i,
  input  wire [3:0]  commit_id_i,
  output wire        mem_valid_o,
  input  wire        mem_ready_i,
  output wire [3:0]  mem_req_id_o,
  output wire [1:0]  mem_req_mode_o,
  output wire        mem_req_we_o,
  output wire [2:0]  mem_req_size_o,
  output wire [3:0]  mem_req_be_o,
  output wire [1:0]  mem_req_attr_o,
  output wire [31:0] mem_req_wdata_o,
  output wire        mem_req_last_o,
  output wire        mem_req_spec_o,
  output wire [31:0] mem_req_addr_o,
  input  wire        mem_resp_exc_i,
  input  wire [5:0]  mem_resp_exccode_i,
  input  wire        mem_resp_dbg_i,
  input  wire        mem_result_valid_i,
  input  wire [31:0] mem_result_rdata_i,
  input  wire        mem_result_err_i,
  input  wire        mem_result_dbg_i,
  output wire        result_valid_o,
  input  wire        result_ready_i,
  output wire [3:0]  result_id_o,
  output wire [31:0] result_data_o,
  output wire [4:0]  result_rd_o,
  output wire        result_we_o,
  output wire [5:0]  result_ecsdata_o,
  output wire [2:0]  result_ecswe_o,
  output wire        result_exc_o,
  output wire [5:0]  result_exccode_o,
  output wire        result_err_o,
  output wire        result_dbg_o
);

  localparam MUL=0,MAC=1,MSUB=2,ADD=3,MOV=4,SUB=5,RECIP=6,HALT=7;
  localparam signed [31:0] TWO=32'sh00020000;
  reg signed [31:0] Rg[0:34];
  reg [6:0] pc; reg busy, done, computed, committed, first;
  reg signed [31:0] data_q; reg [3:0] id_q; reg [4:0] rd_q;
  reg [2:0] mode; reg [2:0] nrp; reg [2:0] nri; reg signed [31:0] nrx, nrt;
  localparam IDLE=0, RUN=1, NR=2;

  // decode (opcode 0x0B funct3=0; funct7 selects)
  wire ours=(issue_req_instr_i[6:0]==7'h0B)&(issue_req_instr_i[14:12]==3'b000);
  wire [6:0] f7=issue_req_instr_i[31:25];
  wire is_step=ours&(f7==0), is_cfg=ours&(f7==1), is_op=is_step|is_cfg;
  wire accept_hs=issue_valid_i & issue_ready_o & is_op;
  wire commit_hit=commit_valid_i & (commit_id_i==id_q);

  // microcode
  reg [20:0] uc;
  always @* begin
    case (pc)
      7'd0: uc={3'd4,6'd15,6'd0,6'd0};
      7'd1: uc={3'd1,6'd15,6'd9,6'd1};
      7'd2: uc={3'd1,6'd15,6'd10,6'd2};
      7'd3: uc={3'd4,6'd16,6'd1,6'd0};
      7'd4: uc={3'd1,6'd16,6'd9,6'd2};
      7'd5: uc={3'd4,6'd17,6'd2,6'd0};
      7'd6: uc={3'd4,6'd18,6'd3,6'd0};
      7'd7: uc={3'd1,6'd18,6'd9,6'd4};
      7'd8: uc={3'd1,6'd18,6'd10,6'd5};
      7'd9: uc={3'd4,6'd19,6'd4,6'd0};
      7'd10: uc={3'd1,6'd19,6'd9,6'd6};
      7'd11: uc={3'd1,6'd19,6'd10,6'd7};
      7'd12: uc={3'd4,6'd20,6'd5,6'd0};
      7'd13: uc={3'd1,6'd20,6'd9,6'd7};
      7'd14: uc={3'd1,6'd20,6'd10,6'd8};
      7'd15: uc={3'd4,6'd21,6'd6,6'd0};
      7'd16: uc={3'd1,6'd21,6'd9,6'd7};
      7'd17: uc={3'd4,6'd22,6'd7,6'd0};
      7'd18: uc={3'd1,6'd22,6'd9,6'd8};
      7'd19: uc={3'd4,6'd23,6'd18,6'd0};
      7'd20: uc={3'd1,6'd23,6'd9,6'd19};
      7'd21: uc={3'd1,6'd23,6'd10,6'd20};
      7'd22: uc={3'd3,6'd23,6'd23,6'd12};
      7'd23: uc={3'd4,6'd24,6'd19,6'd0};
      7'd24: uc={3'd1,6'd24,6'd9,6'd20};
      7'd25: uc={3'd4,6'd25,6'd20,6'd0};
      7'd26: uc={3'd4,6'd26,6'd21,6'd0};
      7'd27: uc={3'd1,6'd26,6'd9,6'd22};
      7'd28: uc={3'd3,6'd26,6'd26,6'd13};
      7'd29: uc={3'd4,6'd27,6'd22,6'd0};
      7'd30: uc={3'd3,6'd28,6'd8,6'd14};
      7'd31: uc={3'd5,6'd29,6'd32,6'd15};
      7'd32: uc={3'd3,6'd30,6'd23,6'd11};
      7'd33: uc={3'd6,6'd31,6'd30,6'd0};
      7'd34: uc={3'd0,6'd18,6'd23,6'd31};
      7'd35: uc={3'd0,6'd19,6'd24,6'd31};
      7'd36: uc={3'd0,6'd20,6'd25,6'd31};
      7'd37: uc={3'd4,6'd0,6'd15,6'd0};
      7'd38: uc={3'd1,6'd0,6'd18,6'd29};
      7'd39: uc={3'd4,6'd1,6'd16,6'd0};
      7'd40: uc={3'd1,6'd1,6'd19,6'd29};
      7'd41: uc={3'd4,6'd2,6'd17,6'd0};
      7'd42: uc={3'd1,6'd2,6'd20,6'd29};
      7'd43: uc={3'd4,6'd3,6'd23,6'd0};
      7'd44: uc={3'd2,6'd3,6'd18,6'd23};
      7'd45: uc={3'd4,6'd4,6'd24,6'd0};
      7'd46: uc={3'd2,6'd4,6'd18,6'd24};
      7'd47: uc={3'd4,6'd5,6'd25,6'd0};
      7'd48: uc={3'd2,6'd5,6'd18,6'd25};
      7'd49: uc={3'd4,6'd6,6'd26,6'd0};
      7'd50: uc={3'd2,6'd6,6'd19,6'd24};
      7'd51: uc={3'd4,6'd7,6'd27,6'd0};
      7'd52: uc={3'd2,6'd7,6'd19,6'd25};
      7'd53: uc={3'd4,6'd8,6'd28,6'd0};
      7'd54: uc={3'd2,6'd8,6'd20,6'd25};
      7'd55: uc={3'd7,6'd0,6'd0,6'd0};
      default: uc=21'd0;
    endcase
  end
  wire [2:0] op=uc[20:18]; wire [5:0] ud=uc[17:12], ua=uc[11:6], ub=uc[5:0];

  // ONE shared Booth-Wallace multiplier (operands muxed by mode/op)
  reg signed [31:0] mA, mB;
  always @* begin
    mA=Rg[ua]; mB=Rg[ub];
    if (mode==NR) begin
      if (nrp==2) begin mA=nrx;    mB=TWO-nrt; end  // x*(2-t)
      else        begin mA=Rg[ua]; mB=nrx;      end  // S*x
    end
  end
  wire signed [63:0] p64; mul_booth_wallace u_mul(.a(mA),.b(mB),.p(p64));
  wire signed [31:0] prod=p64[47:16];
  reg [5:0] msb; integer k;
  always @* begin msb=0; for(k=0;k<32;k=k+1) if(Rg[ua][k]) msb=k[5:0]; end

  assign issue_ready_o          = ~busy & (is_op ? (is_cfg ? (&issue_req_rs_valid_i[1:0]) : issue_req_rs_valid_i[0]) : 1'b1);
  assign issue_resp_accept_o=is_op; assign issue_resp_writeback_o=is_op;
  assign issue_resp_dualwrite_o=0; assign issue_resp_dualread_o=0; assign issue_resp_loadstore_o=0;
  assign issue_resp_ecswrite_o=0; assign issue_resp_exc_o=0;
  assign compressed_ready_o=compressed_valid_i; assign compressed_resp_instr_o=0; assign compressed_resp_accept_o=0;
  assign mem_valid_o=0; assign mem_req_id_o=0; assign mem_req_mode_o=0; assign mem_req_we_o=0;
  assign mem_req_size_o=0; assign mem_req_be_o=0; assign mem_req_attr_o=0; assign mem_req_wdata_o=0;
  assign mem_req_last_o=0; assign mem_req_spec_o=0; assign mem_req_addr_o=0;
  assign result_valid_o=done; assign result_id_o=id_q; assign result_data_o=data_q; assign result_rd_o=rd_q;
  assign result_we_o=1; assign result_ecsdata_o=0; assign result_ecswe_o=0; assign result_exc_o=0;
  assign result_exccode_o=0; assign result_err_o=0; assign result_dbg_o=0;

  integer j;
  always @(posedge clk_i) begin
    if (~rst_ni) begin
      busy<=0; done<=0; computed<=0; committed<=0; first<=1; mode<=IDLE;
      for (j=0;j<35;j=j+1) Rg[j]<=0;
      Rg[9]<=DEF_DT; Rg[10]<=DEF_DT2; Rg[11]<=DEF_R; Rg[12]<=DEF_Q00; Rg[13]<=DEF_Q11; Rg[14]<=DEF_Q22; Rg[33]<=DEF_P0H;
      data_q<=0; id_q<=0; rd_q<=0;
    end else begin
      if (done & result_ready_i) begin done<=0; busy<=0; computed<=0; committed<=0; end
      if (busy & commit_hit & commit_kill_i) begin busy<=0; mode<=IDLE; computed<=0; end
      else if (busy & commit_hit) committed<=1;

      if (accept_hs & ~busy) begin
        busy<=1; committed<=0; computed<=0; id_q<=issue_req_id_i; rd_q<=issue_req_instr_i[11:7];
        if (is_cfg) begin
          case (issue_req_rs_i[35:32])
            4'd0:Rg[11]<=issue_req_rs_i[31:0]; 4'd1:Rg[12]<=issue_req_rs_i[31:0];
            4'd4:Rg[13]<=issue_req_rs_i[31:0]; 4'd6:Rg[14]<=issue_req_rs_i[31:0];
            4'd10:Rg[9]<=issue_req_rs_i[31:0]; 4'd11:Rg[10]<=issue_req_rs_i[31:0];
            4'd7,4'd8,4'd9:Rg[33]<=issue_req_rs_i[31:0]; 4'd15:first<=1; default:;
          endcase
          data_q<=issue_req_rs_i[31:0]; computed<=1;
        end else if (first) begin
          Rg[0]<=issue_req_rs_i[31:0]; Rg[1]<=0; Rg[2]<=0;
          Rg[3]<=Rg[33]; Rg[4]<=0; Rg[5]<=0; Rg[6]<=Rg[33]; Rg[7]<=0; Rg[8]<=Rg[33];
          first<=0; data_q<=issue_req_rs_i[31:0]; computed<=1;
        end else begin
          Rg[32]<=issue_req_rs_i[31:0]; pc<=0; mode<=RUN;
        end
      end

      case (mode)
        RUN: case (op)
          MOV: begin Rg[ud]<=Rg[ua]; pc<=pc+1; end
          ADD: begin Rg[ud]<=Rg[ua]+Rg[ub]; pc<=pc+1; end
          SUB: begin Rg[ud]<=Rg[ua]-Rg[ub]; pc<=pc+1; end
          MUL: begin Rg[ud]<=prod; pc<=pc+1; end
          MAC: begin Rg[ud]<=Rg[ud]+prod; pc<=pc+1; end
          MSUB:begin Rg[ud]<=Rg[ud]-prod; pc<=pc+1; end
          RECIP: begin mode<=NR; nrp<=0; nri<=0; end
          default: begin data_q<=Rg[0]; computed<=1; mode<=IDLE; end // HALT
        endcase
        NR: case (nrp)
          0: begin nrx<=(32'sd1<<(6'd31-msb)); nrp<=1; end
          1: begin nrt<=prod; nrp<=2; end
          2: begin nrx<=prod; if(nri==3) nrp<=3; else begin nri<=nri+1; nrp<=1; end end
          3: begin Rg[ud]<=nrx; pc<=pc+1; mode<=RUN; end
        endcase
        default: ;
      endcase

      if (computed & committed & ~done) done<=1;
    end
  end
endmodule
```

Self-check `kf_copro_ts` against a known noisy trace. Create `tb_kfts.sv` (drives the XIF
issue/commit/result handshake) and run it; the per-step results below are the **golden values**
every later version must reproduce bit-for-bit:

```
expect: 69120357,69177744,69148605,69135372,69113786,69111906
  result=69120357   (init: first kf_step returns y and seeds the filter)
  result=69177744   (66 cycles/step)
  ...
```

Key handshake detail in the testbench `step` task (this exact timing matters - see Part 13.5):

```verilog
@(negedge clk); instr=32'h0000000B; rs={32'b0,y}; rsv=2'b01; id=id+1; issue_valid=1;
wait(issue_ready); @(negedge clk); issue_valid=0;
commit_valid=1; commit_id=id; @(negedge clk); commit_valid=0;
while(!result_valid) @(negedge clk);            // <-- exits on a negedge so result_ready
result=result_data; result_ready=1; @(negedge clk); result_ready=0;   //     lands before a posedge
```

---

## 6. The register-file coprocessor (`kf_copro_rf`) - making it fabric-shaped

`kf_copro_ts` keeps its registers in a flat `reg [31:0] Rg[0:34]` array, which a soft FPGA fabric
cannot host cheaply. The fabric-friendly version, `kf_copro_rf`, stores the array in **eight
`RegFile_32x4` tiles** (32 entries x 4 bits each = a 32 x 32-bit register file with two read ports
A/B and one write port). Three changes follow from "two read ports, one write port":

1. **`MAC`/`MSUB` become two-cycle.** A multiply-accumulate needs three reads (`a`, `b`, and the
   accumulator `dst`) but the RegFile has only two read ports. So cycle 1 computes
   `prod = mem[a]*mem[b]` and latches it; cycle 2 reads `mem[dst]` and writes
   `mem[dst] +/- prod`. (`MOV/ADD/SUB/MUL` stay one cycle.)
2. **Index 32 (`y`) moves to a soft register** `yreg`, because a 32-entry RegFile cannot hold
   index 32. Operand reads of index 32 are muxed from `yreg`.
3. **Two reset-time write sequences** replace the array's power-on values: an `INITC` FSM writes
   the 6 constants (DT..Q22 -> indices 9..14) and a `FINIT` FSM writes the 9 state words
   (indices 0..8) on the first `kf_step`. RegFiles power up at 0 and cannot be preset.

For simulation, the behavioural RegFile model (flattened ports, combinational read, registered
write) is `RegFile_soft.v`. In the *fabric*, the real `RegFile_32x4` tile is used instead; the
soft model is renamed to avoid a name clash with the fabric's tile (Part 9.4).

_File: `rtl/RegFile_soft.v (behavioural model; in the fabric this is a hard tile)`_

```verilog
module RegFile_soft(input D0,D1,D2,D3, input W_ADR0,W_ADR1,W_ADR2,W_ADR3,W_ADR4, input W_en,
  output AD0,AD1,AD2,AD3, input A_ADR0,A_ADR1,A_ADR2,A_ADR3,A_ADR4,
  output BD0,BD1,BD2,BD3, input B_ADR0,B_ADR1,B_ADR2,B_ADR3,B_ADR4, input CLK);
  reg [3:0] mem[0:31]; integer i; initial for(i=0;i<32;i=i+1) mem[i]=0;
  wire [4:0] wa={W_ADR4,W_ADR3,W_ADR2,W_ADR1,W_ADR0};
  wire [4:0] aa={A_ADR4,A_ADR3,A_ADR2,A_ADR1,A_ADR0};
  wire [4:0] ba={B_ADR4,B_ADR3,B_ADR2,B_ADR1,B_ADR0};
  always @(posedge CLK) if(W_en) mem[wa]<={D3,D2,D1,D0};
  assign {AD3,AD2,AD1,AD0}=mem[aa];
  assign {BD3,BD2,BD1,BD0}=mem[ba];
endmodule
```

`kf_copro_rf` produces the **same golden values** as `kf_copro_ts` at ~90 cycles/step (the extra
cycles are the two-cycle MACs). It is the basis for the fabric version in Part 8.

> Two bugs that bit during this step and that you must avoid (full story in Part 13):
> * `wadr = icnt[4:0]` where `icnt` is a 4-bit reg silently makes `wadr[4] = x` (out-of-range bit
>   select) - every `FINIT` write vanishes and the state reads back 0. Use `wadr = {1'b0, icnt}`.
> * The XIF issue handshake can race the `INITC` boot delay; the engine must be held in reset
>   until configuration finishes and the testbench/core must hold `issue_valid` until `issue_ready`
>   is sampled high at a posedge.

---

## 7. Building the FABulous eFPGA project from scratch

This is the heart of the project: a custom eFPGA whose DSP tile multiplies, exposed so the
coprocessor can use it. We build it in a *separate* project directory `efpga_kf`.

### 7.1 Why a custom tile - the two hard constraints

* **A 32x32 multiply does not fit the LUT fabric** (~1500 LUT4s for one multiplier), so it must be
  a **hard BEL** (a custom DSP tile), exactly like a real FPGA's DSP block.
* **The fabric's I/O and routing are narrow.** The default I/O tile and the auto-generated switch
  matrix carry only ~100-200 wires per tile, so an earlier "narrow" KFMUL serialised its 32-bit
  operands through a 16-bit port with an internal load/read FSM. **`synth_fabulous` in this
  toolchain folds any sequential user logic to constants**, so that FSM was optimised away and the
  configured fabric read back 0. (The multiop demo works only because its ops - bitrev/not/xor -
  are purely combinational.)

**The fix (from the FABulous manual, User Guide pp. 33/37):** ports marked
`(* FABulous, EXTERNAL *)` are **not** routed through the switch matrix - they are exported
straight to the top-level fabric wrapper `eFPGA_top`. So we give the KFMUL BEL **wide EXTERNAL**
operand/result ports (`A[31:0]`, `B[31:0]`, `Q[31:0]`). The multiply becomes wide and purely
combinational; the user_design has nothing sequential to fold; and the wide buses never burden the
switch matrix. The BEL's `OUT_reg` config bit optionally registers the product (a pipeline stage
for timing closure - see Part 14).

### 7.2 Create the project skeleton

```bash
cd /home/prasit/fabulous_self
export PATH="/home/prasit/.fabulous/oss-cad-suite/bin:/home/prasit/.local/share/uv/tools/fabulous-fpga/bin:$PATH"
FABulous create-project efpga_kf          # creates the skeleton + reference tiles
cd efpga_kf
```

`create-project` gives you the standard reference tiles under `Tile/` (`LUT4AB`, `W_IO`, the
`N_term_*/S_term_*` terminators, plus `DSP`, `RAM_IO`, `RegFile` examples) and the FABulous flow
scripts. We add one custom tile (`KFMUL`) and write our own `fabric.csv`.

### 7.3 The wide KFMUL DSP BEL

Create `Tile/KFMUL/KFMUL_DSP.v`. This is the combinational Booth-Wallace multiplier with **all
operand/result bits as flattened EXTERNAL ports**, plus a `UserCLK` (EXTERNAL, shared) and one
config bit `OUT_reg` (registers the product when set). The exact file:

_File: `Tile/KFMUL/KFMUL_DSP.v (wide, combinational, EXTERNAL ports)`_

```verilog
// KFMUL_DSP -- WIDE combinational 32x32 Q16.16 Booth-Wallace multiply BEL.
//   A[31:0], B[31:0] in, Q=(A*B)>>>16 out -- ALL ports EXTERNAL (bypass the switch matrix,
//   exported straight to eFPGA_top), so the user_design is purely combinational (nothing for
//   synth_fabulous to fold). ConfigBits[0]=OUT_reg pipelines Q (1 stage) to protect host fmax.
(* FABulous, BelMap,
OUT_reg=0
*)
module KFMUL_DSP #(parameter NoConfigBits = 1) (
    (* FABulous, EXTERNAL *) input  A0,
    (* FABulous, EXTERNAL *) input  A1,
    (* FABulous, EXTERNAL *) input  A2,
    (* FABulous, EXTERNAL *) input  A3,
    (* FABulous, EXTERNAL *) input  A4,
    (* FABulous, EXTERNAL *) input  A5,
    (* FABulous, EXTERNAL *) input  A6,
    (* FABulous, EXTERNAL *) input  A7,
    (* FABulous, EXTERNAL *) input  A8,
    (* FABulous, EXTERNAL *) input  A9,
    (* FABulous, EXTERNAL *) input  A10,
    (* FABulous, EXTERNAL *) input  A11,
    (* FABulous, EXTERNAL *) input  A12,
    (* FABulous, EXTERNAL *) input  A13,
    (* FABulous, EXTERNAL *) input  A14,
    (* FABulous, EXTERNAL *) input  A15,
    (* FABulous, EXTERNAL *) input  A16,
    (* FABulous, EXTERNAL *) input  A17,
    (* FABulous, EXTERNAL *) input  A18,
    (* FABulous, EXTERNAL *) input  A19,
    (* FABulous, EXTERNAL *) input  A20,
    (* FABulous, EXTERNAL *) input  A21,
    (* FABulous, EXTERNAL *) input  A22,
    (* FABulous, EXTERNAL *) input  A23,
    (* FABulous, EXTERNAL *) input  A24,
    (* FABulous, EXTERNAL *) input  A25,
    (* FABulous, EXTERNAL *) input  A26,
    (* FABulous, EXTERNAL *) input  A27,
    (* FABulous, EXTERNAL *) input  A28,
    (* FABulous, EXTERNAL *) input  A29,
    (* FABulous, EXTERNAL *) input  A30,
    (* FABulous, EXTERNAL *) input  A31,
    (* FABulous, EXTERNAL *) input  B0,
    (* FABulous, EXTERNAL *) input  B1,
    (* FABulous, EXTERNAL *) input  B2,
    (* FABulous, EXTERNAL *) input  B3,
    (* FABulous, EXTERNAL *) input  B4,
    (* FABulous, EXTERNAL *) input  B5,
    (* FABulous, EXTERNAL *) input  B6,
    (* FABulous, EXTERNAL *) input  B7,
    (* FABulous, EXTERNAL *) input  B8,
    (* FABulous, EXTERNAL *) input  B9,
    (* FABulous, EXTERNAL *) input  B10,
    (* FABulous, EXTERNAL *) input  B11,
    (* FABulous, EXTERNAL *) input  B12,
    (* FABulous, EXTERNAL *) input  B13,
    (* FABulous, EXTERNAL *) input  B14,
    (* FABulous, EXTERNAL *) input  B15,
    (* FABulous, EXTERNAL *) input  B16,
    (* FABulous, EXTERNAL *) input  B17,
    (* FABulous, EXTERNAL *) input  B18,
    (* FABulous, EXTERNAL *) input  B19,
    (* FABulous, EXTERNAL *) input  B20,
    (* FABulous, EXTERNAL *) input  B21,
    (* FABulous, EXTERNAL *) input  B22,
    (* FABulous, EXTERNAL *) input  B23,
    (* FABulous, EXTERNAL *) input  B24,
    (* FABulous, EXTERNAL *) input  B25,
    (* FABulous, EXTERNAL *) input  B26,
    (* FABulous, EXTERNAL *) input  B27,
    (* FABulous, EXTERNAL *) input  B28,
    (* FABulous, EXTERNAL *) input  B29,
    (* FABulous, EXTERNAL *) input  B30,
    (* FABulous, EXTERNAL *) input  B31,
    (* FABulous, EXTERNAL *) output  Q0,
    (* FABulous, EXTERNAL *) output  Q1,
    (* FABulous, EXTERNAL *) output  Q2,
    (* FABulous, EXTERNAL *) output  Q3,
    (* FABulous, EXTERNAL *) output  Q4,
    (* FABulous, EXTERNAL *) output  Q5,
    (* FABulous, EXTERNAL *) output  Q6,
    (* FABulous, EXTERNAL *) output  Q7,
    (* FABulous, EXTERNAL *) output  Q8,
    (* FABulous, EXTERNAL *) output  Q9,
    (* FABulous, EXTERNAL *) output  Q10,
    (* FABulous, EXTERNAL *) output  Q11,
    (* FABulous, EXTERNAL *) output  Q12,
    (* FABulous, EXTERNAL *) output  Q13,
    (* FABulous, EXTERNAL *) output  Q14,
    (* FABulous, EXTERNAL *) output  Q15,
    (* FABulous, EXTERNAL *) output  Q16,
    (* FABulous, EXTERNAL *) output  Q17,
    (* FABulous, EXTERNAL *) output  Q18,
    (* FABulous, EXTERNAL *) output  Q19,
    (* FABulous, EXTERNAL *) output  Q20,
    (* FABulous, EXTERNAL *) output  Q21,
    (* FABulous, EXTERNAL *) output  Q22,
    (* FABulous, EXTERNAL *) output  Q23,
    (* FABulous, EXTERNAL *) output  Q24,
    (* FABulous, EXTERNAL *) output  Q25,
    (* FABulous, EXTERNAL *) output  Q26,
    (* FABulous, EXTERNAL *) output  Q27,
    (* FABulous, EXTERNAL *) output  Q28,
    (* FABulous, EXTERNAL *) output  Q29,
    (* FABulous, EXTERNAL *) output  Q30,
    (* FABulous, EXTERNAL *) output  Q31,
    (* FABulous, EXTERNAL, SHARED_PORT *) input UserCLK,
    (* FABulous, GLOBAL *) input [NoConfigBits-1:0] ConfigBits
);
    function [63:0] bw_mul;
        input signed [31:0] a, b;
        integer i; reg [34:0] bb; reg [2:0] sel; reg signed [63:0] a64, a264, ppb, acc;
        begin
            a64  = {{32{a[31]}}, a};
            a264 = {{31{a[31]}}, a, 1'b0};
            bb   = {b[31], b[31], b, 1'b0};
            acc  = 64'd0;
            for (i = 0; i < 17; i = i + 1) begin
                sel = bb[2*i+2 -: 3];
                case (sel)
                    3'b001, 3'b010: ppb =  a64;
                    3'b011:         ppb =  a264;
                    3'b100:         ppb = -a264;
                    3'b101, 3'b110: ppb = -a64;
                    default:        ppb = 64'd0;
                endcase
                acc = acc + (ppb <<< (2*i));
            end
            bw_mul = acc;
        end
    endfunction
    wire signed [31:0] A = {A31,A30,A29,A28,A27,A26,A25,A24,A23,A22,A21,A20,A19,A18,A17,A16,A15,A14,A13,A12,A11,A10,A9,A8,A7,A6,A5,A4,A3,A2,A1,A0};
    wire signed [31:0] B = {B31,B30,B29,B28,B27,B26,B25,B24,B23,B22,B21,B20,B19,B18,B17,B16,B15,B14,B13,B12,B11,B10,B9,B8,B7,B6,B5,B4,B3,B2,B1,B0};
    wire signed [63:0] p = bw_mul(A, B);
    wire        [31:0] Qc = p[47:16];
    reg         [31:0] Qr;
    always @(posedge UserCLK) Qr <= Qc;
    wire        [31:0] Qo = ConfigBits[0] ? Qr : Qc;
    assign {Q31,Q30,Q29,Q28,Q27,Q26,Q25,Q24,Q23,Q22,Q21,Q20,Q19,Q18,Q17,Q16,Q15,Q14,Q13,Q12,Q11,Q10,Q9,Q8,Q7,Q6,Q5,Q4,Q3,Q2,Q1,Q0} = Qo;
endmodule
```

And the tile definition `Tile/KFMUL/KFMUL.csv` (a BEL plus an auto-generated switch matrix; the
EXTERNAL ports bypass that matrix so it only has to carry the single config bit):

_File: `Tile/KFMUL/KFMUL.csv`_

```text
TILE,KFMUL
INCLUDE,./../include/Base.csv
BEL,./KFMUL_DSP.v
MATRIX,GENERATE
EndTILE
```

### 7.4 The fabric floorplan (`fabric.csv`)

Write `fabric.csv`. The fabric is 8 rows by 8 columns: a West I/O column, some logic, a `RegFile`
column, the `KFMUL` column, and more logic, fenced by N/S terminators. Because each KFMUL tile
exports its own wide ports, having 8 KFMUL rows yields **8 independent 32x32 multipliers** (the
coprocessor uses one; the rest are spare for future parallelism). The exact file:

_File: `fabric.csv`_

```text
FabricBegin,,,,,,,,,,,,,,,,,,
NULL,N_term_single,N_term_single,N_term_single2,N_term_single,N_term_single,N_term_single,N_term_single,,#
W_IO,LUT4AB,LUT4AB,RegFile,KFMUL,LUT4AB,LUT4AB,LUT4AB,,#
W_IO,LUT4AB,LUT4AB,RegFile,KFMUL,LUT4AB,LUT4AB,LUT4AB,,#
W_IO,LUT4AB,LUT4AB,RegFile,KFMUL,LUT4AB,LUT4AB,LUT4AB,,#
W_IO,LUT4AB,LUT4AB,RegFile,KFMUL,LUT4AB,LUT4AB,LUT4AB,,#
W_IO,LUT4AB,LUT4AB,RegFile,KFMUL,LUT4AB,LUT4AB,LUT4AB,,#
W_IO,LUT4AB,LUT4AB,RegFile,KFMUL,LUT4AB,LUT4AB,LUT4AB,,#
W_IO,LUT4AB,LUT4AB,RegFile,KFMUL,LUT4AB,LUT4AB,LUT4AB,,#
W_IO,LUT4AB,LUT4AB,RegFile,KFMUL,LUT4AB,LUT4AB,LUT4AB,,#
NULL,S_term_single,S_term_single,S_term_single2,S_term_single,S_term_single,S_term_single,S_term_single,,#
FabricEnd,,,,,,,,,,,,,,,,,,

ParametersBegin,,,,,,,,,,,,,,,,,,
ConfigBitMode,frame_based,,,frame_based
GenerateDelayInSwitchMatrix,80
MultiplexerStyle,custom,#,custom
SuperTileEnable,FALSE,#,FALSE
Tile,./Tile/LUT4AB/LUT4AB.csv
Tile,./Tile/N_term_single/N_term_single.csv
Tile,./Tile/S_term_single/S_term_single.csv
Tile,./Tile/N_term_single2/N_term_single2.csv
Tile,./Tile/S_term_single2/S_term_single2.csv
Tile,./Tile/RegFile/RegFile.csv
Tile,./Tile/W_IO/W_IO.csv
Tile,./Tile/KFMUL/KFMUL.csv
ParametersEnd,,,,,,,,,,,,,,,,,,
```

### 7.5 Regenerate the fabric

The FABulous run script `FABulous.tcl` simply chains `load_fabric` and `run_FABulous_fabric`. Run
the fabric generation (with the correct PATH):

```bash
cd /home/prasit/fabulous_self/efpga_kf
export PATH="/home/prasit/.fabulous/oss-cad-suite/bin:/home/prasit/.local/share/uv/tools/fabulous-fpga/bin:$PATH"
FABulous -p . run "load_fabric; run_FABulous_fabric"
# -> ... "FABulous fabric flow complete"
```

> **Stale-artifact trap.** If you have previously generated a *different* KFMUL (e.g. the narrow
> one), FABulous reuses the existing `KFMUL_ConfigMem.csv` and dies with
> `bitstream mapping file ... has a bitmask mismatch; bitmask has in total 411 1-values for 369
> bits`. Delete the generated KFMUL artifacts and regenerate:
> ```bash
> rm -f Tile/KFMUL/KFMUL_ConfigMem.csv Tile/KFMUL/KFMUL_ConfigMem.v \
>       Tile/KFMUL/KFMUL_switch_matrix.v Tile/KFMUL/KFMUL_generated_switch_matrix.{csv,list}
> ```

Verify that `eFPGA_top` now exports the wide KFMUL ports - each is `[7:0]` because there are 8
KFMUL rows (bit `t` is row `Y(8-t)`):

```bash
grep -E 'input  \[7:0\] [AB][0-9]+|output  \[7:0\] Q[0-9]+' Fabric/eFPGA_top.v | head
# input  [7:0] A0 ... input [7:0] B0 ... output [7:0] Q0 ...
```

### 7.6 Build a bitstream

Because A/B/Q are EXTERNAL (driven by the coprocessor, not by fabric logic), the **user_design
carries no multiply logic** - the KFMUL is a hard tile that always works. The user_design only has
to be a valid, purely-combinational design so that synthesis produces a legal bitstream
(`OUT_reg` stays at its default 0 = combinational). A trivial pass-through suffices.

Create `user_design/kf_mul_ext.v`:

_File: `user_design/kf_mul_ext.v (pass-through; the multiply is the hard tile)`_

```verilog
// Minimal combinational user_design: the KFMUL multiply is a HARD tile driven via EXTERNAL
// A/B/Q ports, so the fabric LUT logic does nothing here. This just yields a valid bitstream
// (KFMUL OUT_reg stays at its default 0 = combinational).
module kf_mul_ext(input wire clk, input wire [15:0] io_in, output wire [15:0] io_out, output wire [15:0] io_oeb);
  assign io_out = io_in;        // pure wire pass-through (combinational, won't fold to const)
  assign io_oeb = 16'hFFFF;
endmodule
```

Then run the standard FABulous user-flow (wrap -> synth -> P&R -> bit_gen). The project's
`build_kf.sh` automates it with the four fixes baked in (oss-cad-suite first on PATH; manual
wrapper IO connection; `synth_fabulous` called directly so `-extra-plib custom_prims.v` is
included; relaxed nextpnr timing). The script:

_File: `build_kf.sh (FABulous user-design -> bitstream + gate sim)`_

```bash
#!/usr/bin/env bash
# reproducible FABulous build+sim with the 4 fixes baked in (see echoes below)
set -e
DESIGN="$1"; TOP="$2"; TB="$3"
PROJ="/home/prasit/fabulous_self/efpga_kf_self"
OCS="/home/prasit/.fabulous/oss-cad-suite"
FABBIN="/home/prasit/.local/share/uv/tools/fabulous-fpga/bin"
export PATH="$OCS/bin:$FABBIN:$PATH"             # FIX 1: oss-cad-suite first
cd "$PROJ"
echo "[build_kf] yosys=$(command -v yosys)  nextpnr=$(command -v nextpnr-generic)"

FABulous -p . run "load_fabric; gen_user_design_wrapper $DESIGN user_design/top_wrapper.v" >/tmp/bk_wrap.log 2>&1

# FIX 2: gen_user_design_wrapper leaves the user design's IO unconnected -> wire it up
python3 - "$TOP" <<'PY'
import sys
top=sys.argv[1]; p="user_design/top_wrapper.v"; s=open(p).read()
old=f"{top} user_design_i (.clk(clk), .io_in(), .io_out(), .io_oeb());"
new=(f"{top} user_design_i (.clk(clk),"
     " .io_in(IO_1_bidirectional_frame_config_pass_O),"
     " .io_out(IO_1_bidirectional_frame_config_pass_I),"
     " .io_oeb(IO_1_bidirectional_frame_config_pass_T));")
assert old in s, "[build_kf] wrapper IO line not found -- format changed?"
open(p,"w").write(s.replace(old,new)); print("[build_kf] wrapper IO connected")
PY

JSON="${DESIGN%.v}.json"; FASM="${DESIGN%.v}.fasm"; BIN="${DESIGN%.v}.bin"
# FIX 3: call synth_fabulous directly so -extra-plib custom_prims.v is included
yosys -p "synth_fabulous -top top_wrapper -json $JSON -lut 4 -extra-plib user_design/custom_prims.v -carry none" \
      user_design/top_wrapper.v "$DESIGN" >/tmp/bk_synth.log 2>&1
# FIX 4: relax nextpnr's 12 MHz target (Booth path is ~6-8 MHz here but functionally correct)
FAB_ROOT="$PROJ" nextpnr-generic --uarch fabulous --json "$JSON" -o fasm="$FASM" \
    --timing-allow-fail >/tmp/bk_pnr.log 2>&1
grep -iE 'Max frequency' /tmp/bk_pnr.log | tail -1
bit_gen -genBitstream "$FASM" .FABulous/bitStreamSpec.bin "$BIN" >/tmp/bk_bit.log 2>&1
echo "[build_kf] bitstream: $(wc -c < "$BIN") bytes"

# gate-level sim of the configured fabric
STAGE="$(mktemp -d)"
cp Fabric/*.v "$STAGE/"; find Tile -name '*.v' -exec cp -n {} "$STAGE/" \;
python3 - "$BIN" "$STAGE/bs.hex" <<'PY'
import sys
b=open(sys.argv[1],"rb").read()
open(sys.argv[2],"w").write("".join(f"{b[i]:02x}\n" if i<len(b) else "0\n" for i in range(16384)))
PY
iverilog -g2012 -s "${TOP}_tb" -o "$STAGE/tb.vvp" "$STAGE"/*.v "$TB"
vvp "$STAGE/tb.vvp" +bitstream_hex="$STAGE/bs.hex" | grep -iE 'SIM:|PASS|FAIL'
rm -rf "$STAGE"
```

Run just the bitstream steps manually if you prefer:

```bash
export PATH="/home/prasit/.fabulous/oss-cad-suite/bin:/home/prasit/.local/share/uv/tools/fabulous-fpga/bin:$PATH"
FABulous -p . run "load_fabric; gen_user_design_wrapper user_design/kf_mul_ext.v user_design/top_wrapper.v"
# connect the wrapper IO (FABulous leaves the custom design's io_* unconnected):
python3 - <<'PY'
p="user_design/top_wrapper.v"; s=open(p).read()
old="kf_mul_ext user_design_i (.clk(clk), .io_in(), .io_out(), .io_oeb());"
new=("kf_mul_ext user_design_i (.clk(clk), .io_in(IO_1_bidirectional_frame_config_pass_O),"
     " .io_out(IO_1_bidirectional_frame_config_pass_I), .io_oeb(IO_1_bidirectional_frame_config_pass_T));")
open(p,"w").write(s.replace(old,new))
PY
yosys -p "synth_fabulous -top top_wrapper -json user_design/kf_mul_ext.json -lut 4 \
          -extra-plib user_design/custom_prims.v -carry none" user_design/top_wrapper.v user_design/kf_mul_ext.v
FAB_ROOT="$PWD" nextpnr-generic --uarch fabulous --json user_design/kf_mul_ext.json \
          -o fasm=user_design/kf_mul_ext.fasm --timing-allow-fail
bit_gen -genBitstream user_design/kf_mul_ext.fasm .FABulous/bitStreamSpec.bin user_design/kf_mul_ext.bin
# -> user_design/kf_mul_ext.bin  (5784 bytes = 1446 config words)
```

### 7.7 Verify the configured-fabric multiply (the crucial proof)

Gate-simulate the *configured* fabric: load the bitstream into `eFPGA_top`, drive the KFMUL
tile-0 slice (`A_k[0], B_k[0]`), read `Q_k[0]`, and check `Q == (A*B)>>16`. The testbench
(`Test/kf_mul_ext_tb.v`, generated so the 96 wide-port connections are exact):

_File: `Test/kf_mul_ext_tb.v`_

```verilog
`timescale 1ps/1ps
module kf_mul_ext_tb;
  wire [15:0] I_top,T_top; reg [15:0] O_top=0; wire [31:0] A_cfg,B_cfg;
  reg CLK=0,resetn=1,SelfWriteStrobe=0; reg [31:0] SelfWriteData=0; reg Rx=1,s_clk=0,s_data=0;
  wire ComActive,ReceiveLED;
  reg signed [31:0] a=0,b=0; wire [31:0] q;
  wire [7:0] qv0; wire [7:0] qv1; wire [7:0] qv2; wire [7:0] qv3; wire [7:0] qv4; wire [7:0] qv5; wire [7:0] qv6; wire [7:0] qv7; wire [7:0] qv8; wire [7:0] qv9; wire [7:0] qv10; wire [7:0] qv11; wire [7:0] qv12; wire [7:0] qv13; wire [7:0] qv14; wire [7:0] qv15; wire [7:0] qv16; wire [7:0] qv17; wire [7:0] qv18; wire [7:0] qv19; wire [7:0] qv20; wire [7:0] qv21; wire [7:0] qv22; wire [7:0] qv23; wire [7:0] qv24; wire [7:0] qv25; wire [7:0] qv26; wire [7:0] qv27; wire [7:0] qv28; wire [7:0] qv29; wire [7:0] qv30; wire [7:0] qv31;
  eFPGA_top top_i(.I_top(I_top),.T_top(T_top),.O_top(O_top),.A_config_C(A_cfg),.B_config_C(B_cfg),
    .CLK(CLK),.resetn(resetn),.SelfWriteStrobe(SelfWriteStrobe),.SelfWriteData(SelfWriteData),
    .Rx(Rx),.ComActive(ComActive),.ReceiveLED(ReceiveLED),.s_clk(s_clk),.s_data(s_data),
    .A0({7'b0,a[0]}),
    .A1({7'b0,a[1]}),
    .A2({7'b0,a[2]}),
    .A3({7'b0,a[3]}),
    .A4({7'b0,a[4]}),
    .A5({7'b0,a[5]}),
    .A6({7'b0,a[6]}),
    .A7({7'b0,a[7]}),
    .A8({7'b0,a[8]}),
    .A9({7'b0,a[9]}),
    .A10({7'b0,a[10]}),
    .A11({7'b0,a[11]}),
    .A12({7'b0,a[12]}),
    .A13({7'b0,a[13]}),
    .A14({7'b0,a[14]}),
    .A15({7'b0,a[15]}),
    .A16({7'b0,a[16]}),
    .A17({7'b0,a[17]}),
    .A18({7'b0,a[18]}),
    .A19({7'b0,a[19]}),
    .A20({7'b0,a[20]}),
    .A21({7'b0,a[21]}),
    .A22({7'b0,a[22]}),
    .A23({7'b0,a[23]}),
    .A24({7'b0,a[24]}),
    .A25({7'b0,a[25]}),
    .A26({7'b0,a[26]}),
    .A27({7'b0,a[27]}),
    .A28({7'b0,a[28]}),
    .A29({7'b0,a[29]}),
    .A30({7'b0,a[30]}),
    .A31({7'b0,a[31]}),
    .B0({7'b0,b[0]}),
    .B1({7'b0,b[1]}),
    .B2({7'b0,b[2]}),
    .B3({7'b0,b[3]}),
    .B4({7'b0,b[4]}),
    .B5({7'b0,b[5]}),
    .B6({7'b0,b[6]}),
    .B7({7'b0,b[7]}),
    .B8({7'b0,b[8]}),
    .B9({7'b0,b[9]}),
    .B10({7'b0,b[10]}),
    .B11({7'b0,b[11]}),
    .B12({7'b0,b[12]}),
    .B13({7'b0,b[13]}),
    .B14({7'b0,b[14]}),
    .B15({7'b0,b[15]}),
    .B16({7'b0,b[16]}),
    .B17({7'b0,b[17]}),
    .B18({7'b0,b[18]}),
    .B19({7'b0,b[19]}),
    .B20({7'b0,b[20]}),
    .B21({7'b0,b[21]}),
    .B22({7'b0,b[22]}),
    .B23({7'b0,b[23]}),
    .B24({7'b0,b[24]}),
    .B25({7'b0,b[25]}),
    .B26({7'b0,b[26]}),
    .B27({7'b0,b[27]}),
    .B28({7'b0,b[28]}),
    .B29({7'b0,b[29]}),
    .B30({7'b0,b[30]}),
    .B31({7'b0,b[31]}),
    .Q0(qv0),
    .Q1(qv1),
    .Q2(qv2),
    .Q3(qv3),
    .Q4(qv4),
    .Q5(qv5),
    .Q6(qv6),
    .Q7(qv7),
    .Q8(qv8),
    .Q9(qv9),
    .Q10(qv10),
    .Q11(qv11),
    .Q12(qv12),
    .Q13(qv13),
    .Q14(qv14),
    .Q15(qv15),
    .Q16(qv16),
    .Q17(qv17),
    .Q18(qv18),
    .Q19(qv19),
    .Q20(qv20),
    .Q21(qv21),
    .Q22(qv22),
    .Q23(qv23),
    .Q24(qv24),
    .Q25(qv25),
    .Q26(qv26),
    .Q27(qv27),
    .Q28(qv28),
    .Q29(qv29),
    .Q30(qv30),
    .Q31(qv31));
  assign q[0]=qv0[0];
  assign q[1]=qv1[0];
  assign q[2]=qv2[0];
  assign q[3]=qv3[0];
  assign q[4]=qv4[0];
  assign q[5]=qv5[0];
  assign q[6]=qv6[0];
  assign q[7]=qv7[0];
  assign q[8]=qv8[0];
  assign q[9]=qv9[0];
  assign q[10]=qv10[0];
  assign q[11]=qv11[0];
  assign q[12]=qv12[0];
  assign q[13]=qv13[0];
  assign q[14]=qv14[0];
  assign q[15]=qv15[0];
  assign q[16]=qv16[0];
  assign q[17]=qv17[0];
  assign q[18]=qv18[0];
  assign q[19]=qv19[0];
  assign q[20]=qv20[0];
  assign q[21]=qv21[0];
  assign q[22]=qv22[0];
  assign q[23]=qv23[0];
  assign q[24]=qv24[0];
  assign q[25]=qv25[0];
  assign q[26]=qv26[0];
  assign q[27]=qv27[0];
  assign q[28]=qv28[0];
  assign q[29]=qv29[0];
  assign q[30]=qv30[0];
  assign q[31]=qv31[0];
  // golden reference (Booth Q16.16)
  function [31:0] gold; input signed [31:0] x,y; reg signed [63:0] p; begin p=x*y; gold=p[47:16]; end endfunction
  reg [7:0] bs[0:16383]; always #5000 CLK=(CLK===1'b0);
  integer i,errs; reg [2047:0] hx;
  task domul(input signed [31:0] x,y); begin a=x; b=y; #20000;
    if(q!==gold(x,y)) begin errs=errs+1; $display("  MUL FAIL a=%h b=%h got=%h exp=%h",x,y,q,gold(x,y)); end
    else $display("  ok %h * %h = %h", x, y, q); end endtask
  initial begin errs=0;
    if($value$plusargs("bitstream_hex=%s",hx)) $readmemh(hx,bs); else $fatal;
    #100; resetn=0; #10000; resetn=1; #10000; repeat(20)@(posedge CLK); #2500;
    for(i=0;i<5784;i=i+4) begin SelfWriteData<={bs[i],bs[i+1],bs[i+2],bs[i+3]};
      repeat(2)@(posedge CLK); SelfWriteStrobe<=1; @(posedge CLK); SelfWriteStrobe<=0; repeat(2)@(posedge CLK); end
    repeat(20)@(posedge CLK);
    domul(32'h0003_0000, 32'h0002_8000);  // 3.0 * 2.5 = 7.5 -> 0x0007_8000
    domul(32'h0001_0000, 32'h0001_0000);  // 1.0 * 1.0 = 1.0
    domul(32'h0002_0000, 32'h0004_0000);  // 2.0 * 4.0 = 8.0
    domul(32'hFFFF_0000, 32'h0002_0000);  // -1.0 * 2.0 = -2.0
    domul(32'h0000_8000, 32'h0000_8000);  // 0.5 * 0.5 = 0.25
    if(errs==0) $display("KFMUL-WIDE-eFPGA SIM: PASS - configured fabric multiplies via wide EXTERNAL KFMUL tile");
    else        $display("KFMUL-WIDE-eFPGA SIM: FAIL (%0d errors)",errs);
    $finish;
  end
endmodule
```

Run it (stage the fabric .v + tile .v, pad the bitstream to a 16384-line hex, simulate):

```bash
export PATH="/home/prasit/.fabulous/oss-cad-suite/bin:$PATH"
STAGE=$(mktemp -d); cp Fabric/*.v "$STAGE/"; find Tile -name '*.v' ! -name '*.bak' -exec cp -n {} "$STAGE/" \;
python3 -c "b=open('user_design/kf_mul_ext.bin','rb').read(); open('$STAGE/bs.hex','w').write(''.join('%02x\n'%(b[i] if i<len(b) else 0) for i in range(16384)))"
iverilog -g2012 -s kf_mul_ext_tb -o "$STAGE/tb.vvp" "$STAGE"/*.v Test/kf_mul_ext_tb.v
vvp "$STAGE/tb.vvp" +bitstream_hex="$STAGE/bs.hex"
# -> KFMUL-WIDE-eFPGA SIM: PASS - configured fabric multiplies via wide EXTERNAL KFMUL tile
```

If you see PASS, the eFPGA half is done: a real, configured FABulous fabric performs a 32x32
Q16.16 multiply driven entirely from outside.

---

## 8. The fabric-KFMUL coprocessor (`kf_copro_fab`)

`kf_copro_fab` = `kf_copro_rf` with the soft multiplier replaced by the configured fabric, plus an
**OBI master that streams the bitstream from system RAM** at boot. Three structural additions:

1. **`eFPGA_top` instance + KFMUL drive.** The engine's operands `mulA/mulB` drive the fabric's
   tile-0 slice (`A_k[0] = mulA[k]`, `B_k[0] = mulB[k]`), and the product is
   `prod = {Q31[0],...,Q0[0]}`. With `OUT_reg = 0` the product is combinational, so the engine's
   timing is identical to the soft version and it stays bit-exact.
2. **OBI config loader.** A small FSM issues OBI reads (`cfgm_req/gnt/addr/rvalid/rdata`) from
   `BITS_BASE`, capturing each 32-bit word into `SelfWriteData` and pulsing `SelfWriteStrobe`,
   for `NWORDS` words, then a short settle. `cfg_done` releases the engine. **The bitstream lives
   in RAM, not in the RTL**, so a different bitstream can be loaded on the same fabric at run time
   (the multiop-style reconfiguration mechanism).
3. **`kf_cfg`.** A `CFGWR` mode writes a coefficient into the RegFile (idx 0->R[11], 1->Q00[12],
   4->Q11[13], 6->Q22[14], 10->DT[9], 11->DT2[10]); P0 (idx 7/8/9) goes to a soft `p0reg` used by
   `FINIT`; idx 15 re-initialises the filter (`first<=1`).

The engine is **held in reset until `cfg_done`** (`eng_rst_n = rst_ni & cfg_done`) so it cannot
run against an unconfigured fabric. Create `rtl/kf_copro_fab.v`:

_File: `rtl/kf_copro_fab.v`_

```verilog
// kf_copro_fab.v -- kf_copro_rf with the multiply offloaded to the CONFIGURED eFPGA fabric.
// Instantiates eFPGA_top (wide EXTERNAL KFMUL tile), streams the bitstream at reset, and
// drives KFMUL tile-0 (A_k[0],B_k[0]) reading Q_k[0]=prod. OUT_reg=0 -> combinational mul
// (same timing as the soft mul, so the engine stays bit-exact). Engine held in reset until cfg_done.
// ORIG: time-shared KF coprocessor with the register file in HARD RegFile tiles
// (8x RegFile_32x4 = 32 entries x 32-bit, 2 read ports + 1 write). This is the fabric-fitting
// version of kf_copro_ts: the 35-entry array becomes RegFile tiles (index 32 = y kept in a soft
// reg; RegFile is 32 entries). MAC/MSUB are 2-cycle (RegFile has only 2 read ports). Same XIF.
module kf_copro_fab #(
  parameter XLEN=32, parameter INPUT_BUFFER_DEPTH=1, parameter FORWARDING=1,
  parameter signed [31:0] DEF_DT=32'sd1311, DEF_DT2=32'sd13, DEF_R=32'sd524288,
  parameter signed [31:0] DEF_Q00=32'sd3277, DEF_Q11=32'sd36045, DEF_Q22=32'sd66,
  parameter signed [31:0] DEF_P0=32'sd13107200,
  parameter [31:0] BITS_BASE=32'h0010_0000, parameter integer NWORDS=1446, parameter integer HOLD_CYCLES=16
) (
  input  wire clk_i, input wire rst_ni,
  // ---- OBI read master: streams the bitstream out of system RAM (multiop-style) ----
  output wire cfgm_req_o, input wire cfgm_gnt_i, output wire [31:0] cfgm_addr_o,
  input wire cfgm_rvalid_i, input wire [31:0] cfgm_rdata_i, output wire config_busy_o,
  input  wire compressed_valid_i, output wire compressed_ready_o,
  output wire [31:0] compressed_resp_instr_o, output wire compressed_resp_accept_o,
  input  wire issue_valid_i, output wire issue_ready_o, input wire [31:0] issue_req_instr_i,
  input  wire [1:0] issue_req_mode_i, input wire [3:0] issue_req_id_i, input wire [63:0] issue_req_rs_i,
  input  wire [1:0] issue_req_rs_valid_i, output wire issue_resp_accept_o, output wire issue_resp_writeback_o,
  output wire issue_resp_dualwrite_o, output wire [2:0] issue_resp_dualread_o, output wire issue_resp_loadstore_o,
  output wire issue_resp_ecswrite_o, output wire issue_resp_exc_o,
  input  wire commit_valid_i, input wire commit_kill_i, input wire [3:0] commit_id_i,
  output wire mem_valid_o, input wire mem_ready_i, output wire [3:0] mem_req_id_o, output wire [1:0] mem_req_mode_o,
  output wire mem_req_we_o, output wire [2:0] mem_req_size_o, output wire [3:0] mem_req_be_o, output wire [1:0] mem_req_attr_o,
  output wire [31:0] mem_req_wdata_o, output wire mem_req_last_o, output wire mem_req_spec_o, output wire [31:0] mem_req_addr_o,
  input  wire mem_resp_exc_i, input wire [5:0] mem_resp_exccode_i, input wire mem_resp_dbg_i,
  input  wire mem_result_valid_i, input wire [31:0] mem_result_rdata_i, input wire mem_result_err_i, input wire mem_result_dbg_i,
  output wire result_valid_o, input wire result_ready_i, output wire [3:0] result_id_o, output wire [31:0] result_data_o,
  output wire [4:0] result_rd_o, output wire result_we_o, output wire [5:0] result_ecsdata_o, output wire [2:0] result_ecswe_o,
  output wire result_exc_o, output wire [5:0] result_exccode_o, output wire result_err_o, output wire result_dbg_o
);
  localparam MUL=0,MAC=1,MSUB=2,ADD=3,MOV=4,SUB=5,RECIP=6,HALT=7;
  localparam signed [31:0] TWO=32'sh00020000;
  localparam IDLE=0,INITC=1,RUN=2,MAC2=3,NR=4,FINIT=5,CFGWR=6;

  // ---- 8x RegFile_32x4 = 32 x 32-bit, 2 read ports (A,B) + 1 write ----
  wire [31:0] ada, bdb; reg [31:0] wd; reg [4:0] aadr, badr, wadr; reg wen;
  RegFile_soft rf0(.D0(wd[0]),.D1(wd[1]),.D2(wd[2]),.D3(wd[3]),.W_ADR0(wadr[0]),.W_ADR1(wadr[1]),.W_ADR2(wadr[2]),.W_ADR3(wadr[3]),.W_ADR4(wadr[4]),.W_en(wen),.AD0(ada[0]),.AD1(ada[1]),.AD2(ada[2]),.AD3(ada[3]),.A_ADR0(aadr[0]),.A_ADR1(aadr[1]),.A_ADR2(aadr[2]),.A_ADR3(aadr[3]),.A_ADR4(aadr[4]),.BD0(bdb[0]),.BD1(bdb[1]),.BD2(bdb[2]),.BD3(bdb[3]),.B_ADR0(badr[0]),.B_ADR1(badr[1]),.B_ADR2(badr[2]),.B_ADR3(badr[3]),.B_ADR4(badr[4]),.CLK(clk_i));
  RegFile_soft rf1(.D0(wd[4]),.D1(wd[5]),.D2(wd[6]),.D3(wd[7]),.W_ADR0(wadr[0]),.W_ADR1(wadr[1]),.W_ADR2(wadr[2]),.W_ADR3(wadr[3]),.W_ADR4(wadr[4]),.W_en(wen),.AD0(ada[4]),.AD1(ada[5]),.AD2(ada[6]),.AD3(ada[7]),.A_ADR0(aadr[0]),.A_ADR1(aadr[1]),.A_ADR2(aadr[2]),.A_ADR3(aadr[3]),.A_ADR4(aadr[4]),.BD0(bdb[4]),.BD1(bdb[5]),.BD2(bdb[6]),.BD3(bdb[7]),.B_ADR0(badr[0]),.B_ADR1(badr[1]),.B_ADR2(badr[2]),.B_ADR3(badr[3]),.B_ADR4(badr[4]),.CLK(clk_i));
  RegFile_soft rf2(.D0(wd[8]),.D1(wd[9]),.D2(wd[10]),.D3(wd[11]),.W_ADR0(wadr[0]),.W_ADR1(wadr[1]),.W_ADR2(wadr[2]),.W_ADR3(wadr[3]),.W_ADR4(wadr[4]),.W_en(wen),.AD0(ada[8]),.AD1(ada[9]),.AD2(ada[10]),.AD3(ada[11]),.A_ADR0(aadr[0]),.A_ADR1(aadr[1]),.A_ADR2(aadr[2]),.A_ADR3(aadr[3]),.A_ADR4(aadr[4]),.BD0(bdb[8]),.BD1(bdb[9]),.BD2(bdb[10]),.BD3(bdb[11]),.B_ADR0(badr[0]),.B_ADR1(badr[1]),.B_ADR2(badr[2]),.B_ADR3(badr[3]),.B_ADR4(badr[4]),.CLK(clk_i));
  RegFile_soft rf3(.D0(wd[12]),.D1(wd[13]),.D2(wd[14]),.D3(wd[15]),.W_ADR0(wadr[0]),.W_ADR1(wadr[1]),.W_ADR2(wadr[2]),.W_ADR3(wadr[3]),.W_ADR4(wadr[4]),.W_en(wen),.AD0(ada[12]),.AD1(ada[13]),.AD2(ada[14]),.AD3(ada[15]),.A_ADR0(aadr[0]),.A_ADR1(aadr[1]),.A_ADR2(aadr[2]),.A_ADR3(aadr[3]),.A_ADR4(aadr[4]),.BD0(bdb[12]),.BD1(bdb[13]),.BD2(bdb[14]),.BD3(bdb[15]),.B_ADR0(badr[0]),.B_ADR1(badr[1]),.B_ADR2(badr[2]),.B_ADR3(badr[3]),.B_ADR4(badr[4]),.CLK(clk_i));
  RegFile_soft rf4(.D0(wd[16]),.D1(wd[17]),.D2(wd[18]),.D3(wd[19]),.W_ADR0(wadr[0]),.W_ADR1(wadr[1]),.W_ADR2(wadr[2]),.W_ADR3(wadr[3]),.W_ADR4(wadr[4]),.W_en(wen),.AD0(ada[16]),.AD1(ada[17]),.AD2(ada[18]),.AD3(ada[19]),.A_ADR0(aadr[0]),.A_ADR1(aadr[1]),.A_ADR2(aadr[2]),.A_ADR3(aadr[3]),.A_ADR4(aadr[4]),.BD0(bdb[16]),.BD1(bdb[17]),.BD2(bdb[18]),.BD3(bdb[19]),.B_ADR0(badr[0]),.B_ADR1(badr[1]),.B_ADR2(badr[2]),.B_ADR3(badr[3]),.B_ADR4(badr[4]),.CLK(clk_i));
  RegFile_soft rf5(.D0(wd[20]),.D1(wd[21]),.D2(wd[22]),.D3(wd[23]),.W_ADR0(wadr[0]),.W_ADR1(wadr[1]),.W_ADR2(wadr[2]),.W_ADR3(wadr[3]),.W_ADR4(wadr[4]),.W_en(wen),.AD0(ada[20]),.AD1(ada[21]),.AD2(ada[22]),.AD3(ada[23]),.A_ADR0(aadr[0]),.A_ADR1(aadr[1]),.A_ADR2(aadr[2]),.A_ADR3(aadr[3]),.A_ADR4(aadr[4]),.BD0(bdb[20]),.BD1(bdb[21]),.BD2(bdb[22]),.BD3(bdb[23]),.B_ADR0(badr[0]),.B_ADR1(badr[1]),.B_ADR2(badr[2]),.B_ADR3(badr[3]),.B_ADR4(badr[4]),.CLK(clk_i));
  RegFile_soft rf6(.D0(wd[24]),.D1(wd[25]),.D2(wd[26]),.D3(wd[27]),.W_ADR0(wadr[0]),.W_ADR1(wadr[1]),.W_ADR2(wadr[2]),.W_ADR3(wadr[3]),.W_ADR4(wadr[4]),.W_en(wen),.AD0(ada[24]),.AD1(ada[25]),.AD2(ada[26]),.AD3(ada[27]),.A_ADR0(aadr[0]),.A_ADR1(aadr[1]),.A_ADR2(aadr[2]),.A_ADR3(aadr[3]),.A_ADR4(aadr[4]),.BD0(bdb[24]),.BD1(bdb[25]),.BD2(bdb[26]),.BD3(bdb[27]),.B_ADR0(badr[0]),.B_ADR1(badr[1]),.B_ADR2(badr[2]),.B_ADR3(badr[3]),.B_ADR4(badr[4]),.CLK(clk_i));
  RegFile_soft rf7(.D0(wd[28]),.D1(wd[29]),.D2(wd[30]),.D3(wd[31]),.W_ADR0(wadr[0]),.W_ADR1(wadr[1]),.W_ADR2(wadr[2]),.W_ADR3(wadr[3]),.W_ADR4(wadr[4]),.W_en(wen),.AD0(ada[28]),.AD1(ada[29]),.AD2(ada[30]),.AD3(ada[31]),.A_ADR0(aadr[0]),.A_ADR1(aadr[1]),.A_ADR2(aadr[2]),.A_ADR3(aadr[3]),.A_ADR4(aadr[4]),.BD0(bdb[28]),.BD1(bdb[29]),.BD2(bdb[30]),.BD3(bdb[31]),.B_ADR0(badr[0]),.B_ADR1(badr[1]),.B_ADR2(badr[2]),.B_ADR3(badr[3]),.B_ADR4(badr[4]),.CLK(clk_i));

  reg signed [31:0] yreg, prodreg, nrx, nrt;
  reg signed [31:0] p0reg, cfgval; reg [4:0] cfgwadr;        // kf_cfg: P0 + coeff write
  wire [3:0] cfg_idx = issue_req_rs_i[35:32];                // kf_cfg index = rs2[3:0]
  function [4:0] cfgmap; input [3:0] i; case (i)
    4'd0:cfgmap=5'd11; 4'd1:cfgmap=5'd12; 4'd4:cfgmap=5'd13;
    4'd6:cfgmap=5'd14; 4'd10:cfgmap=5'd9; 4'd11:cfgmap=5'd10; default:cfgmap=5'd0; endcase endfunction
  reg [6:0] pc; reg [2:0] mode, nrp, nri; reg [3:0] icnt;
  reg busy, done, computed, committed, first; reg [3:0] id_q; reg [4:0] rd_q; reg [31:0] data_q;

  // microcode
  reg [20:0] uc;
  always @* begin
    case (pc)
      7'd0: uc={3'd4,6'd15,6'd0,6'd0};
      7'd1: uc={3'd1,6'd15,6'd9,6'd1};
      7'd2: uc={3'd1,6'd15,6'd10,6'd2};
      7'd3: uc={3'd4,6'd16,6'd1,6'd0};
      7'd4: uc={3'd1,6'd16,6'd9,6'd2};
      7'd5: uc={3'd4,6'd17,6'd2,6'd0};
      7'd6: uc={3'd4,6'd18,6'd3,6'd0};
      7'd7: uc={3'd1,6'd18,6'd9,6'd4};
      7'd8: uc={3'd1,6'd18,6'd10,6'd5};
      7'd9: uc={3'd4,6'd19,6'd4,6'd0};
      7'd10: uc={3'd1,6'd19,6'd9,6'd6};
      7'd11: uc={3'd1,6'd19,6'd10,6'd7};
      7'd12: uc={3'd4,6'd20,6'd5,6'd0};
      7'd13: uc={3'd1,6'd20,6'd9,6'd7};
      7'd14: uc={3'd1,6'd20,6'd10,6'd8};
      7'd15: uc={3'd4,6'd21,6'd6,6'd0};
      7'd16: uc={3'd1,6'd21,6'd9,6'd7};
      7'd17: uc={3'd4,6'd22,6'd7,6'd0};
      7'd18: uc={3'd1,6'd22,6'd9,6'd8};
      7'd19: uc={3'd4,6'd23,6'd18,6'd0};
      7'd20: uc={3'd1,6'd23,6'd9,6'd19};
      7'd21: uc={3'd1,6'd23,6'd10,6'd20};
      7'd22: uc={3'd3,6'd23,6'd23,6'd12};
      7'd23: uc={3'd4,6'd24,6'd19,6'd0};
      7'd24: uc={3'd1,6'd24,6'd9,6'd20};
      7'd25: uc={3'd4,6'd25,6'd20,6'd0};
      7'd26: uc={3'd4,6'd26,6'd21,6'd0};
      7'd27: uc={3'd1,6'd26,6'd9,6'd22};
      7'd28: uc={3'd3,6'd26,6'd26,6'd13};
      7'd29: uc={3'd4,6'd27,6'd22,6'd0};
      7'd30: uc={3'd3,6'd28,6'd8,6'd14};
      7'd31: uc={3'd5,6'd29,6'd32,6'd15};
      7'd32: uc={3'd3,6'd30,6'd23,6'd11};
      7'd33: uc={3'd6,6'd31,6'd30,6'd0};
      7'd34: uc={3'd0,6'd18,6'd23,6'd31};
      7'd35: uc={3'd0,6'd19,6'd24,6'd31};
      7'd36: uc={3'd0,6'd20,6'd25,6'd31};
      7'd37: uc={3'd4,6'd0,6'd15,6'd0};
      7'd38: uc={3'd1,6'd0,6'd18,6'd29};
      7'd39: uc={3'd4,6'd1,6'd16,6'd0};
      7'd40: uc={3'd1,6'd1,6'd19,6'd29};
      7'd41: uc={3'd4,6'd2,6'd17,6'd0};
      7'd42: uc={3'd1,6'd2,6'd20,6'd29};
      7'd43: uc={3'd4,6'd3,6'd23,6'd0};
      7'd44: uc={3'd2,6'd3,6'd18,6'd23};
      7'd45: uc={3'd4,6'd4,6'd24,6'd0};
      7'd46: uc={3'd2,6'd4,6'd18,6'd24};
      7'd47: uc={3'd4,6'd5,6'd25,6'd0};
      7'd48: uc={3'd2,6'd5,6'd18,6'd25};
      7'd49: uc={3'd4,6'd6,6'd26,6'd0};
      7'd50: uc={3'd2,6'd6,6'd19,6'd24};
      7'd51: uc={3'd4,6'd7,6'd27,6'd0};
      7'd52: uc={3'd2,6'd7,6'd19,6'd25};
      7'd53: uc={3'd4,6'd8,6'd28,6'd0};
      7'd54: uc={3'd2,6'd8,6'd20,6'd25};
      7'd55: uc={3'd7,6'd0,6'd0,6'd0};
      default: uc=21'd0;
    endcase
  end
  wire [2:0] op=uc[20:18]; wire [5:0] ud=uc[17:12], ua=uc[11:6], ub=uc[5:0];

  // operands (RegFile combinational read; index 32 = y soft reg). NR uses soft nrx/nrt.
  wire signed [31:0] opA = (ua==6'd32) ? yreg : ada;
  wire signed [31:0] opB = (ub==6'd32) ? yreg : bdb;
  reg  signed [31:0] mulA, mulB;
  always @* begin
    if (mode==NR) begin
      if (nrp==2) begin mulA=nrx; mulB=TWO-nrt; end else begin mulA=(ua==6'd32)?yreg:ada; mulB=nrx; end
    end else begin mulA=opA; mulB=opB; end
  end
  // ---- multiply offloaded to the CONFIGURED eFPGA fabric (wide EXTERNAL KFMUL, tile-0 slice) ----
  wire [7:0] qv0; wire [7:0] qv1; wire [7:0] qv2; wire [7:0] qv3; wire [7:0] qv4; wire [7:0] qv5; wire [7:0] qv6; wire [7:0] qv7; wire [7:0] qv8; wire [7:0] qv9; wire [7:0] qv10; wire [7:0] qv11; wire [7:0] qv12; wire [7:0] qv13; wire [7:0] qv14; wire [7:0] qv15; wire [7:0] qv16; wire [7:0] qv17; wire [7:0] qv18; wire [7:0] qv19; wire [7:0] qv20; wire [7:0] qv21; wire [7:0] qv22; wire [7:0] qv23; wire [7:0] qv24; wire [7:0] qv25; wire [7:0] qv26; wire [7:0] qv27; wire [7:0] qv28; wire [7:0] qv29; wire [7:0] qv30; wire [7:0] qv31;
  wire signed [31:0] prod = {qv31[0],qv30[0],qv29[0],qv28[0],qv27[0],qv26[0],qv25[0],qv24[0],qv23[0],qv22[0],qv21[0],qv20[0],qv19[0],qv18[0],qv17[0],qv16[0],qv15[0],qv14[0],qv13[0],qv12[0],qv11[0],qv10[0],qv9[0],qv8[0],qv7[0],qv6[0],qv5[0],qv4[0],qv3[0],qv2[0],qv1[0],qv0[0]};
  reg [31:0] swdata; reg swstrobe; wire [15:0] fab_itop, fab_ttop; wire [31:0] fab_acfg, fab_bcfg; wire fab_ca, fab_rl;
  eFPGA_top fab (
    .I_top(fab_itop), .T_top(fab_ttop), .O_top(16'h0000), .A_config_C(fab_acfg), .B_config_C(fab_bcfg),
    .CLK(clk_i), .resetn(rst_ni), .SelfWriteStrobe(swstrobe), .SelfWriteData(swdata),
    .Rx(1'b1), .ComActive(fab_ca), .ReceiveLED(fab_rl), .s_clk(1'b0), .s_data(1'b0),
    .A0({7'b0,mulA[0]}), .A1({7'b0,mulA[1]}), .A2({7'b0,mulA[2]}), .A3({7'b0,mulA[3]}), .A4({7'b0,mulA[4]}), .A5({7'b0,mulA[5]}), .A6({7'b0,mulA[6]}), .A7({7'b0,mulA[7]}), .A8({7'b0,mulA[8]}), .A9({7'b0,mulA[9]}), .A10({7'b0,mulA[10]}), .A11({7'b0,mulA[11]}), .A12({7'b0,mulA[12]}), .A13({7'b0,mulA[13]}), .A14({7'b0,mulA[14]}), .A15({7'b0,mulA[15]}), .A16({7'b0,mulA[16]}), .A17({7'b0,mulA[17]}), .A18({7'b0,mulA[18]}), .A19({7'b0,mulA[19]}), .A20({7'b0,mulA[20]}), .A21({7'b0,mulA[21]}), .A22({7'b0,mulA[22]}), .A23({7'b0,mulA[23]}), .A24({7'b0,mulA[24]}), .A25({7'b0,mulA[25]}), .A26({7'b0,mulA[26]}), .A27({7'b0,mulA[27]}), .A28({7'b0,mulA[28]}), .A29({7'b0,mulA[29]}), .A30({7'b0,mulA[30]}), .A31({7'b0,mulA[31]}),
    .B0({7'b0,mulB[0]}), .B1({7'b0,mulB[1]}), .B2({7'b0,mulB[2]}), .B3({7'b0,mulB[3]}), .B4({7'b0,mulB[4]}), .B5({7'b0,mulB[5]}), .B6({7'b0,mulB[6]}), .B7({7'b0,mulB[7]}), .B8({7'b0,mulB[8]}), .B9({7'b0,mulB[9]}), .B10({7'b0,mulB[10]}), .B11({7'b0,mulB[11]}), .B12({7'b0,mulB[12]}), .B13({7'b0,mulB[13]}), .B14({7'b0,mulB[14]}), .B15({7'b0,mulB[15]}), .B16({7'b0,mulB[16]}), .B17({7'b0,mulB[17]}), .B18({7'b0,mulB[18]}), .B19({7'b0,mulB[19]}), .B20({7'b0,mulB[20]}), .B21({7'b0,mulB[21]}), .B22({7'b0,mulB[22]}), .B23({7'b0,mulB[23]}), .B24({7'b0,mulB[24]}), .B25({7'b0,mulB[25]}), .B26({7'b0,mulB[26]}), .B27({7'b0,mulB[27]}), .B28({7'b0,mulB[28]}), .B29({7'b0,mulB[29]}), .B30({7'b0,mulB[30]}), .B31({7'b0,mulB[31]}),
    .Q0(qv0), .Q1(qv1), .Q2(qv2), .Q3(qv3), .Q4(qv4), .Q5(qv5), .Q6(qv6), .Q7(qv7), .Q8(qv8), .Q9(qv9), .Q10(qv10), .Q11(qv11), .Q12(qv12), .Q13(qv13), .Q14(qv14), .Q15(qv15), .Q16(qv16), .Q17(qv17), .Q18(qv18), .Q19(qv19), .Q20(qv20), .Q21(qv21), .Q22(qv22), .Q23(qv23), .Q24(qv24), .Q25(qv25), .Q26(qv26), .Q27(qv27), .Q28(qv28), .Q29(qv29), .Q30(qv30), .Q31(qv31));
  // ---- config loader: OBI master streams the bitstream from system RAM at BITS_BASE ----
  // (multiop-style: bitstream lives in RAM, loaded by tb_top; lets a different bitstream be
  //  loaded on the same fabric at runtime instead of a fixed ROM baked into the coprocessor.)
  localparam FP_REQ=3'd0, FP_WAIT=3'd1, FP_SET=3'd2, FP_STR=3'd3, FP_NXT=3'd4, FP_HOLD=3'd5;
  reg cfg_done; reg [15:0] widx; reg [2:0] fp; reg [7:0] holdc;
  assign cfgm_req_o  = (~cfg_done) & (fp==FP_REQ);
  assign cfgm_addr_o = BITS_BASE + (widx << 2);
  assign config_busy_o = ~cfg_done;
  always @(posedge clk_i) begin
    if (~rst_ni) begin cfg_done<=1'b0; widx<=16'd0; fp<=FP_REQ; holdc<=8'd0; swdata<=32'd0; swstrobe<=1'b0; end
    else if (~cfg_done) begin
      swstrobe <= 1'b0;
      case (fp)
        FP_REQ:  if (cfgm_gnt_i)    fp<=FP_WAIT;                       // address phase accepted
        FP_WAIT: if (cfgm_rvalid_i) begin swdata<=cfgm_rdata_i; fp<=FP_SET; end  // capture config word
        FP_SET:  fp<=FP_STR;                                          // let data settle
        FP_STR:  begin swstrobe<=1'b1; fp<=FP_NXT; end                // 1-cycle SelfWriteStrobe
        FP_NXT:  if (widx==NWORDS-1) begin holdc<=8'd0; fp<=FP_HOLD; end
                 else begin widx<=widx+16'd1; fp<=FP_REQ; end
        FP_HOLD: if (holdc>=HOLD_CYCLES[7:0]) cfg_done<=1'b1; else holdc<=holdc+8'd1;  // settle
        default: fp<=FP_REQ;
      endcase
    end
  end
  wire eng_rst_n = rst_ni & cfg_done;   // hold the KF engine in reset until the fabric is configured
  reg [5:0] msb; integer k;
  always @* begin msb=0; for(k=0;k<32;k=k+1) if(ada[k]) msb=k[5:0]; end

  // decode
  wire ours=(issue_req_instr_i[6:0]==7'h0B)&(issue_req_instr_i[14:12]==3'b000);
  wire [6:0] f7=issue_req_instr_i[31:25]; wire is_step=ours&(f7==0), is_cfg=ours&(f7==1), is_op=is_step|is_cfg;
  wire accept_hs=issue_valid_i & issue_ready_o & is_op;
  wire commit_hit=commit_valid_i & (commit_id_i==id_q);
  wire rdy = (mode==IDLE) & ~busy;

  // ---- ADDRESSES + write-enable: depend ONLY on control (no ada/opA/prod) -> breaks comb loop ----
  always @* begin
    aadr=ua[4:0]; badr=ub[4:0]; wadr=ud[4:0]; wen=1'b0;
    case (mode)
      INITC: begin wen=1'b1; case (icnt) 0:wadr=9; 1:wadr=10; 2:wadr=11; 3:wadr=12; 4:wadr=13; 5:wadr=14; default: wen=1'b0; endcase end
      FINIT: begin wen=1'b1; wadr={1'b0,icnt}; end                    // icnt 0..8 -> state regs 0..8
      RUN:   case (op) MOV,ADD,SUB,MUL: wen=1'b1; default: ; endcase   // MAC/MSUB write in MAC2
      MAC2:  begin aadr=ud[4:0]; wadr=ud[4:0]; wen=1'b1; end           // read+write the accumulator
      CFGWR: begin wadr=cfgwadr; wen=1'b1; end                          // kf_cfg coeff write
      NR:    if (nrp==3) begin wadr=ud[4:0]; wen=1'b1; end             // write recip
      default: ;
    endcase
  end
  // ---- WRITE DATA: reads ada/opA/prod but never drives aadr -> the cycle is broken ----
  always @* begin
    wd=32'd0;
    case (mode)
      INITC: case (icnt) 0:wd=DEF_DT;1:wd=DEF_DT2;2:wd=DEF_R;3:wd=DEF_Q00;4:wd=DEF_Q11;5:wd=DEF_Q22; default: wd=32'd0; endcase
      FINIT: case (icnt) 0:wd=yreg; 3:wd=p0reg; 6:wd=p0reg; 8:wd=p0reg; default: wd=32'd0; endcase
      RUN:   case (op) MOV:wd=opA; ADD:wd=opA+opB; SUB:wd=opA-opB; MUL:wd=prod; default: wd=32'd0; endcase
      MAC2:  wd = (op==MAC) ? (ada + prodreg) : (ada - prodreg);
      CFGWR: wd = cfgval;
      NR:    wd = nrx;
      default: wd=32'd0;
    endcase
  end

  assign issue_ready_o = rdy & (is_op ? (is_cfg ? (&issue_req_rs_valid_i[1:0]) : issue_req_rs_valid_i[0]) : 1'b1);
  assign issue_resp_accept_o=is_op; assign issue_resp_writeback_o=is_op;
  assign issue_resp_dualwrite_o=0; assign issue_resp_dualread_o=0; assign issue_resp_loadstore_o=0;
  assign issue_resp_ecswrite_o=0; assign issue_resp_exc_o=0;
  assign compressed_ready_o=compressed_valid_i; assign compressed_resp_instr_o=0; assign compressed_resp_accept_o=0;
  assign mem_valid_o=0; assign mem_req_id_o=0; assign mem_req_mode_o=0; assign mem_req_we_o=0; assign mem_req_size_o=0;
  assign mem_req_be_o=0; assign mem_req_attr_o=0; assign mem_req_wdata_o=0; assign mem_req_last_o=0; assign mem_req_spec_o=0; assign mem_req_addr_o=0;
  assign result_valid_o=done; assign result_id_o=id_q; assign result_data_o=data_q; assign result_rd_o=rd_q;
  assign result_we_o=1'b1; assign result_ecsdata_o=0; assign result_ecswe_o=0; assign result_exc_o=0; assign result_exccode_o=0; assign result_err_o=0; assign result_dbg_o=0;

  always @(posedge clk_i) begin
    if (~eng_rst_n) begin
      mode<=INITC; icnt<=0; pc<=0; busy<=0; done<=0; computed<=0; committed<=0; first<=1; p0reg<=DEF_P0;
      yreg<=0; prodreg<=0; nrx<=0; nrt<=0; nrp<=0; nri<=0; id_q<=0; rd_q<=0; data_q<=0;
    end else begin
      // ---- XIF handshake: runs EVERY cycle (not gated by the compute FSM) ----
      if (done & result_ready_i) begin done<=0; busy<=0; computed<=0; committed<=0; end
      if (busy & commit_hit) committed<=1;
      if (accept_hs & ~busy) begin
        busy<=1; computed<=0; committed<=0; id_q<=issue_req_id_i; rd_q<=issue_req_instr_i[11:7];
        if (is_cfg) begin data_q<=issue_req_rs_i[31:0];
          case (cfg_idx)
            4'd15: begin first<=1'b1; computed<=1; end                              // re-init filter
            4'd7,4'd8,4'd9: begin p0reg<=issue_req_rs_i[31:0]; computed<=1; end      // P0 diagonal
            default: begin cfgval<=issue_req_rs_i[31:0]; cfgwadr<=cfgmap(cfg_idx); mode<=CFGWR; end // R/Q/DT
          endcase end
        else if (first) begin yreg<=issue_req_rs_i[31:0]; data_q<=issue_req_rs_i[31:0]; first<=0; icnt<=0; mode<=FINIT; end
        else begin yreg<=issue_req_rs_i[31:0]; pc<=0; mode<=RUN; end
      end
      // ---- compute FSM ----
      case (mode)
        INITC: if (icnt==5) begin mode<=IDLE; icnt<=0; end else icnt<=icnt+1;
        FINIT: if (icnt==8) begin computed<=1; mode<=IDLE; end else icnt<=icnt+1;
        RUN: case (op)
          MOV,ADD,SUB,MUL: pc<=pc+1;
          MAC,MSUB: begin prodreg<=prod; mode<=MAC2; end
          RECIP: begin mode<=NR; nrp<=0; nri<=0; end
          default: begin data_q<=ada; computed<=1; mode<=IDLE; end // HALT: ada=mem[0]=new x0
        endcase
        MAC2: begin mode<=RUN; pc<=pc+1; end
        CFGWR: begin computed<=1; mode<=IDLE; end
        NR: case (nrp)
          0: begin nrx<=(32'sd1<<(6'd31-msb)); nrp<=1; end
          1: begin nrt<=prod; nrp<=2; end
          2: begin nrx<=prod; if(nri==3) nrp<=3; else begin nri<=nri+1; nrp<=1; end end
          3: begin mode<=RUN; pc<=pc+1; end
        endcase
        default: ; // IDLE
      endcase
      // ---- result ready when computed AND committed ----
      if (computed & committed & ~done) done<=1;
    end
  end
endmodule
```

### 8.1 Standalone verification (OBI config + kf_step + kf_cfg)

Before touching the SoC, verify `kf_copro_fab` with a tiny OBI memory model that serves the
bitstream words and the full fabric in the loop. The bench:

_File: `_dbg/tb_kf_fab.sv (OBI memory model + fabric in loop)`_

```verilog
`timescale 1ns/1ps
module tb_kf_fab;
  reg clk=0, rst_n=0; always #5 clk=~clk;
  reg issue_valid=0; wire issue_ready; reg [31:0] instr; reg [63:0] rs; reg [1:0] rsv; reg [3:0] id;
  reg commit_valid=0; reg [3:0] commit_id; wire result_valid; reg result_ready=0; wire [31:0] result_data;
  // cfgm OBI master <-> simple bitstream memory model
  wire cfgm_req, cfgm_gnt; wire [31:0] cfgm_addr; wire cfgm_rvalid; wire [31:0] cfgm_rdata; wire config_busy;
  localparam [31:0] BASE=32'h0010_0000;
  reg [31:0] bsword[0:1445]; initial $readmemh("/home/prasit/fabulous_self/cv32e40x_kf_test/bitstreams/kf_mul_ext.words.hex", bsword);
  assign cfgm_gnt = cfgm_req;                         // accept address immediately
  reg rvq; reg [31:0] raddr;
  always @(posedge clk) begin rvq <= cfgm_req & cfgm_gnt; raddr <= cfgm_addr; end
  assign cfgm_rvalid = rvq;
  assign cfgm_rdata  = bsword[(raddr - BASE) >> 2];
  kf_copro_fab #(.BITS_BASE(BASE), .NWORDS(1446)) dut(.clk_i(clk),.rst_ni(rst_n),
    .cfgm_req_o(cfgm_req),.cfgm_gnt_i(cfgm_gnt),.cfgm_addr_o(cfgm_addr),.cfgm_rvalid_i(cfgm_rvalid),.cfgm_rdata_i(cfgm_rdata),.config_busy_o(config_busy),
    .compressed_valid_i(1'b0),.compressed_ready_o(),.compressed_resp_instr_o(),.compressed_resp_accept_o(),
    .issue_valid_i(issue_valid),.issue_ready_o(issue_ready),.issue_req_instr_i(instr),.issue_req_mode_i(2'b0),
    .issue_req_id_i(id),.issue_req_rs_i(rs),.issue_req_rs_valid_i(rsv),
    .issue_resp_accept_o(),.issue_resp_writeback_o(),.issue_resp_dualwrite_o(),.issue_resp_dualread_o(),
    .issue_resp_loadstore_o(),.issue_resp_ecswrite_o(),.issue_resp_exc_o(),
    .commit_valid_i(commit_valid),.commit_kill_i(1'b0),.commit_id_i(commit_id),
    .mem_valid_o(),.mem_ready_i(1'b1),.mem_req_id_o(),.mem_req_mode_o(),.mem_req_we_o(),.mem_req_size_o(),
    .mem_req_be_o(),.mem_req_attr_o(),.mem_req_wdata_o(),.mem_req_last_o(),.mem_req_spec_o(),.mem_req_addr_o(),
    .mem_resp_exc_i(1'b0),.mem_resp_exccode_i(6'b0),.mem_resp_dbg_i(1'b0),
    .mem_result_valid_i(1'b0),.mem_result_rdata_i(32'b0),.mem_result_err_i(1'b0),.mem_result_dbg_i(1'b0),
    .result_valid_o(result_valid),.result_ready_i(result_ready),.result_id_o(),.result_data_o(result_data),
    .result_rd_o(),.result_we_o(),.result_ecsdata_o(),.result_ecswe_o(),.result_exc_o(),.result_exccode_o(),
    .result_err_o(),.result_dbg_o());
  integer cyc, errs; reg [31:0] r1;
  task op(input [6:0] f7, input [31:0] a1, input [31:0] a2); begin
    @(negedge clk); instr={f7,25'h0000_00B}; instr[31:25]=f7; instr[14:12]=3'b000; instr[6:0]=7'h0B;
    rs={a2,a1}; rsv=2'b11; id=id+1; issue_valid=1;
    @(posedge clk); while(!issue_ready) @(posedge clk);
    @(negedge clk); issue_valid=0; commit_valid=1; commit_id=id; @(negedge clk); commit_valid=0;
    cyc=0; while(!result_valid) begin @(negedge clk); cyc=cyc+1; end
    result_ready=1; @(negedge clk); result_ready=0;
  end endtask
  initial begin errs=0; id=0; rst_n=0; repeat(4)@(negedge clk); rst_n=1;
    $display("config via OBI master from RAM..."); wait(dut.cfg_done); $display("cfg_done t=%0t",$time);
    op(7'd0, 69120357, 0); if(result_data!==69120357) errs=errs+1; $display("  init -> %0d", result_data);
    op(7'd0, 69180207, 0); r1=result_data; if(r1!==69177744) errs=errs+1; $display("  step R=8 -> %0d (exp 69177744)", r1);
    // change R via kf_cfg + reinit, re-run -> result must differ
    op(7'd1, 32'd1966080, 32'd0);   // kf_cfg(R=30.0=Q16.16(30)=1966080, idx 0=CFG_R)
    op(7'd1, 0, 32'd15);            // kf_cfg reinit (idx 15)
    op(7'd0, 69120357, 0);         // re-init
    op(7'd0, 69180207, 0); $display("  step R=30 -> %0d", result_data);
    if(result_data===r1) begin errs=errs+1; $display("  kf_cfg(R) had NO effect!"); end
    if(errs==0) $display("KF-COPRO-FAB(OBI+cfg): PASS - RAM-config + kf_step bit-exact + kf_cfg(R) changes output");
    else        $display("KF-COPRO-FAB(OBI+cfg): FAIL (%0d errors)", errs);
    $finish;
  end
endmodule
```

Run it (note the soft RegFile is renamed `RegFile_soft` to avoid clashing with the fabric's own
`RegFile_32x4` tile - Part 9.4):

```bash
# convert the bitstream to little-endian word hex for the OBI model (see Part 9.1)
python3 tools/bin2hex.py bitstreams/kf_mul_ext.bin bitstreams/kf_mul_ext
# stage the wide fabric .v once:
mkdir -p _dbg/fabstage; cp /home/prasit/fabulous_self/efpga_kf/Fabric/*.v _dbg/fabstage/
find /home/prasit/fabulous_self/efpga_kf/Tile -name '*.v' ! -name '*.bak' -exec cp -n {} _dbg/fabstage/ \;
iverilog -g2012 -s tb_kf_fab -o _dbg/tb_kf_fab.vvp \
   rtl/kf_copro_fab.v rtl/RegFile_soft.v _dbg/fabstage/*.v _dbg/tb_kf_fab.sv
vvp _dbg/tb_kf_fab.vvp
# -> cfg_done t=...
#    init -> 69120357
#    step R=8 -> 69177744   (bit-exact golden value)
#    step R=30 -> 69172261  (different => kf_cfg(R) takes effect)
#    KF-COPRO-FAB(OBI+cfg): PASS
```

---

## 9. Integrating into the CV32E40X SoC

Now wire `kf_copro_fab` into the core and feed the bitstream from RAM.

### 9.1 Bitstream -> RAM (byte order matters)

The data memory `dp_ram` assembles a 32-bit read **little-endian** (`rdata[7:0]=mem[A]`), and the
OBI loader copies `cfgm_rdata` straight into `SelfWriteData`. So the `.bytes.hex` loaded into RAM
must be little-endian per word. Use the multiop tool `tools/bin2hex.py`:

```bash
cp /home/prasit/fabulous_self/efpga_kf/user_design/kf_mul_ext.bin bitstreams/
python3 tools/bin2hex.py bitstreams/kf_mul_ext.bin bitstreams/kf_mul_ext
# produces bitstreams/kf_mul_ext.words.hex (00aaff01...) and .bytes.hex (01 ff aa 00... = LE)
```

Load it into RAM at `BITS_BASE = 0x0010_0000` (slot 0) in `tb/tb_top.sv`, replacing the multiop
slot-0 load:

```verilog
// in tb_top.sv, the load_bitstreams initial block:
$readmemh({bitdir,"/kf_mul_ext.bytes.hex"},
          cv32e40x_tb_wrapper_i.ram_i.dp_ram_i.mem, BITS_BASE + 0*BITS_STRIDE);
```

The wrapper already routes a dedicated OBI read port (`dp_ram` port C) to the coprocessor's
`cfgm_*`; no SoC change is needed there.

### 9.2 Wire `xif_copro.sv`

`xif_copro.sv` already declares `cfgm_*`/`config_busy_o` (they were tied off). Instantiate
`kf_copro_fab` instead of the soft coprocessor and connect them:

```verilog
kf_copro_fab #(
  .XLEN(XLEN), .INPUT_BUFFER_DEPTH(INPUT_BUFFER_DEPTH), .FORWARDING(FORWARDING),
  .BITS_BASE(32'h0010_0000), .NWORDS(1446)
) kf_copro_i (
  .clk_i(clk_i), .rst_ni(rst_ni),
  .cfgm_req_o(cfgm_req_o), .cfgm_gnt_i(cfgm_gnt_i), .cfgm_addr_o(cfgm_addr_o),
  .cfgm_rvalid_i(cfgm_rvalid_i), .cfgm_rdata_i(cfgm_rdata_i), .config_busy_o(config_busy_o),
  /* ... the rest of the flattened XIF connections, unchanged ... */
);
```

(Remove the old `assign cfgm_req_o = 0; assign cfgm_addr_o = 0; assign config_busy_o = 0;` tie-offs.)

### 9.3 The manifest

Copy the wide fabric into the CV tree and list everything in `cv32e40x_manifest.flist`:

```bash
mkdir -p rtl/efpga/fabric_kf
cp /home/prasit/fabulous_self/efpga_kf/Fabric/*.v rtl/efpga/fabric_kf/
find /home/prasit/fabulous_self/efpga_kf/Tile -name '*.v' ! -name '*.bak' -exec cp -n {} rtl/efpga/fabric_kf/ \;
cp _dbg/RegFile_soft.v rtl/RegFile_soft.v        # soft register file for the coprocessor
```

Then add, in the coprocessor section of the manifest (order is irrelevant for ModelSim's
elaboration, but keep it tidy):

```
// ---- wide-I/O eFPGA fabric (FABulous, regenerated with wide EXTERNAL KFMUL tile) ----
${DESIGN_RTL_DIR}/efpga/fabric_kf/<each .v file>
// ---- fabric-KFMUL coprocessor ----
${DESIGN_RTL_DIR}/RegFile_soft.v
${DESIGN_RTL_DIR}/kf_copro_fab.v
${DESIGN_RTL_DIR}/xif_copro.sv
```

A one-liner to append the 39 fabric files automatically:

```bash
python3 - <<'PY'
import os
files=sorted(f for f in os.listdir("rtl/efpga/fabric_kf") if f.endswith(".v"))
print("\n".join("${DESIGN_RTL_DIR}/efpga/fabric_kf/%s"%f for f in files))
PY
```

### 9.4 The `RegFile_soft` name-clash

The fabric contains a `RegFile_32x4` *tile*, and the coprocessor's soft register array is also a
`RegFile_32x4`. Compiling both collides. Rename the coprocessor's behavioural model to
`RegFile_soft` and instantiate that (the `rtl/RegFile_soft.v` listing in Part 6, and
`kf_copro_fab` already instantiates `RegFile_soft`).

---

## 10. The software

The firmware is plain C; the custom instructions are inline-asm `.insn` directives. The existing
`sw/kf/kf.c` already drives both opcodes (configure the model with `kf_cfg`, stream the trace
through `kf_step`, then change `R` at run time to prove `kf_cfg` works). No change is needed - it
talks to `kf_copro_fab` exactly as it talked to the soft coprocessor:

_File: `sw/kf/kf.c`_

```c
// =====================================================================================
// kf.c -- exercise the Kalman-filter coprocessor's TWO operations on the CV32E40X.
//
// The single custom opcode (0x0B, funct3=0) does two things, selected by funct7:
//
//   kf_step  -> .insn r 0x0B,0x0,0x00,rd,rs1,zero    filter one sample (rs1 -> rd)
//   kf_cfg   -> .insn r 0x0B,0x0,0x01,rd,rs1,rs2     write model coefficient[rs2] = rs1
//
// This program is just a functional check that BOTH work: it writes the model parameters
// with a batch of kf_cfg calls, streams the noisy trace through kf_step, then re-runs the
// trace after changing ONE parameter (R) with kf_cfg to confirm the change takes effect.
// No adaptive/decision logic here -- that lives in a separate algorithm later.
// =====================================================================================
#include <stdint.h>
#include "trace.h"     // #define N ; static const int NOISY[N], TRUTH[N]  (all Q16.16)

#define MM_PRINT  (*(volatile uint32_t *)0x00800000u)   // write a byte -> stdout
#define MM_STATUS (*(volatile uint32_t *)0x008000c0u)   // 123456789 = pass, 1 = fail
#define MM_EXIT   (*(volatile uint32_t *)0x008000c4u)   // write -> $finish(value)

// ---- the single custom opcode, two operations ----
static inline int kf_step(int y){                       // raw altitude -> denoised
  int r; asm volatile(".insn r 0x0B,0x0,0x00,%0,%1,zero" : "=r"(r) : "r"(y)); return r;
}
static inline int kf_cfg(int value, int index){         // coefficient[index] = value
  int r; asm volatile(".insn r 0x0B,0x0,0x01,%0,%1,%2" : "=r"(r) : "r"(value), "r"(index)); return r;
}

// ---- kf_cfg coefficient indices (see kf_copro.v) ----
#define CFG_R    0
#define CFG_Q00  1
#define CFG_Q11  4
#define CFG_Q22  6
#define CFG_P0H  7
#define CFG_P0V  8
#define CFG_P0A  9
#define CFG_DT   10
#define CFG_DT2  11
#define CFG_REINIT 15

// ---- parameter values (Q16.16) ----
#define Q16(i)   ((int)((i) << 16))   // integer -> Q16.16
#define R_DEF    Q16(8)               // nominal measurement-noise variance
#define R_ALT    Q16(30)              // a different R, to prove kf_cfg takes effect
#define P0_DEF   Q16(200)             // initial state covariance (diagonal)
#define Q00_DEF  3277                 // 0.05  (fractional Q16.16 literal)
#define Q11_DEF  36045                // 0.55
#define Q22_DEF  66                   // 0.001
#define DT_DEF   1311                 // 0.02  (50 Hz)
#define DT2_DEF  13                   // 0.0002

static void putc_(char c){ MM_PRINT = (uint32_t)c; }
static void puts_(const char *s){ while(*s) putc_(*s++); }
static void putdec(int v){
  char b[12]; int i=0; unsigned u;
  if(v<0){ putc_('-'); u=(unsigned)(-v); } else u=(unsigned)v;
  if(u==0){ putc_('0'); return; }
  while(u){ b[i++]='0'+(u%10); u/=10; }
  while(i) putc_(b[--i]);
}
static int ipart(int q){ return q>>16; }     // Q16.16 -> integer
static int absq(int q){ return q<0 ? -q : q; }

// stream the whole trace through kf_step; return total |estimate - truth| (Q16.16)
static long long run_trace(int print){
  long long err = 0; int k, est;
  for(k=0; k<N; k++){
    est = kf_step(NOISY[k]);
    err += absq(est - TRUTH[k]);
    if(print && (k<10 || (k%8)==0)){
      puts_("  "); putdec(k);
      puts_("  "); putdec(ipart(NOISY[k]));
      puts_("  "); putdec(ipart(est));
      puts_("  "); putdec(ipart(TRUTH[k]));
      putc_('\n');
    }
  }
  return err;
}

int main(void){
  long long raw_err = 0, errA, errB;
  int k;

  for(k=0; k<N; k++) raw_err += absq(NOISY[k] - TRUTH[k]);

  puts_("KF coprocessor opcode check: kf_step + kf_cfg\n");

  // ---- write the full model with kf_cfg, then run kf_step over the trace ----
  puts_("config A: R=8, Q=diag(.05,.55,.001), P0=200, dt=0.02\n");
  kf_cfg(R_DEF,   CFG_R);
  kf_cfg(Q00_DEF, CFG_Q00);
  kf_cfg(Q11_DEF, CFG_Q11);
  kf_cfg(Q22_DEF, CFG_Q22);
  kf_cfg(P0_DEF,  CFG_P0H);
  kf_cfg(P0_DEF,  CFG_P0V);
  kf_cfg(P0_DEF,  CFG_P0A);
  kf_cfg(DT_DEF,  CFG_DT);
  kf_cfg(DT2_DEF, CFG_DT2);
  kf_cfg(0,       CFG_REINIT);          // re-seed filter for a clean start

  puts_("  k  raw   kf  true\n");
  errA = run_trace(1);

  // ---- change ONE parameter via kf_cfg and re-run: result must differ ----
  puts_("config B: same model but R=30 (via kf_cfg)\n");
  kf_cfg(R_ALT, CFG_R);
  kf_cfg(0,     CFG_REINIT);
  errB = run_trace(0);

  puts_("total |error| (m):  raw="); putdec((int)(raw_err>>16));
  puts_("  kf(R=8)=");               putdec((int)(errA>>16));
  puts_("  kf(R=30)=");              putdec((int)(errB>>16));
  putc_('\n');

  // PASS = both configs denoise (kf < raw) AND kf_cfg(R) demonstrably changed the output
  if(errA < raw_err && errB < raw_err && errA != errB){
    puts_("PASS: kf_step filters and kf_cfg changes a parameter\n");
    MM_STATUS = 123456789u; MM_EXIT = 0u;
  } else {
    puts_("FAIL\n");
    MM_STATUS = 1u; MM_EXIT = 1u;
  }
  for(;;);
  return 0;
}
```

For the cycle-count comparison, `sw/kfperf/perf.c` runs the same trace twice - once in pure
software, once via the coprocessor - timing each with the `mcycle` CSR (remember
`csrw mcountinhibit, zero` first on CV32E40X). It reports cycles/sample for both.

---

## 11. Building and running

### 11.1 Quick RTL checks (iverilog, seconds)

```bash
cd cv32e40x_kf_test
# elaborate the coprocessor + fabric (catch syntax/port errors fast)
iverilog -g2012 -t null rtl/kf_copro_fab.v rtl/RegFile_soft.v rtl/efpga/fabric_kf/*.v
```

### 11.2 Full SoC simulation (ModelSim)

The `sw/Makefile` compiles the manifest and runs a firmware image. From `sw/`:

```bash
cd sw
make kf-vsim-run          # functional: runs sw/kf/kf.c on the SoC with the fabric in the loop
make kfperf-vsim-run      # performance: software vs coprocessor cycle counts
```

Expected functional output (from the ModelSim `transcript`):

```
[1ns] eFPGA: bitstream pre-loaded into RAM at 0x00100000 (+0x2000/slot) from ../bitstreams
KF coprocessor opcode check: kf_step + kf_cfg
config A: R=8, Q=diag(.05,.55,.001), P0=200, dt=0.02
config B: same model but R=30 (via kf_cfg)
total |error| (m):  raw=53  kf(R=8)=29  kf(R=30)=53
PASS: kf_step filters and kf_cfg changes a parameter
ALL TESTS PASSED
```

(The benign `vsim-3722 [TFMPC] Missing connection for port` warnings come from the
auto-generated fabric and can be ignored.)

Expected performance output:

```
KF performance: pure software vs coprocessor (cycles via mcycle)
software  total : 42342 cyc  (661 /sample)
coproc    total :  6319 cyc  ( 98 /sample)
ALL TESTS PASSED
```

---

## 12. Results and performance

| Metric | Software | eFPGA-fabric coprocessor |
|---|---|---|
| cycles / sample | 661 | **98** (6.7x faster) |
| multiply | sequential SW Booth/`mul` | hard KFMUL tile in the configured fabric |
| one-time cost | none | ~7000-cycle bitstream stream at boot (amortised) |
| denoising (64-sample trace) | - | raw 53 m -> 29 m total |error| |
| runtime reconfig | - | yes (bitstream from RAM; `kf_cfg` changes coefficients) |

What was proven, end-to-end and bit-exact at every stage:
1. Booth-Wallace multiply == native `*` (200k vectors).
2. Wide combinational KFMUL BEL == multiply (5000 vectors + edge cases).
3. The **configured FABulous fabric** multiplies correctly (`KFMUL-WIDE-eFPGA SIM: PASS`).
4. `kf_copro_fab` reproduces the golden KF values with the fabric in the loop, and `kf_cfg`
   changes the output at run time (`KF-COPRO-FAB(OBI+cfg): PASS`).
5. The full CV32E40X SoC runs the C firmware: `ALL TESTS PASSED`, 6.7x faster than software.

---

## 13. Troubleshooting: every trap and its fix

**13.1 `synth_fabulous` folds your user logic to constants (configured fabric reads 0).**
Any *sequential* user_design in this toolchain is optimised to constants (even a trivial counter).
Only purely combinational user designs survive. Fix: keep the heavy datapath in a **hard BEL** and
expose it with `EXTERNAL` ports; keep the user_design combinational.

**13.2 EXTERNAL vs switch-matrix ports.** A wide BEL (96 ports) will overwhelm the auto-generated
switch matrix. `(* FABulous, EXTERNAL *)` ports bypass the matrix and appear at `eFPGA_top`. Use
EXTERNAL for the wide operand/result buses; only the config bit goes through the matrix.

**13.3 Stale FABulous config artifacts.** A leftover `*_ConfigMem.csv` from a previous BEL causes
`bitmask mismatch` during fabric regeneration. Delete the generated `KFMUL_*` (ConfigMem,
switch_matrix, generated_switch_matrix) and regenerate.

**13.4 Bitstream byte order.** `dp_ram` reads words little-endian and the OBI loader copies
`cfgm_rdata` directly to `SelfWriteData`. Generate `.bytes.hex` with `tools/bin2hex.py` (which
emits little-endian bytes); a 32-bit read then delivers the exact word the fabric config FSM
expects. (Sanity: `.words.hex` line 0 should equal the first config word, e.g. `00aaff01`.)

**13.5 XIF handshake / boot race.** Two related issues:
 * The coprocessor must hold the engine in reset until `cfg_done` (config takes ~7000 cycles); a
   `kf_step` issued during configuration simply stalls (`issue_ready=0`) until ready.
 * When `issue_ready` rises *late* (after the boot delay), a testbench that does
   `wait(issue_ready); @(negedge) issue_valid=0;` can drop `issue_valid` one negedge before the
   accepting posedge, so the accept is missed and the sim hangs forever. Hold `issue_valid` until
   `issue_ready` is sampled high **at a posedge**:
   `@(posedge clk); while(!issue_ready) @(posedge clk);` then drop it.

**13.6 Out-of-range bit select silently drops writes.** `wadr = icnt[4:0]` with `icnt` a
`reg [3:0]` makes `wadr[4]` an `x`, so `mem[wadr]` writes vanish (state reads back 0). Use
`wadr = {1'b0, icnt}`. Symptom: the init `kf_step` "works" (its result is `data_q<=y`, not from
memory) but every compute step is garbage.

**13.7 RegFile two-read-port limit.** `MAC`/`MSUB` need three reads (a, b, accumulator) but the
RegFile has two read ports - split them into two cycles (compute+latch `prod`, then
read-accumulate-write).

**13.8 Module name clash.** The fabric's `RegFile_32x4` tile collides with the coprocessor's soft
register file. Rename the soft one to `RegFile_soft`.

**13.9 Simulator/sandbox traps that masquerade as RTL hangs.**
 * Run `iverilog`/`vvp` in the **foreground** with files **inside the project tree**. Background
   jobs and `/tmp`/scratch dirs can be on a separate or ephemeral filesystem; a failed recompile
   then silently runs a **stale** `.vvp` and the "hang" is really a missing file.
 * `vvp` buffers stdout internally - output appears only at `$finish` (not on `$fflush` under a
   pipe, and **lost** on SIGKILL). To see state before a hang, `$fwrite`+`$fflush(fd)` to a real
   file, or `$dumpvars` to a VCD (flushes incrementally). A VCD whose time keeps advancing proves
   it is a *functional* stall, not a comb loop.
 * `vvp` ignores plain SIGTERM while busy; use `timeout -s KILL N vvp ...`.

**13.10 PATH ordering.** oss-cad-suite's yosys/nextpnr must precede any system install, or the
FABulous flow misbehaves in subtle ways.

---

## 14. Future work: pipelining the multiply (`OUT_reg = 1`)

With `OUT_reg = 0` the fabric multiply is combinational and sits in the coprocessor's critical
path (the Booth tree + fabric routing), which would limit the host clock. The KFMUL BEL already
has an `OUT_reg` config bit that **registers the product** (one pipeline stage). To use it:

1. Set the `OUT_reg` config bit for the KFMUL tile(s) in the bitstream (via a `fasm` feature line
   before `bit_gen`, or by making the BEL's output always-registered).
2. Add **one cycle of latency** to every multiply-consuming step of the engine: present the
   operands for a settle cycle (product registering), then consume `prod` the next cycle. `MUL`
   becomes 2 cycles, `MAC`/`MSUB` 3 cycles, and each Newton-Raphson multiply +1. Estimated cost
   ~+35 cycles/step (~125 cyc/sample, still ~5x faster than software) in exchange for a much
   shorter critical path. Deeper pipelining (registers inside the Booth tree) is a further BEL
   change.

This is intentionally left as a follow-up; the functional integration above is complete and
verified.

---

## Appendix A. Command cheat-sheet

```bash
# --- environment (every fabric command) ---
export PATH="/home/prasit/.fabulous/oss-cad-suite/bin:/home/prasit/.local/share/uv/tools/fabulous-fpga/bin:$PATH"

# --- FABulous project ---
FABulous create-project efpga_kf
cd efpga_kf
# (add Tile/KFMUL, write fabric.csv)
FABulous -p . run "load_fabric; run_FABulous_fabric"        # regenerate fabric
./build_kf.sh user_design/kf_mul_ext.v kf_mul_ext Test/kf_mul_ext_tb.v   # bitstream + gate sim

# --- bitstream into the CV project ---
cd ../cv32e40x_kf_test
cp ../efpga_kf/user_design/kf_mul_ext.bin bitstreams/
python3 tools/bin2hex.py bitstreams/kf_mul_ext.bin bitstreams/kf_mul_ext
mkdir -p rtl/efpga/fabric_kf
cp ../efpga_kf/Fabric/*.v rtl/efpga/fabric_kf/
find ../efpga_kf/Tile -name '*.v' ! -name '*.bak' -exec cp -n {} rtl/efpga/fabric_kf/ \;

# --- unit sims (foreground) ---
iverilog -g2012 -s tb_mul    -o _dbg/tb_mul.vvp    rtl/mul_booth_wallace.v _dbg/tb_mul.sv && vvp _dbg/tb_mul.vvp
iverilog -g2012 -s tb_kf_fab -o _dbg/tb_kf_fab.vvp rtl/kf_copro_fab.v rtl/RegFile_soft.v _dbg/fabstage/*.v _dbg/tb_kf_fab.sv && vvp _dbg/tb_kf_fab.vvp

# --- full SoC (ModelSim) ---
cd sw
make kf-vsim-run        # functional   -> ALL TESTS PASSED
make kfperf-vsim-run    # performance  -> 98 vs 661 cyc/sample
```

## Appendix B. Files created or edited (relative to the CV project)

```
NEW   rtl/mul_booth_wallace.v          Booth-Wallace 32x32 multiplier
NEW   rtl/kf_copro_ts.v                time-shared soft coprocessor (golden model)
NEW   rtl/kf_copro_fab.v              fabric-KFMUL coprocessor (OBI config + kf_cfg)
NEW   rtl/RegFile_soft.v              soft register-file model (renamed to avoid clash)
NEW   rtl/efpga/fabric_kf/*.v         the FABulous fabric (copied from efpga_kf)
NEW   bitstreams/kf_mul_ext.{bin,words.hex,bytes.hex}
EDIT  rtl/xif_copro.sv                instantiate kf_copro_fab; connect cfgm_*
EDIT  cv32e40x_manifest.flist         add fabric + RegFile_soft + kf_copro_fab
EDIT  tb/tb_top.sv                     load kf_mul_ext.bytes.hex at BITS_BASE
NEW   sw/kfperf/perf.c                 cycle-count comparison (optional)
(unchanged) sw/kf/kf.c                 already drives kf_step + kf_cfg

FABulous project (efpga_kf):
NEW   Tile/KFMUL/KFMUL.csv, KFMUL_DSP.v    wide combinational EXTERNAL-port multiply BEL
NEW   fabric.csv                            8x8 floorplan with the KFMUL column
NEW   user_design/kf_mul_ext.v              combinational pass-through (valid bitstream)
NEW   Test/kf_mul_ext_tb.v                  configured-fabric multiply gate sim
```

*End of document.*

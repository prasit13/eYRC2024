// =====================================================================================
// kf_copro -- single-opcode linear Kalman-filter coprocessor (altimeter denoising).
//
// Implements the linear Kalman filter from "Kalman Filter for Precise Altitude Estimation
// in FMCW Radar" (Jha et al., IEEE MAPCON 2023, DOI 10.1109/MAPCON58678.2023.10463967):
//   state x = [Altitude, Velocity, Acceleration] (n=3), scalar altitude measurement,
//   kinematic A = [[1,dt,dt^2/2],[0,1,dt],[0,0,1]], H = [1 0 0].
// The paper's tuned constants are the reset defaults (Q16.16):
//   P0 = diag(200,200,200) ,  Q = diag(0.05, 0.55, 0.001) ,  R = 8 ,  dt = 0.02 (50 Hz).
//
// ONE custom opcode (0x0B); the funct7 field selects the operation, so it stays a single
// opcode while still allowing run-time re-tuning (the paper tunes Q/R with a GA per sortie):
//
//   funct7=0  kf_step  rd, rs1        .insn r 0x0B,0x0,0x00,rd,rs1,zero
//             rs1 = raw altitude (Q16.16)  ->  rd = denoised altitude (Q16.16)
//
//   funct7=1  kf_cfg   rd, rs1, rs2   .insn r 0x0B,0x0,0x01,rd,rs1,rs2
//             rs2 = coefficient index, rs1 = value (Q16.16)  ->  rd = value (ack)
//             index: 0=R 1=Q00 2=Q01 3=Q02 4=Q11 5=Q12 6=Q22 7=P0H 8=P0V 9=P0A
//                    10=DT 11=DT2 15=REINIT(re-seed filter from current P0 on next sample)
//
// Filter state (x, P) is PERSISTENT across calls; the first kf_step after reset (or after a
// REINIT) auto-initialises x=[y,0,0], P=P0. Q16.16 signed fixed-point. Flattened-XIF port
// list matches xif_copro_verilog (drop-in / eFPGA-mappable).
// =====================================================================================
module kf_copro #(
  parameter XLEN = 32, parameter INPUT_BUFFER_DEPTH = 1, parameter FORWARDING = 1,
  // ---- reset-default model constants (Q16.16) = the MAPCON-2023 paper's tuned values ----
  parameter signed [31:0] DEF_DT  = 32'sd1311,     // dt   = 0.02   (50 Hz)
  parameter signed [31:0] DEF_DT2 = 32'sd13,       // dt^2/2 = 0.0002
  parameter signed [31:0] DEF_R   = 32'sd524288,   // R    = 8.0
  parameter signed [31:0] DEF_Q00 = 32'sd3277,     // Q diag 0.05
  parameter signed [31:0] DEF_Q01 = 32'sd0,
  parameter signed [31:0] DEF_Q02 = 32'sd0,
  parameter signed [31:0] DEF_Q11 = 32'sd36045,    // Q diag 0.55
  parameter signed [31:0] DEF_Q12 = 32'sd0,
  parameter signed [31:0] DEF_Q22 = 32'sd66,       // Q diag 0.001
  parameter signed [31:0] DEF_P0H = 32'sd13107200, // P0 diag 200.0
  parameter signed [31:0] DEF_P0V = 32'sd13107200,
  parameter signed [31:0] DEF_P0A = 32'sd13107200
) (
  input  wire        clk_i,
  input  wire        rst_ni,
  input  wire        compressed_valid_i,
  output wire        compressed_ready_o,
  output wire [31:0] compressed_resp_instr_o,
  output wire        compressed_resp_accept_o,
  input  wire        issue_valid_i,
  output wire        issue_ready_o,
  input  wire [31:0] issue_req_instr_i,
  input  wire [1:0]  issue_req_mode_i,
  input  wire [3:0]  issue_req_id_i,
  input  wire [63:0] issue_req_rs_i,
  input  wire [1:0]  issue_req_rs_valid_i,
  output wire        issue_resp_accept_o,
  output wire        issue_resp_writeback_o,
  output wire        issue_resp_dualwrite_o,
  output wire [2:0]  issue_resp_dualread_o,
  output wire        issue_resp_loadstore_o,
  output wire        issue_resp_ecswrite_o,
  output wire        issue_resp_exc_o,
  input  wire        commit_valid_i,
  input  wire        commit_kill_i,
  input  wire [3:0]  commit_id_i,
  output wire        mem_valid_o,
  input  wire        mem_ready_i,
  output wire [3:0]  mem_req_id_o,
  output wire [1:0]  mem_req_mode_o,
  output wire        mem_req_we_o,
  output wire [2:0]  mem_req_size_o,
  output wire [3:0]  mem_req_be_o,
  output wire [1:0]  mem_req_attr_o,
  output wire [31:0] mem_req_wdata_o,
  output wire        mem_req_last_o,
  output wire        mem_req_spec_o,
  output wire [31:0] mem_req_addr_o,
  input  wire        mem_resp_exc_i,
  input  wire [5:0]  mem_resp_exccode_i,
  input  wire        mem_resp_dbg_i,
  input  wire        mem_result_valid_i,
  input  wire [31:0] mem_result_rdata_i,
  input  wire        mem_result_err_i,
  input  wire        mem_result_dbg_i,
  output wire        result_valid_o,
  input  wire        result_ready_i,
  output wire [3:0]  result_id_o,
  output wire [31:0] result_data_o,
  output wire [4:0]  result_rd_o,
  output wire        result_we_o,
  output wire [5:0]  result_ecsdata_o,
  output wire [2:0]  result_ecswe_o,
  output wire        result_exc_o,
  output wire [5:0]  result_exccode_o,
  output wire        result_err_o,
  output wire        result_dbg_o
);

  // ---- run-time model coefficients (registers; reset to the paper defaults) ----
  reg signed [31:0] DT, DT2, R, Q00, Q01, Q02, Q11, Q12, Q22, P0H, P0V, P0A;
  
  // ---- persistent filter state ----
  reg signed [31:0] x0, x1, x2;
  reg signed [31:0] p00, p01, p02, p11, p12, p22;
  reg        first;
  
  // ---- one outstanding instruction ----
  reg        busy, done;
  reg signed [31:0] data_q;
  reg [3:0]  id_q;
  reg [4:0]  rd_q;
  
  // ---- opcode/funct decode (single opcode 0x0B, funct3=0; funct7 selects op) ----
  wire        ours    = (issue_req_instr_i[6:0]==7'h0B) & (issue_req_instr_i[14:12]==3'b000);
  wire [6:0]  f7      = issue_req_instr_i[31:25];
  wire        is_step = ours & (f7==7'd0);
  wire        is_cfg  = ours & (f7==7'd1);
  wire        is_op   = is_step | is_cfg;
  
  // ---- Combinational inputs from RS registers ----
  wire signed [31:0] y       = issue_req_rs_i[31:0];
  wire signed [31:0] cfg_val = issue_req_rs_i[31:0];
  wire [3:0]         cfg_idx = issue_req_rs_i[35:32];   // rs2 low nibble

  // ---- Combinational logic and instances extracted from the always block ----
  // Wires and modules for the Predict Step
  wire signed [31:0] m_dt_x1, m_dt2_x2, m_dt_x2;
  qmul_booth_wallace u01(.a(DT), .b(x1), .q(m_dt_x1));
  qmul_booth_wallace u02(.a(DT2),.b(x2), .q(m_dt2_x2));
  qmul_booth_wallace u03(.a(DT), .b(x2), .q(m_dt_x2));
  
  wire signed [31:0] nx0 = x0 + m_dt_x1 + m_dt2_x2;
  wire signed [31:0] nx1 = x1 + m_dt_x2;
  wire signed [31:0] nx2 = x2;
  
  wire signed [31:0] m_dt_p01, m_dt2_p02, m_dt_p11, m_dt2_p12, m_dt_p12, m_dt2_p22, m_dt_p22;
  qmul_booth_wallace u04(.a(DT), .b(p01), .q(m_dt_p01));
  qmul_booth_wallace u05(.a(DT2),.b(p02), .q(m_dt2_p02));
  qmul_booth_wallace u06(.a(DT), .b(p11), .q(m_dt_p11));
  qmul_booth_wallace u07(.a(DT2),.b(p12), .q(m_dt2_p12));
  qmul_booth_wallace u08(.a(DT), .b(p12), .q(m_dt_p12));
  qmul_booth_wallace u09(.a(DT2),.b(p22), .q(m_dt2_p22));
  qmul_booth_wallace u10(.a(DT), .b(p22), .q(m_dt_p22));
  
  wire signed [31:0] ap00 = p00 + m_dt_p01 + m_dt2_p02;
  wire signed [31:0] ap01 = p01 + m_dt_p11 + m_dt2_p12;
  wire signed [31:0] ap02 = p02 + m_dt_p12 + m_dt2_p22; // Added missing semicolon here
  wire signed [31:0] ap11 = p11 + m_dt_p12;
  wire signed [31:0] ap12 = p12 + m_dt_p22;
  wire signed [31:0] ap22 = p22;
  
  wire signed [31:0] m_dt_ap01, m_dt2_ap02, m_dt_ap02, m_dt_ap12;
  qmul_booth_wallace u11(.a(DT), .b(ap01), .q(m_dt_ap01));
  qmul_booth_wallace u12(.a(DT2),.b(ap02), .q(m_dt2_ap02));
  qmul_booth_wallace u13(.a(DT), .b(ap02), .q(m_dt_ap02));
  qmul_booth_wallace u14(.a(DT), .b(ap12), .q(m_dt_ap12));
  
  wire signed [31:0] pm00 = ap00 + m_dt_ap01 + m_dt2_ap02 + Q00;
  wire signed [31:0] pm01 = ap01 + m_dt_ap02              + Q01;
  wire signed [31:0] pm02 = ap02                          + Q02;
  wire signed [31:0] pm11 = ap11 + m_dt_ap12              + Q11;
  wire signed [31:0] pm12 = ap12                          + Q12;
  wire signed [31:0] pm22 = ap22                          + Q22;
  
  // Wires and modules for the Update Step (scalar measurement)
  wire signed [31:0] e_in = y - nx0;
  wire signed [31:0] s_in = pm00 + R;
  
  wire signed [31:0] k0_w, recip, k1_w, k2_w;
  div_nr #(.ITER(4)) u_div (.num(pm00), .den(s_in), .q(k0_w), .recip(recip));
  
  wire signed [31:0] k0 = k0_w;
  qmul_booth_wallace u15(.a(pm01), .b(recip), .q(k1_w));
  qmul_booth_wallace u16(.a(pm02), .b(recip), .q(k2_w));
  wire signed [31:0] k1 = k1_w;
  wire signed [31:0] k2 = k2_w;
  
  wire signed [31:0] m_k0_e, m_k1_e, m_k2_e;
  qmul_booth_wallace u17(.a(k0), .b(e_in), .q(m_k0_e));
  qmul_booth_wallace u18(.a(k1), .b(e_in), .q(m_k1_e));
  qmul_booth_wallace u19(.a(k2), .b(e_in), .q(m_k2_e));
  
  wire signed [31:0] ux0 = nx0 + m_k0_e;
  wire signed [31:0] ux1 = nx1 + m_k1_e;
  wire signed [31:0] ux2 = nx2 + m_k2_e;
  
  wire signed [31:0] m_k0_pm00, m_k0_pm01, m_k0_pm02, m_k1_pm01, m_k1_pm02, m_k2_pm02;
  qmul_booth_wallace u20(.a(k0), .b(pm00), .q(m_k0_pm00));
  qmul_booth_wallace u21(.a(k0), .b(pm01), .q(m_k0_pm01));
  qmul_booth_wallace u22(.a(k0), .b(pm02), .q(m_k0_pm02));
  qmul_booth_wallace u23(.a(k1), .b(pm01), .q(m_k1_pm01));
  qmul_booth_wallace u24(.a(k1), .b(pm02), .q(m_k1_pm02));
  qmul_booth_wallace u25(.a(k2), .b(pm02), .q(m_k2_pm02));
  
  wire signed [31:0] np00 = pm00 - m_k0_pm00;
  wire signed [31:0] np01 = pm01 - m_k0_pm01;
  wire signed [31:0] np02 = pm02 - m_k0_pm02;
  wire signed [31:0] np11 = pm11 - m_k1_pm01;
  wire signed [31:0] np12 = pm12 - m_k1_pm02;
  wire signed [31:0] np22 = pm22 - m_k2_pm02;

  // ---- issue response ----
  //  kf_step needs rs1 valid; kf_cfg needs rs1(value)+rs2(index) valid; else reject.
  assign issue_ready_o          = ~busy & (is_op ? (is_cfg ? (&issue_req_rs_valid_i[1:0])
                                                           : issue_req_rs_valid_i[0]) : 1'b1);
  assign issue_resp_accept_o    = is_op;
  assign issue_resp_writeback_o = is_op;
  assign issue_resp_dualwrite_o = 1'b0;
  assign issue_resp_dualread_o  = 3'b0;
  assign issue_resp_loadstore_o = 1'b0;
  assign issue_resp_ecswrite_o  = 1'b0;
  assign issue_resp_exc_o       = 1'b0;
  
  // ---- dead outputs ----
  assign compressed_ready_o       = compressed_valid_i;
  assign compressed_resp_instr_o  = 32'b0;
  assign compressed_resp_accept_o = 1'b0;
  assign mem_valid_o=1'b0; assign mem_req_id_o=4'b0; assign mem_req_mode_o=2'b0;
  assign mem_req_we_o=1'b0; assign mem_req_size_o=3'b0;
  assign mem_req_be_o=4'b0;
  assign mem_req_attr_o=2'b0; assign mem_req_wdata_o=32'b0; assign mem_req_last_o=1'b0;
  assign mem_req_spec_o=1'b0; assign mem_req_addr_o=32'b0;

  assign result_valid_o   = done;
  assign result_id_o      = id_q;
  assign result_data_o    = data_q;
  assign result_rd_o      = rd_q;
  assign result_we_o      = 1'b1;
  assign result_ecsdata_o = 6'b0; assign result_ecswe_o = 3'b0;
  assign result_exc_o     = 1'b0; assign result_exccode_o = 6'b0;
  assign result_err_o     = 1'b0; assign result_dbg_o = 1'b0;
  
  wire accept_hs  = issue_valid_i & issue_ready_o & is_op;
  wire commit_hit = commit_valid_i & (commit_id_i == id_q);
  
  always @(posedge clk_i) begin
    if (~rst_ni) begin
      busy<=1'b0; done<=1'b0; first<=1'b1;
      x0<=0; x1<=0; x2<=0; p00<=0; p01<=0; p02<=0; p11<=0; p12<=0; p22<=0;
      data_q<=0; id_q<=0; rd_q<=0;
      DT<=DEF_DT; DT2<=DEF_DT2; R<=DEF_R;
      Q00<=DEF_Q00; Q01<=DEF_Q01; Q02<=DEF_Q02; Q11<=DEF_Q11; Q12<=DEF_Q12; Q22<=DEF_Q22;
      P0H<=DEF_P0H; P0V<=DEF_P0V; P0A<=DEF_P0A;
    end else begin
      if (done & result_ready_i) begin 
        done<=1'b0; busy<=1'b0;
      end

      if (accept_hs & ~busy) begin
        busy <= 1'b1;
        id_q <= issue_req_id_i;
        rd_q <= issue_req_instr_i[11:7];

        if (is_cfg) begin
          // ---- run-time coefficient write (or REINIT) ----
          case (cfg_idx)
            4'd0:  R   <= cfg_val;
            4'd1:  Q00 <= cfg_val;
            4'd2:  Q01 <= cfg_val;
            4'd3:  Q02 <= cfg_val;
            4'd4:  Q11 <= cfg_val;
            4'd5:  Q12 <= cfg_val;
            4'd6:  Q22 <= cfg_val;
            4'd7:  P0H <= cfg_val;
            4'd8:  P0V <= cfg_val;
            4'd9:  P0A <= cfg_val;
            4'd10: DT  <= cfg_val;
            4'd11: DT2 <= cfg_val;
            4'd15: first <= 1'b1; // re-seed filter on next kf_step
            default: ;
          endcase
          data_q <= cfg_val; // ack
        end else if (first) begin
          // ---- auto-initialise ----
          x0<=y;
          x1<=0; x2<=0;
          p00<=P0H; p01<=0; p02<=0; p11<=P0V; p12<=0; p22<=P0A;
          first<=1'b0;
          data_q<=y;
        end else begin
          // ---- PREDICT & UPDATE result writeback ----
          x0<=ux0; x1<=ux1; x2<=ux2;
          p00<=np00; p01<=np01; p02<=np02; p11<=np11; p12<=np12; p22<=np22;
          data_q <= ux0;
        end

        if (commit_valid_i & (commit_id_i == issue_req_id_i)) begin
          if (commit_kill_i) busy <= 1'b0;
          else done <= 1'b1;
        end
      end else if (busy & ~done & commit_hit) begin
        if (commit_kill_i) busy <= 1'b0;
        else done <= 1'b1;
      end
    end
  end
endmodule


// Q16.16 divide via Newton-Raphson reciprocal (reuses the Booth multiplier)
//   x_{n+1} = x_n*(2 - den*x_n)  ->  x -> 1/den   (seed makes den*x0 in [0.5,1))
`default_nettype none
module div_nr #(parameter ITER = 4) (
    input  wire signed [31:0] num,    // numerator (Q16.16, signed)
    input  wire        [31:0] den,    // denominator (Q16.16, > 0)
    output wire signed [31:0] q,      // num/den (Q16.16)
    output wire signed [31:0] recip   // 1/den   (exposed so callers share it)
);
    localparam signed [31:0] TWO = 32'sd131072;   // 2.0 in Q16.16
    function [5:0] msb; input [31:0] v;
        integer i; begin
            msb = 0; for (i=0;i<32;i=i+1) if (v[i]) msb = i[5:0];
        end 
    endfunction
    wire [5:0]  m  = msb(den);
    wire [31:0] x0 = 32'd1 << (6'd31 - m);         // seed
    wire signed [31:0] x [0:ITER];
    assign x[0] = x0;
    
    genvar n;
    generate
        for (n = 0; n < ITER; n = n + 1) begin : NR
            wire signed [31:0] dx, two_dx;
            qmul_booth_wallace u_dx (.a($signed(den)), .b(x[n]),   .q(dx));      // d*x_n
            assign two_dx = TWO - dx; // 2 - d*x_n
            qmul_booth_wallace u_up (.a(x[n]),         .b(two_dx), .q(x[n+1])); // x_n*(2-d*x_n)
        end
    endgenerate
    assign recip = x[ITER];
    qmul_booth_wallace u_q (.a(num), .b(recip), .q(q));                          // num * (1/den)
endmodule
`default_nettype wire


// signed 32x32 -> 64 multiplier: radix-4 Booth + Wallace tree (combinational)
`default_nettype none
module mul_booth_wallace (
    input  wire signed [31:0] a,
    input  wire signed [31:0] b,
    output wire signed [63:0] p
);
    // operand multiples, sign-extended to 64 bits:  a  and  2a
    wire [63:0] a64  = {{32{a[31]}}, a};
    wire [63:0] a264 = {{31{a[31]}}, a, 1'b0};

    // radix-4 Booth recoding -> 17 partial products
    //   group i looks at (b[2i+1], b[2i], b[2i-1]); b[-1]=0, top sign-extended.
    wire [34:0] B = {b[31], b[31], b, 1'b0};
    wire [63:0] pp [0:16];
    
    genvar i;
    generate
        for (i = 0; i < 17; i = i + 1) begin : PPG
            wire [2:0]  sel  = B[2*i+2 -: 3];
            wire [63:0] base =
                (sel == 3'b001 || sel == 3'b010) ? a64            :  // +1
                (sel == 3'b011)                  ? a264           :  // +2
                (sel == 3'b100)                  ? (~a264 + 64'd1) :  // -2
                (sel == 3'b101 || sel == 3'b110) ? (~a64  + 64'd1) :  // -1
                                                    64'd0;            //  0
            assign pp[i] = base << (2*i);
        end
    endgenerate

    // Wallace tree: 3:2 carry-save compressors, 17 -> 2 (carry pre-shifted <<1)
    `define CSA(S,C,X,Y,Z) \
        wire [63:0] S = (X) ^ (Y) ^ (Z); \
        wire [63:0] C = (((X)&(Y)) | ((X)&(Z)) | ((Y)&(Z))) << 1;
        
    `CSA(s10,c10, pp[0],  pp[1],  pp[2])
    `CSA(s11,c11, pp[3],  pp[4],  pp[5])
    `CSA(s12,c12, pp[6],  pp[7],  pp[8])
    `CSA(s13,c13, pp[9],  pp[10], pp[11])
    `CSA(s14,c14, pp[12], pp[13], pp[14])
    
    `CSA(s20,c20, s10, c10, s11)
    `CSA(s21,c21, c11, s12, c12)
    `CSA(s22,c22, s13, c13, s14)
    `CSA(s23,c23, c14, pp[15], pp[16])
    
    `CSA(s30,c30, s20, c20, s21)
    `CSA(s31,c31, c21, s22, c22)
    
    `CSA(s40,c40, s30, c30, s31)
    `CSA(s41,c41, c31, s23, c23)
    
    `CSA(s50,c50, s40, c40, s41)
    
    `CSA(s60,c60, s50, c50, c41)
    `undef CSA

    assign p = s60 + c60; // final carry-propagate add
endmodule

// Q16.16 wrapper: (a*b) >>> 16
module qmul_booth_wallace (
    input  wire signed [31:0] a,
    input  wire signed [31:0] b,
    output wire signed [31:0] q
);
    wire signed [63:0] p;
    mul_booth_wallace u_mul (.a(a), .b(b), .p(p));
    assign q = p[47:16];
endmodule
`default_nettype wire

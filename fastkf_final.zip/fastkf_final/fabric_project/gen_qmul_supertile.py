#!/usr/bin/env python3
"""
gen_qmul_supertile.py  --  build a 4-row qmul SUPERTILE (Booth-Wallace 32x32) for FABulous,
modelled on the shipped DSP supertile (Tile/DSP).  Splits the 96 BEL pins (a0..31, b0..31,
q0..31) across 4 vertically-stacked basic tiles so each tile carries only ~24 fabric-facing
connections (DSP's proven density) instead of 96 on one tile -> routable.

Layout (top -> bottom in the fabric grid):
    qmul_r3 (top)  : sources b16..b31,  delivers q24..q31
    qmul_r2        : sources b0..b15,   delivers q16..q23
    qmul_r1        : sources a16..a31,  delivers q8..q15
    qmul_r0 (BEL)  : sources a0..a15,   delivers q0..q7   + instantiates boothmult

Inter-tile buses (DSP top2bot/bot2top pattern, adjacent Y only):
    down (inputs toward BEL): dA r3->r2 (16), dB r2->r1 (32), dC r1->r0 (48)
    up   (outputs from BEL) : uA r0->r1 (24), uB r1->r2 (16), uC r2->r3 (8)

Each sub-tile matrix = full standard through-routing (every *BEG sink <- *END sources, "rule 1",
the proven single-tile recipe) + that tile's share of BEL/bus connections.  No INCLUDE Base.list
(we wire everything explicitly, as the standalone qmul tile did).

Run from the project root (needs Tile/include/Base.csv and Tile/qmul/boothmult.v):
    python3 gen_qmul_supertile.py
"""
import os, shutil

TR = 2      # through-routing fanin per *BEG sink
FI = 4      # *END fanin per locally-sourced BEL/forward input bit
FO = 8      # *BEG fanout per locally-delivered BEL/forward output bit
ROOT = "."
QDIR = os.path.join(ROOT, "Tile", "QMUL")

# ---------------------------------------------------------------- parse Base.csv wire pools
def parse_base():
    sinks, ends = [], []                          # all *BEG (need a driver) ; all *END (sources)
    for ln in open(os.path.join(ROOT, "Tile", "include", "Base.csv")):
        c = [x.strip() for x in ln.split(",")]
        if len(c) < 6 or c[0] not in ("NORTH", "EAST", "SOUTH", "WEST", "JUMP"):
            continue
        src, dst = c[1], c[4]
        try:
            n = int(c[5])
        except ValueError:
            continue
        if "BEG" in src and src != "NULL":       # incl. N2BEGb / S2BEGb / ... "b" variants
            sinks += [f"{src}{i}" for i in range(n)]
        if "END" in dst and dst != "NULL":
            ends += [f"{dst}{i}" for i in range(n)]
    return sinks, ends

SINKS, ENDS = parse_base()
OUT_BEGS = {"N": [], "E": [], "S": [], "W": []}    # directional BEGs for driving BEL outputs
for s in SINKS:
    if s[0] in OUT_BEGS:
        OUT_BEGS[s[0]].append(s)
DIRS = [d for d in ("N", "E", "S", "W") if OUT_BEGS[d]]

def through_routing():
    """rule 1: every *BEG sink <- TR *END sources (standard pass-through)."""
    out = []
    for i, s in enumerate(SINKS):
        for j in range(TR):
            out.append(f"{s},{ENDS[(i * TR + j) % len(ENDS)]}")
    return out

def feed_input(sink, k, const=False):
    """FI lines: input bit <- *END sources (+GND0/VCC0 for real BEL operand bits)."""
    out = [f"{sink},{ENDS[(k * FI + j) % len(ENDS)]}" for j in range(FI)]
    if const:
        out += [f"{sink},GND0", f"{sink},VCC0"]
    return out

def drive_output(src, k):
    """FO lines: directional *BEG wires (spread N/E/S/W) <- output source."""
    out, per = [], max(1, FO // len(DIRS))
    for d in DIRS:
        pool = OUT_BEGS[d]
        for j in range(per):
            out.append(f"{pool[(k * per + j) % len(pool)]},{src}")
    return out

# ---------------------------------------------------------------- tile CSV + matrix writers
def _pad(*fields, n=18):
    return ",".join(list(fields) + [""] * (n - len(fields))) + "\n"

CSV_HDR = ("TILE,{name},,,,,,,,,,,,,,,,,\n"
           "#direction,source_name,X-offset,Y-offset,destination_name,wires,,,,,,,,,,,,\n"
           "INCLUDE,../../include/Base.csv,,,,,,,,,,,,,,,,,\n")   # defines standard wires (N1BEG..)

def bus_src(direction, name, dy, w):   # tile GENERATES the bus (source)
    return _pad(direction, name, "0", str(dy), "NULL", str(w))
def bus_dst(direction, name, dy, w):   # tile RECEIVES the bus (destination)
    return _pad(direction, "NULL", "0", str(dy), name, str(w))

def find_bel(bel):
    # robust BEL source lookup (root first, so it never collides with the copy we write into
    # Tile/QMUL/qmul_r0/; avoids the Tile/qmul vs Tile/QMUL case-collision on some filesystems)
    for p in (os.path.join(ROOT, bel),
              os.path.join(ROOT, "bel_src", bel),
              os.path.join(ROOT, "Tile", "QMUL", "qmul_r0", bel),
              os.path.join(ROOT, "Tile", "qmul", bel),
              os.path.join(ROOT, "Tile", "QMUL", bel)):
        if os.path.isfile(p):
            return p
    raise FileNotFoundError(f"BEL '{bel}' not found (looked in ./, ./bel_src/, Tile/QMUL/qmul_r0/, "
                            "Tile/qmul/, Tile/QMUL/). Put the Booth-Wallace BEL at ./{bel}.".format(bel=bel))

def write_tile(name, csv_bus, matrix_lines, bel=None):
    d = os.path.join(QDIR, name); os.makedirs(d, exist_ok=True)
    csv = CSV_HDR.format(name=name) + csv_bus
    if bel:
        src = find_bel(bel); dst = os.path.join(d, bel)
        if os.path.abspath(src) != os.path.abspath(dst):
            shutil.copy(src, dst)
        csv += _pad("BEL", f"./{bel}")
    csv += _pad("MATRIX", f"./{name}_switch_matrix.list") + _pad("EndTILE")
    open(os.path.join(d, f"{name}.csv"), "w").write(csv)
    ml = [f"# {name}"] + through_routing() + [""] + matrix_lines
    open(os.path.join(d, f"{name}_switch_matrix.list"), "w").write("\n".join(ml) + "\n")

# ================================================================ build the four sub-tiles
shutil.rmtree(QDIR, ignore_errors=True)   # clean any stale/merged Tile/QMUL before regenerating
# ---- qmul_r0 (bottom, boothmult BEL) ----------------------------------------------------
csv0 = bus_dst("SOUTH", "dC", 1, 48) + bus_src("NORTH", "uA", -1, 24)
m0 = []
for i in range(16):                                  # a0..a15 <- local *END (+consts)
    m0 += feed_input(f"a{i}", i, const=True)
for i in range(16):                                  # a16..a31 <- dC[0..15]
    m0.append(f"a{i+16},dC{i}")
for i in range(32):                                  # b0..b31 <- dC[16..47]
    m0.append(f"b{i},dC{i+16}")
for i in range(8):                                   # q0..q7 -> local *BEG (spread)
    m0 += drive_output(f"q{i}", i)
for i in range(24):                                  # uA[0..23] <- q8..q31
    m0.append(f"uA{i},q{i+8}")
write_tile("qmul_r0", csv0, m0, bel="boothmult.v")

# ---- qmul_r1 --------------------------------------------------------------------------
csv1 = (bus_dst("SOUTH", "dB", 1, 32) + bus_src("SOUTH", "dC", 1, 48) +
        bus_src("NORTH", "uB", -1, 16) + bus_dst("NORTH", "uA", -1, 24))
m1 = []
for i in range(16):                                  # a16..a31 (local) -> dC[0..15]
    m1 += feed_input(f"dC{i}", i)
for i in range(32):                                  # dC[16..47] <- dB[0..31] (forward down)
    m1.append(f"dC{i+16},dB{i}")
for i in range(8):                                   # q8..q15 delivered (uA[0..7]) -> *BEG
    m1 += drive_output(f"uA{i}", i)
for i in range(16):                                  # uB[0..15] <- uA[8..23] (forward up)
    m1.append(f"uB{i},uA{i+8}")
write_tile("qmul_r1", csv1, m1)

# ---- qmul_r2 --------------------------------------------------------------------------
csv2 = (bus_dst("SOUTH", "dA", 1, 16) + bus_src("SOUTH", "dB", 1, 32) +
        bus_src("NORTH", "uC", -1, 8) + bus_dst("NORTH", "uB", -1, 16))
m2 = []
for i in range(16):                                  # b0..b15 (local) -> dB[0..15]
    m2 += feed_input(f"dB{i}", i)
for i in range(16):                                  # dB[16..31] <- dA[0..15] (forward down)
    m2.append(f"dB{i+16},dA{i}")
for i in range(8):                                   # q16..q23 delivered (uB[0..7]) -> *BEG
    m2 += drive_output(f"uB{i}", i)
for i in range(8):                                   # uC[0..7] <- uB[8..15] (forward up)
    m2.append(f"uC{i},uB{i+8}")
write_tile("qmul_r2", csv2, m2)

# ---- qmul_r3 (top) --------------------------------------------------------------------
csv3 = bus_src("SOUTH", "dA", 1, 16) + bus_dst("NORTH", "uC", -1, 8)
m3 = []
for i in range(16):                                  # b16..b31 (local) -> dA[0..15]
    m3 += feed_input(f"dA{i}", i)
for i in range(8):                                   # q24..q31 delivered (uC[0..7]) -> *BEG
    m3 += drive_output(f"uC{i}", i)
write_tile("qmul_r3", csv3, m3)

# ---- supertile definition -------------------------------------------------------------
open(os.path.join(QDIR, "QMUL.csv"), "w").write(
    "SuperTILE,QMUL,\nqmul_r3,\nqmul_r2,\nqmul_r1,\nqmul_r0,\nEndSuperTILE,\n")

print(f"SINKS(BEG)={len(SINKS)}  ENDS={len(ENDS)}  dirs={DIRS}  TR={TR} FI={FI} FO={FO}")
for t in ("qmul_r0", "qmul_r1", "qmul_r2", "qmul_r3"):
    n = sum(1 for _ in open(os.path.join(QDIR, t, f"{t}_switch_matrix.list")))
    print(f"  {t}: {n} matrix lines")
print("wrote Tile/QMUL/  (qmul_r0..r3 + QMUL.csv). BEL boothmult in qmul_r0.")

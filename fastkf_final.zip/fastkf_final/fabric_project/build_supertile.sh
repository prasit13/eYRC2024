#!/usr/bin/env bash
# =============================================================================
# build_supertile.sh  --  build the full 34-multiply spatial fast-KF bitstream
# using the qmul SUPERTILE (the channel-width fix).  Run on a >=32 GB machine
# (Codespace 16-core/32GB or your 64GB workstation).  Fabric-gen + synth are
# light; only nextpnr P&R needs the RAM.
#
#   bash build_supertile.sh
# Output: build/kf.fasm  build/kf.bin  build/kf.hex  build/pnr.log
# =============================================================================
set -euo pipefail
cd "$(cd "$(dirname "$0")" && pwd)"; PROJ="$(pwd)"

echo "== [0/7] tools =="
command -v FABulous >/dev/null 2>&1 || { curl -LsSf https://astral.sh/uv/install.sh | sh; export PATH="$HOME/.local/bin:$PATH"; uv tool install fabulous-fpga; }
command -v nextpnr-generic >/dev/null 2>&1 || FABulous install oss-cad-suite || true
for d in "$HOME/.FABulous/oss-cad-suite/bin" "$HOME/.local/share/uv/tools/fabulous-fpga/bin"; do [ -d "$d" ] && export PATH="$d:$PATH"; done
hash -r
echo "  RAM: $(free -h | awk '/Mem/{print $2" total, "$7" avail"}')"

echo "== [1/7] (re)generate the qmul SUPERTILE (Tile/QMUL/qmul_r0..r3 + QMUL.csv) =="
python3 gen_qmul_supertile.py

echo "== [2/7] clean stale generated files =="
find Tile -type f \( -name '*_switch_matrix.v' -o -name '*_ConfigMem.v' -o -name '*_ConfigMem.csv' \
  -o -name '*generated_switch_matrix*' -o -name '*.json' \) -delete 2>/dev/null || true
rm -f Fabric/eFPGA*.v Fabric/models_pack.v .FABulous/pips.txt .FABulous/bel*.txt .FABulous/bitStreamSpec.* 2>/dev/null || true
rm -rf build && mkdir -p build
sed -i '/FAB_MODELS_PACK/d' .FABulous/.env 2>/dev/null || true   # let FABulous auto-guess

echo "== [3/7] generate fabric + nextpnr model + eFPGA_top =="
printf 'load_fabric\nrun_FABulous_fabric\nexit\n' > gen.tcl
FABulous . -fs gen.tcl
grep -aoE '(UIN_top|UOUT_top)[[:space:]]*\[[0-9]+:0\]' Fabric/eFPGA_top.v | sort -u
echo "  qmul supertiles (boothmult BELs): $(grep -ac boothmult .FABulous/bel.txt)"

echo "== [4/7] regen gen_copro wrapper + integration =="
python3 script/gen_copro.py wrapper
python3 script/gen_copro.py integration user_design/xif_copro_efpga.v

echo "== [5/7] synth user design -> build/kf.json =="
yosys -p "synth_fabulous -top top_wrapper -json build/kf.json -extra-plib user_design/custom_prims.v" \
  user_design/top_wrapper.v user_design/xif_copro_sync.v user_design/kf_copro.v user_design/qmw.v 2>&1 | tail -20

echo "== [6/7] PLACE & ROUTE with router2 (the RAM-hungry step; supertile removes the congestion) =="
FAB_ROOT="$PROJ" nextpnr-generic --uarch fabulous --router router2 \
  --json build/kf.json -o fasm=build/kf.fasm 2>&1 | tee build/pnr.log | tail -40
test -s build/kf.fasm || { echo "ROUTE FAILED (watch the 'remaining arcs' column in build/pnr.log; if it reaches 0 it routed). If it plateaus, widen: python3 widen_fabric.py or add qmul columns."; exit 3; }

echo "== [7/7] bit_gen =="
bit_gen -genBitstream build/kf.fasm .FABulous/bitStreamSpec.bin build/kf.bin
python3 Test/makehex.py build/kf.bin 16384 build/kf.hex
echo "DONE.  NWORDS = $(( $(stat -c%s build/kf.bin) / 4 )).  Copy build/kf.{fasm,bin,hex} + fabric.csv back."

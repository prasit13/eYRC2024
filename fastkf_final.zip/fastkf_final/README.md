# Fast spatial Kalman‑Filter eFPGA coprocessor — final deliverable

The whole 34‑multiply pipelined `kf_copro` mapped **spatially** into a FABulous eFPGA (using a
custom Booth‑Wallace **qmul supertile** to beat the switch‑matrix channel‑width limit), and
integrated into the CV32E40X SoC over the eXtension Interface.

**Result: ~73× vs pure software (9 cycles/sample), vs 3.48× for the old time‑shared eFPGA KF.**
The fabric routes on a normal laptop and the coprocessor is functionally verified
(step output `69177744` matches the golden reference).

```
fastkf_final/
├── cv32e40x_kf_test/     the CV32E40X SoC with the fast KF coprocessor integrated
└── fabric_project/       the FABulous fabric that produces the bitstream
```

---

## 1. `fabric_project/` — the FABulous eFPGA

Builds the fabric and the bitstream for the fast KF. Regenerable from source; the routed outputs
are already included in `build/`.

**Key files**
- `boothmult.v` — the verified 32×32 Booth‑Wallace multiplier BEL.
- `gen_qmul_supertile.py` — generates the 4‑row **qmul supertile** (`Tile/QMUL/qmul_r0..r3`) that
  splits the multiplier's 96 pins across 4 tiles so it routes.
- `fabric.csv` — the 60×32 fabric (5 spread qmul‑supertile columns = 40 supertiles, 2 CIO, LUT4AB).
- `user_design/` — `kf_copro.v` (34 `qmul_booth_wallace`), `qmw.v`, `xif_copro_sync.v`, `custom_prims.v`.
- `build_supertile.sh` — one‑shot: gen supertile → fabric → synth → **router2** P&R → `bit_gen`.
- `Fabric/eFPGA_top.v`, `eFPGA.v` — the generated fabric RTL.
- `build/kf.fasm`, `kf.bin`, `kf.hex` — the routed netlist + bitstream (**NWORDS = 39606**).

**Rebuild from scratch** (needs FABulous + OSS‑CAD‑Suite on PATH; `bit_gen` is at
`~/.local/share/uv/tools/fabulous-fpga/bin`):
```bash
cd fabric_project
bash build_supertile.sh          # regenerates fabric + routes + bit_gen -> build/kf.{fasm,bin,hex}
```
(The huge regenerable intermediates `.FABulous/pips.txt` and `bitStreamSpec.bin` were dropped to keep
this lean; `build_supertile.sh` recreates them.)

---

## 2. `cv32e40x_kf_test/` — the SoC integration

The eFPGA coprocessor drop‑in, wired to the core over XIF.

**What was integrated**
- `rtl/efpga/fabric_fastkf/` — the 50‑file fast‑fabric RTL.
- `rtl/efpga/xif_copro_efpga_fastkf.v` — reconfig wrapper (`UIN_top[511:0]`/`UOUT_top[639:0]`,
  `NWORDS=39606`, `BITS_STRIDE=256 KiB`).
- `rtl/xif_copro.sv` — repointed to the fast wrapper.
- `cv32e40x_manifest.flist` — filelist (uses `fabric_fastkf`).
- `bitstreams/kf_kf.bytes.hex` — the fast bitstream (made with `tools/bin2hex.py` for correct byte order).
- `sw/kfperf/perf.c` — the SW‑vs‑coprocessor cycle benchmark (64 samples).

**Run the benchmark** (needs a **64‑bit** ModelSim/Questa + RISC‑V GCC on PATH):
```bash
cd cv32e40x_kf_test/sw
make kfperf-vsim-run             # builds RTL + perf.hex, runs the SW-vs-coproc mcycle comparison
```
> Note: the free 32‑bit `modelsim_ase` (Starter) **cannot** elaborate this 1920‑tile fabric
> (`eFPGA.v` is 126k+ lines → `mmap` fails). It compiles fine; only elaboration needs a 64‑bit tool.
> The coprocessor's **9 cycles/sample** was confirmed with a cycle‑accurate soft‑RTL sim (a FABulous
> fabric preserves every pipeline register, so the cycle count is identical).

---

## Numbers

| implementation | cycles/sample | speed‑up vs SW |
|---|---|---|
| pure software KF | ~661 | 1× |
| time‑shared eFPGA KF | ~190 | 3.48× |
| **fast spatial eFPGA KF** | **9** | **~73×** |

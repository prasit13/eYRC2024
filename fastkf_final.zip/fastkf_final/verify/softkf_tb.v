`timescale 1ns/1ps
module softkf_tb;
  reg clk_i=0, rst_ni, compressed_valid_i, issue_valid_i;
  reg [31:0] issue_req_instr_i; reg [1:0] issue_req_mode_i; reg [3:0] issue_req_id_i;
  reg [63:0] issue_req_rs_i; reg [1:0] issue_req_rs_valid_i;
  reg commit_valid_i, commit_kill_i; reg [3:0] commit_id_i;
  reg mem_ready_i, mem_resp_exc_i; reg [5:0] mem_resp_exccode_i; reg mem_resp_dbg_i;
  reg mem_result_valid_i; reg [31:0] mem_result_rdata_i; reg mem_result_err_i, mem_result_dbg_i;
  reg result_ready_i;
  wire compressed_ready_o; wire [31:0] compressed_resp_instr_o; wire compressed_resp_accept_o;
  wire issue_ready_o, issue_resp_accept_o, issue_resp_writeback_o, issue_resp_dualwrite_o;
  wire [2:0] issue_resp_dualread_o; wire issue_resp_loadstore_o, issue_resp_ecswrite_o, issue_resp_exc_o;
  wire mem_valid_o; wire [3:0] mem_req_id_o; wire [1:0] mem_req_mode_o; wire mem_req_we_o;
  wire [2:0] mem_req_size_o; wire [3:0] mem_req_be_o; wire [1:0] mem_req_attr_o;
  wire [31:0] mem_req_wdata_o; wire mem_req_last_o, mem_req_spec_o; wire [31:0] mem_req_addr_o;
  wire result_valid_o; wire [3:0] result_id_o; wire [31:0] result_data_o; wire [4:0] result_rd_o;
  wire result_we_o; wire [5:0] result_ecsdata_o; wire [2:0] result_ecswe_o; wire result_exc_o;
  wire [5:0] result_exccode_o; wire result_err_o, result_dbg_o;
  xif_copro_verilog dut(.*);
  always #5 clk_i=~clk_i;
  integer j,cyc,total=0,nst=0; reg fg; reg [31:0] fd;
  task idle; begin compressed_valid_i=0;issue_valid_i=0;issue_req_instr_i=0;issue_req_mode_i=0;
    issue_req_id_i=0;issue_req_rs_i=0;issue_req_rs_valid_i=0;commit_valid_i=0;commit_kill_i=0;commit_id_i=0;
    mem_ready_i=1;mem_resp_exc_i=0;mem_resp_exccode_i=0;mem_resp_dbg_i=0;mem_result_valid_i=0;
    mem_result_rdata_i=0;mem_result_err_i=0;mem_result_dbg_i=0;result_ready_i=1;rst_ni=0; end endtask
  task do_step; input [31:0] y; input [3:0] id; begin fg=0;fd=0;cyc=0;
    @(negedge clk_i); issue_valid_i=1; issue_req_instr_i={7'd0,5'd0,5'd0,3'b000,5'd1,7'h0B};
    issue_req_rs_i={32'h0,y}; issue_req_rs_valid_i=2'b01; issue_req_id_i=id;
    @(posedge clk_i); cyc=cyc+1; j=0; while(!issue_ready_o && j<300) begin @(posedge clk_i);cyc=cyc+1;j=j+1; end
    @(negedge clk_i); issue_valid_i=0; commit_valid_i=1; commit_id_i=id; @(negedge clk_i); commit_valid_i=0;
    for(j=0;j<1200 && !fg;j=j+1) begin @(posedge clk_i);cyc=cyc+1; if(result_valid_o) begin fg=1;fd=result_data_o; end @(negedge clk_i); end
    if(fg) begin total=total+cyc;nst=nst+1; $display("  step y=%0d -> %0d   [%0d cycles]",y,fd,cyc); end
    else $display("  step y=%0d NO RESULT (%0d cyc)",y,cyc);
    repeat(4)@(posedge clk_i); end endtask
  initial begin idle;
    #20; rst_ni=0; repeat(8)@(posedge clk_i); rst_ni=1; repeat(20)@(posedge clk_i);
    $display("soft kf_copro coproc: measuring cycles/sample");
    do_step(69120357,1); do_step(69180207,2); do_step(69200000,3); do_step(69210000,4); do_step(69220000,5);
    if(nst>0) $display("SOFT-KF-COPROC: %0d steps, AVG %0d CYCLES/SAMPLE (= fabric cycles/sample)",nst,total/nst);
    $finish; end
endmodule

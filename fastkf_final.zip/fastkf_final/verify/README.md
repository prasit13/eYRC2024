# Verifying the fast KF coprocessor on this machine

## Quick (seconds) — cycle-accurate, works here
```bash
bash verify_cycles.sh
```
Drives the real `xif_copro_verilog` XIF handshake into the soft `kf_copro`. Because a FABulous
fabric preserves every pipeline register, this gives the IDENTICAL cycles/sample and numeric result
as the routed fabric. Expect: **9 cycles/sample**, step output **69177744** (matches golden).

## Full fabric (slow) — configures the actual routed bitstream
```bash
bash verify_fabric.sh      # iverilog; ~30-60 min to compile the 1920-tile fabric
```
Configures the real fabric from `build/kf.hex` and runs KF steps through it. Definitive, but slow.
The 32-bit `modelsim_ase` cannot do this (mmap fails on the 126k-line eFPGA.v); a 64-bit
ModelSim/Questa runs the full SoC benchmark: `cd ../cv32e40x_kf_test/sw && make kfperf-vsim-run`.

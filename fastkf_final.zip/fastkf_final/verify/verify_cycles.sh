#!/usr/bin/env bash
# Cycle-accurate coprocessor verification (runs in SECONDS with plain iverilog).
# A FABulous fabric preserves every pipeline register, so the soft kf_copro driven through the
# real xif_copro_verilog XIF handshake gives the IDENTICAL cycles/sample as the routed fabric,
# and the same numeric result.  Verifies: 9 cycles/sample + output 69177744 (matches golden).
set -e; cd "$(dirname "$0")"
iverilog -g2012 -s softkf_tb -o /tmp/softkf.vvp \
  ../cv32e40x_kf_test/rtl/kf_copro.v \
  ../fabric_project/user_design/xif_copro_sync.v \
  softkf_tb.v
vvp /tmp/softkf.vvp

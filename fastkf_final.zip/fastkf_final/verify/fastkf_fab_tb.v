`timescale 1ps/1ps
`define NWORDS 39606
module fastkf_fab_tb;
  reg [511:0] UIN_top; wire [639:0] UOUT_top;
  wire [63:0] eF_I,eF_T; wire [127:0] eF_A,eF_B; wire eF_ca,eF_rl;
  reg CLK=0, resetn=1, SelfWriteStrobe=0; reg [31:0] SelfWriteData=0;
  `include "tb_copro_map.vh"
  eFPGA_top top_i (.I_top(eF_I),.T_top(eF_T),.O_top(64'b0),.A_config_C(eF_A),.B_config_C(eF_B),
    .UIN_top(UIN_top),.UOUT_top(UOUT_top),.CLK(CLK),.resetn(resetn),
    .SelfWriteStrobe(SelfWriteStrobe),.SelfWriteData(SelfWriteData),
    .Rx(1'b1),.ComActive(eF_ca),.ReceiveLED(eF_rl),.s_clk(1'b0),.s_data(1'b0));
  always @(*) begin UIN_top=512'b0; `DRIVE_UIN end
  wire        f_iready = UOUT_top[`OB_issue_ready_o];
  wire        f_rvalid = UOUT_top[`OB_result_valid_o];
  wire [31:0] f_rdata  = UOUT_top[`OB_result_data_o +: `OW_result_data_o];
  reg [7:0] bitstream[0:`NWORDS*4-1]; localparam MAX=`NWORDS*4;
  always #5000 CLK=(CLK===1'b0);
  integer i,j,errors=0,cyc,total=0,nst=0; reg [4095:0] hexarg; reg fg; reg [31:0] fd;
  task idle; begin compressed_valid_i=0; issue_valid_i=0; issue_req_instr_i=0; issue_req_mode_i=0;
    issue_req_id_i=0; issue_req_rs_i=0; issue_req_rs_valid_i=0; commit_valid_i=0; commit_kill_i=0;
    commit_id_i=0; mem_ready_i=1; mem_resp_exc_i=0; mem_resp_exccode_i=0; mem_resp_dbg_i=0;
    mem_result_valid_i=0; mem_result_rdata_i=0; mem_result_err_i=0; mem_result_dbg_i=0; result_ready_i=1; rst_ni=0; end endtask
  task do_step; input [31:0] y; input [3:0] id; begin fg=0; fd=0; cyc=0;
    @(negedge CLK); issue_valid_i=1; issue_req_instr_i={7'd0,5'd0,5'd0,3'b000,5'd1,7'h0B};
    issue_req_rs_i={32'h0,y}; issue_req_rs_valid_i=2'b01; issue_req_id_i=id;
    @(posedge CLK); cyc=cyc+1; j=0; while(!f_iready && j<300) begin @(posedge CLK); cyc=cyc+1; j=j+1; end
    @(negedge CLK); issue_valid_i=0; commit_valid_i=1; commit_id_i=id; @(negedge CLK); commit_valid_i=0;
    for(j=0;j<1200 && !fg;j=j+1) begin @(posedge CLK); cyc=cyc+1; if(f_rvalid) begin fg=1; fd=f_rdata; end @(negedge CLK); end
    if(fg) begin total=total+cyc; nst=nst+1; end
    if(!fg) begin errors=errors+1; $display("  step y=%0d: NO RESULT after %0d cyc",y,cyc); end
    else $display("  step y=%0d -> %0d   [%0d cycles]",y,fd,cyc);
    repeat(4)@(posedge CLK); end endtask
  initial begin idle;
    if(!$value$plusargs("bitstream_hex=%s",hexarg)) begin $display("no bitstream_hex"); $finish; end
    $readmemh(hexarg,bitstream);
    #100; resetn=0; #10000; resetn=1; #10000; repeat(20)@(posedge CLK); #2500;
    $display("config load (%0d words)...",`NWORDS);
    for(i=0;i<MAX;i=i+4) begin SelfWriteData<={bitstream[i],bitstream[i+1],bitstream[i+2],bitstream[i+3]};
      repeat(2)@(posedge CLK); SelfWriteStrobe<=1; @(posedge CLK); SelfWriteStrobe<=0; end
    repeat(40)@(posedge CLK); rst_ni=1; repeat(30)@(posedge CLK);
    $display("config done, running KF steps (measuring coproc cycles/sample)...");
    do_step(69120357,1); do_step(69180207,2); do_step(69200000,3); do_step(69210000,4); do_step(69220000,5);
    if(nst>0) $display("FASTKF-FABRIC-SIM: %0d steps OK, AVG %0d CYCLES/SAMPLE (errors=%0d)",nst,total/nst,errors);
    else $display("FASTKF-FABRIC-SIM: FAIL (no results, errors=%0d)",errors);
    $finish; end
endmodule

#!/usr/bin/env bash
# FULL-FABRIC verification: configures the REAL routed 1920-tile fabric with the bitstream
# (build/kf.hex), streams KF samples through the XIF, and checks the configured fabric computes
# the KF + measures cycles/sample.
#   - modelsim_ase (32-bit, free Starter) CANNOT elaborate this fabric (eFPGA.v ~126k lines -> mmap fails).
#   - iverilog CAN, but compiling the fabric is SLOW (~30-60 min). Be patient.
set -e; cd "$(dirname "$0")"
FF=../cv32e40x_kf_test/rtl/efpga/fabric_fastkf
cp -f ../fabric_project/Test/tb_copro_map.vh .
echo "[1/2] compiling the full fabric (slow: ~30-60 min in iverilog)..."
iverilog -g2012 -s fastkf_fab_tb -o /tmp/fastkf_fab.vvp "$FF"/*.v fastkf_fab_tb.v
echo "[2/2] running (config 39606 words, then KF steps)..."
vvp /tmp/fastkf_fab.vvp +bitstream_hex=../fabric_project/build/kf.hex

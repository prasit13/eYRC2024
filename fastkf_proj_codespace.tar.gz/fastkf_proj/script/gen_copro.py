#!/usr/bin/env python3
"""Generator for the XIF-coprocessor-on-eFPGA flow (FABulous 2.0).

=============================================================================
USAGE EXAMPLES (Run these from the project root directory, where scripts/ is):
=============================================================================

1. Generate the fabric.csv
   Usage: python3 scripts/gen_copro.py fabric <rows> <cio_cols> <lut_cols>
   Example: python3 scripts/gen_copro.py fabric 8 2 10
   (This creates fabric.csv in the root directory)

2. Generate the Top Wrapper and Testbench Map
   Usage: python3 scripts/gen_copro.py wrapper
   Example: python3 scripts/gen_copro.py wrapper
   (This reads Fabric/eFPGA_top.v and writes user_design/top_wrapper.v 
   and Test/tb_copro_map.vh)

3. Generate the Drop-in Integration RTL
   Usage: python3 scripts/gen_copro.py integration <output_path.v>
   Example: python3 scripts/gen_copro.py integration user_design/xif_copro_efpga.v
   (This generates the synthesizable wrapper that replaces the coprocessor)

4. Generate the Synthesizable Bitstream ROM
   Usage: python3 scripts/gen_copro.py rom <input_bitstream.bin> <output_rom.v>
   Example: python3 scripts/gen_copro.py rom user_design/xif_copro_sync.bin user_design/efpga_bitstream_rom.v
   (This converts your generated bitstream into a Verilog ROM module)

=============================================================================

Subcommands:
  fabric   -> emit fabric.csv (W_IO west cap + CIO IO columns + LUT4AB logic)
  wrapper  -> parse the generated Fabric/eFPGA_top.v and emit
              user_design/top_wrapper.v (coproc + placed CIO BELs) and
              Test/tb_copro_map.vh (UIN_top/UOUT_top <-> coproc bit packing).

Bit packing convention (the single source of truth tying everything together):
  - Coproc INPUT ports (declaration order, excluding clk_i) are packed LSB-first
    into cin[NIN-1:0]: port `name[W-1:0]` occupies cin[base +: W], cin[base+k]=name[k].
  - Coproc OUTPUT ports packed the same way into cout[NOUT-1:0].
  - The wrapper connects cin[g] to the CIO BEL pin that eFPGA_top exposes as
    UIN_top[g]; likewise cout[g] <-> UOUT_top[g]. So UIN_top[g] drives coproc
    input-bit g, and UOUT_top[g] reads coproc output-bit g.
"""
import re, sys, os

# MODIFIED: Points to the user_design directory instead of two levels up
COPROC = os.path.join(os.path.dirname(__file__), "..", "user_design", "xif_copro_sync.v")
MODULE = "xif_copro_verilog"


def parse_ports(path):
    src = open(path).read()
    m = re.search(r'module\s+' + MODULE + r'\s*#\([^)]*\)\s*\((.*?)\);', src, re.S)
    ins, outs = [], []
    for line in m.group(1).splitlines():
        line = line.split('//')[0].strip().rstrip(',')
        mm = re.match(r'(input|output)\s+wire\s*(\[(\d+):(\d+)\])?\s*(\w+)', line)
        if not mm:
            continue
        d = mm.group(1)
        w = int(mm.group(3)) - int(mm.group(4)) + 1 if mm.group(2) else 1
        name = mm.group(5)
        if name == 'clk_i':
            continue
        (ins if d == 'input' else outs).append((name, w))
    return ins, outs


def pack(ports):
    """Return list of (name, width, base) and total width."""
    base = 0
    out = []
    for name, w in ports:
        out.append((name, w, base))
        base += w
    return out, base


def gen_fabric(rows, cio_cols, lut_cols):
    """Columns: col0=W_IO, then cio_cols CIO columns, then lut_cols LUT4AB columns."""
    width = 1 + cio_cols + lut_cols
    # top terminator row: NULL over W_IO (no vert wires), N_term over the rest
    def term_row(t):
        return ['NULL'] + [t] * (cio_cols + lut_cols)
    body = ['W_IO'] + ['CIO'] * cio_cols + ['LUT4AB'] * lut_cols
    lines = ['FabricBegin' + ',' * 17]
    lines.append(','.join(term_row('N_term_single')) + ',,#')
    for _ in range(rows):
        lines.append(','.join(body) + ',,#')
    lines.append(','.join(term_row('S_term_single')) + ',,#')
    lines.append('FabricEnd' + ',' * 17)
    lines += ['', ',' * 17, 'ParametersBegin' + ',' * 17,
              'ConfigBitMode,frame_based,,,frame_based',
              'GenerateDelayInSwitchMatrix,80',
              'MultiplexerStyle,custom,#,custom',
              'SuperTileEnable,TRUE,#,TRUE', '']
    for t in ['LUT4AB', 'N_term_single', 'S_term_single', 'W_IO', 'CIO']:
        lines.append(f'Tile,./Tile/{t}/{t}.csv')
    lines += ['', 'ParametersEnd' + ',' * 17, '']
    return '\n'.join(lines) + '\n'


def parse_efpga_top(path):
    """Return inmap[g]=(tile,pin), outmap[g]=(tile,pin), and NIN, NOUT vector widths."""
    txt = open(path).read()
    inmap, outmap = {}, {}
    for tile, pin, g in re.findall(r'\.Tile_(X\d+Y\d+)_UIN_top(\d+)\(UIN_top\[(\d+)\]\)', txt):
        inmap[int(g)] = (tile, int(pin))
    for tile, pin, g in re.findall(r'\.Tile_(X\d+Y\d+)_UOUT_top(\d+)\(UOUT_top\[(\d+)\]\)', txt):
        outmap[int(g)] = (tile, int(pin))
    nin = max(inmap) + 1 if inmap else 0
    nout = max(outmap) + 1 if outmap else 0
    return inmap, outmap, nin, nout


def gen_wrapper(efpga_top):
    ins, outs = parse_ports(COPROC)
    ip, NIN = pack(ins)
    op, NOUT = pack(outs)
    inmap, outmap, vNIN, vNOUT = parse_efpga_top(efpga_top)
    assert vNIN >= NIN, f"fabric has {vNIN} top-inputs, need {NIN}"
    assert vNOUT >= NOUT, f"fabric has {vNOUT} top-outputs, need {NOUT}"

    # group BEL pin connections by tile
    tiles = {}
    for g, (tile, pin) in inmap.items():
        tiles.setdefault(tile, {'UIN': {}, 'UOUT': {}})['UIN'][pin] = g
    for g, (tile, pin) in outmap.items():
        tiles.setdefault(tile, {'UIN': {}, 'UOUT': {}})['UOUT'][pin] = g

    L = []
    L.append("// AUTO-GENERATED by gen_copro.py -- do not edit.")
    L.append("module top_wrapper;")
    L.append(f"    wire [{NIN-1}:0] cin;")
    L.append(f"    wire [{NOUT-1}:0] cout;")
    L.append("    wire clk;")
    L.append("    (* keep *) Global_Clock clk_i_bel (.CLK(clk));")
    L.append("")
    # coproc instance
    L.append(f"    {MODULE} dut (")
    conns = ["        .clk_i(clk)"]
    for name, w, base in ip:
        sl = f"cin[{base}]" if w == 1 else f"cin[{base+w-1}:{base}]"
        conns.append(f"        .{name}({sl})")
    for name, w, base in op:
        sl = f"cout[{base}]" if w == 1 else f"cout[{base+w-1}:{base}]"
        conns.append(f"        .{name}({sl})")
    L.append(",\n".join(conns))
    L.append("    );")
    L.append("")
    # CIO BEL instances (only tiles that carry at least one used pin)
    inst = 0
    for tile in sorted(tiles, key=lambda t: (int(re.search(r'X(\d+)', t).group(1)),
                                             int(re.search(r'Y(\d+)', t).group(1)))):
        d = tiles[tile]
        used = any(g < NIN for g in d['UIN'].values()) or any(g < NOUT for g in d['UOUT'].values())
        if not used:
            continue
        pins = []
        for pin in range(8):
            g = d['UIN'].get(pin)
            if g is not None and g < NIN:
                pins.append(f".UIN{pin}(cin[{g}])")
        for pin in range(10):
            g = d['UOUT'].get(pin)
            if g is not None and g < NOUT:
                pins.append(f".UOUT{pin}(cout[{g}])")
            else:
                pins.append(f".UOUT{pin}(1'b0)")
        L.append(f'    (* keep, BEL="{tile}.A" *) CIO_GenIO cio_{tile} (' + ", ".join(pins) + ");")
        inst += 1
    L.append("endmodule")
    sys.stderr.write(f"wrapper: {inst} CIO BELs, NIN={NIN}, NOUT={NOUT}, fabric vNIN={vNIN} vNOUT={vNOUT}\n")

    # testbench map include
    T = []
    T.append("// AUTO-GENERATED by gen_copro.py -- coproc<->fabric bit map.")
    T.append("// Golden coproc input regs:")
    for name, w in ins:
        T.append(f"    reg {'' if w==1 else f'[{w-1}:0] '}{name};")
    T.append("// Golden coproc output wires:")
    for name, w in outs:
        T.append(f"    wire {'' if w==1 else f'[{w-1}:0] '}{name}_g;")
    T.append("")
    T.append("`define COPRO_GOLD_INST \\")
    gi = [f"        .clk_i(CLK)"]
    for name, w in ins:
        gi.append(f"        .{name}({name})")
    for name, w in outs:
        gi.append(f"        .{name}({name}_g)")
    T.append(f"    {MODULE} gold ( \\")
    T.append(" , \\\n".join(gi) + " )")
    T.append("")
    T.append("`define DRIVE_UIN \\")
    drive = []
    for name, w, base in ip:
        drive.append(f"        UIN_top[{base} +: {w}] = {name}")
    T.append(" ; \\\n".join(drive) + " ;")
    T.append("")
    T.append("// output compare: returns 1 if any mismatch")
    T.append("`define CHECK_UOUT(ERR) \\")
    chk = []
    for name, w, base in op:
        chk.append(f'        if (UOUT_top[{base} +: {w}] !== {name}_g) begin ERR = 1\'b1; '
                   f'$display("  MISMATCH {name}: fab=%h gold=%h", UOUT_top[{base} +: {w}], {name}_g); end')
    T.append(" \\\n".join(chk))
    T.append("")
    T.append(f"`define NIN {NIN}")
    T.append(f"`define NOUT {NOUT}")
    T.append(f"`define VNIN {vNIN}")
    T.append(f"`define VNOUT {vNOUT}")
    T.append("")
    T.append("// Per-output bit-base / width into UOUT_top (for protocol-gated checks)")
    for name, w, base in op:
        T.append(f"`define OB_{name} {base}")
        T.append(f"`define OW_{name} {w}")
    return "\n".join(L) + "\n", "\n".join(T) + "\n"


# --- Outputs the fabric genuinely computes for BITREV (taken from the eFPGA). ---
LIVE_OUTPUTS = {
    "issue_ready_o", "issue_resp_accept_o", "issue_resp_writeback_o",
    "result_valid_o", "result_id_o", "result_data_o", "result_rd_o", "result_we_o",
}
# Outputs that equal an input (combinational pass-through in the RTL).
PASSTHROUGH_OUTPUTS = {"compressed_ready_o": "compressed_valid_i"}
# "valid"-class live outputs that must be forced inactive until the fabric is configured.
GATED_OUTPUTS = {"issue_ready_o", "issue_resp_accept_o", "result_valid_o"}
# Everything else is structurally constant / dead for a BITREV-only coprocessor and is
# hard-tied here (the Greyhound hard/soft split) -- value 0 is the RTL-correct constant
# for every one of them (mem path gated by mem_valid_o=0, ecs/exc/err/dbg all 0).


def gen_integration(efpga_top):
    """Emit a synthesizable rtl/efpga/xif_copro_efpga.v that is pin-compatible with
    xif_copro_verilog but maps the live datapath onto the eFPGA fabric, hard-ties the
    dead outputs, and self-configures from an on-chip bitstream ROM."""
    ins, outs = parse_ports(COPROC)
    ip, NIN = pack(ins)
    op, NOUT = pack(outs)
    inmap, outmap, vNIN, vNOUT = parse_efpga_top(efpga_top)
    rst_base = dict((n, b) for n, w, b in ip)["rst_ni"]

    L = []
    L.append("// AUTO-GENERATED by gen_copro.py (integration) -- do not edit.")
    L.append("// Drop-in, synthesizable replacement for xif_copro_verilog: the live BITREV")
    L.append("// datapath runs on the FABulous eFPGA (eFPGA_top), configured at reset from an")
    L.append("// on-chip bitstream ROM; dead/constant outputs are hard-tied. Same port list as")
    L.append("// xif_copro_verilog, so xif_copro.sv connects to it identically.")
    L.append("module xif_copro_efpga #(")
    L.append("  parameter XLEN = 32, parameter INPUT_BUFFER_DEPTH = 1, parameter FORWARDING = 1")
    L.append(") (")
    decl = ["  input  wire        clk_i", "  input  wire        rst_ni"]
    for name, w in ins:
        if name == "rst_ni":
            continue
        decl.append(f"  input  wire {'      ' if w==1 else f'[{w-1}:0]'.rjust(6)} {name}")
    for name, w in outs:
        decl.append(f"  output wire {'      ' if w==1 else f'[{w-1}:0]'.rjust(6)} {name}")
    L.append(",\n".join(decl))
    L.append(");")
    L.append("")
    L.append(f"  wire [{vNIN-1}:0] UIN_top;")
    L.append(f"  wire [{vNOUT-1}:0] UOUT_top;")
    L.append("  wire        cfg_done;       // fabric configured + coproc out of reset")
    L.append("  wire        coproc_rstn;    // functional reset to the mapped coproc (active low)")
    L.append("  wire        cfg_strobe;")
    L.append("  wire [31:0] cfg_data;")
    L.append("  // unused fabric IO (W_IO bidirectional pads + config-access taps)")
    L.append("  wire [27:0] eF_I_top, eF_T_top;")
    L.append("  wire [55:0] eF_A_cfg, eF_B_cfg;")
    L.append("  wire        eF_ComActive, eF_ReceiveLED;")
    L.append("")
    L.append("  // ---- input packing: coproc inputs -> UIN_top (rst_ni is loader-controlled) ----")
    if vNIN > NIN:
        L.append(f"  assign UIN_top[{vNIN-1}:{NIN}] = {vNIN-NIN}'b0;  // spare fabric inputs")
    for name, w, base in ip:
        sl = f"UIN_top[{base}]" if w == 1 else f"UIN_top[{base+w-1}:{base}]"
        if name == "rst_ni":
            L.append(f"  assign {sl} = coproc_rstn;")
        else:
            L.append(f"  assign {sl} = {name};")
    L.append("")
    L.append("  // ---- output mapping: live from eFPGA, dead hard-tied (RTL-correct constants) ----")
    for name, w, base in op:
        sl = f"UOUT_top[{base}]" if w == 1 else f"UOUT_top[{base+w-1}:{base}]"
        if name in PASSTHROUGH_OUTPUTS:
            L.append(f"  assign {name} = {PASSTHROUGH_OUTPUTS[name]};")
        elif name in LIVE_OUTPUTS:
            if name in GATED_OUTPUTS:
                L.append(f"  assign {name} = cfg_done & {sl};")
            else:
                L.append(f"  assign {name} = {sl};")
        else:
            L.append(f"  assign {name} = {w}'b0;")
    L.append("")
    L.append("  // ---- bitstream loader (on-chip ROM -> SelfWrite config port) ----")
    L.append("  efpga_config_loader loader (")
    L.append("    .clk_i(clk_i), .rst_ni(rst_ni),")
    L.append("    .cfg_strobe_o(cfg_strobe), .cfg_data_o(cfg_data),")
    L.append("    .coproc_rstn_o(coproc_rstn), .cfg_done_o(cfg_done)")
    L.append("  );")
    L.append("")
    L.append("  // ---- the FABulous eFPGA fabric ----")
    L.append("  eFPGA_top efpga_i (")
    L.append("    .A_config_C(eF_A_cfg), .B_config_C(eF_B_cfg),")
    L.append("    .I_top(eF_I_top), .O_top(28'b0), .T_top(eF_T_top),")
    L.append("    .UIN_top(UIN_top), .UOUT_top(UOUT_top),")
    L.append("    .CLK(clk_i), .resetn(rst_ni),")
    L.append("    .SelfWriteStrobe(cfg_strobe), .SelfWriteData(cfg_data),")
    L.append("    .Rx(1'b1), .ComActive(eF_ComActive), .ReceiveLED(eF_ReceiveLED),")
    L.append("    .s_clk(1'b0), .s_data(1'b0)")
    L.append("  );")
    L.append("endmodule")
    return "\n".join(L) + "\n"


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: gen_copro.py [fabric|wrapper|integration|rom] [args...]")
        sys.exit(1)

    cmd = sys.argv[1]
    here = os.path.dirname(__file__)
    proj = os.path.join(here, "..")
    if cmd == "fabric":
        rows = int(sys.argv[2]); cio = int(sys.argv[3]); lut = int(sys.argv[4])
        open(os.path.join(proj, "fabric.csv"), "w").write(gen_fabric(rows, cio, lut))
        print(f"wrote fabric.csv: {rows} rows, {cio} CIO cols, {lut} LUT cols")
    elif cmd == "wrapper":
        wrap, tb = gen_wrapper(os.path.join(proj, "Fabric", "eFPGA_top.v"))
        open(os.path.join(proj, "user_design", "top_wrapper.v"), "w").write(wrap)
        open(os.path.join(proj, "Test", "tb_copro_map.vh"), "w").write(tb)
        print("wrote user_design/top_wrapper.v and Test/tb_copro_map.vh")
    elif cmd == "integration":
        out = sys.argv[2]  # output .v path
        open(out, "w").write(gen_integration(os.path.join(proj, "Fabric", "eFPGA_top.v")))
        print(f"wrote {out}")
    elif cmd == "rom":
        binpath = sys.argv[2]; out = sys.argv[3]
        data = open(binpath, "rb").read()
        nbytes = 16384  # MAX_BITBYTES (matches the proven loader/testbench length)
        data = data + b"\x00" * (nbytes - len(data))
        nwords = nbytes // 4
        R = ["// AUTO-GENERATED by gen_copro.py (rom) -- bitstream as a synthesizable ROM.",
             f"// {nwords} words; word k = {{bin[4k], bin[4k+1], bin[4k+2], bin[4k+3]}}.",
             "module efpga_bitstream_rom (",
             f"  input  wire [{(nwords-1).bit_length()-1}:0] addr_i,",
             "  output reg  [31:0]      data_o",
             ");",
             f"  localparam NWORDS = {nwords};",
             "  always @(*) begin",
             "    case (addr_i)"]
        for k in range(nwords):
            w = (data[4*k] << 24) | (data[4*k+1] << 16) | (data[4*k+2] << 8) | data[4*k+3]
            R.append(f"      {(nwords-1).bit_length()}'d{k}: data_o = 32'h{w:08X};")
        R += ["      default: data_o = 32'h00000000;",
              "    endcase", "  end", "endmodule"]
        open(out, "w").write("\n".join(R) + "\n")
        print(f"wrote {out}: {nwords} words from {binpath}")

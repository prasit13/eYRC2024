
//Warning: The primitive CIO_GenIO was added by FABulous automatically.
(* blackbox, keep *)
module CIO_GenIO (
    input UOUT0,
    input UOUT1,
    input UOUT2,
    input UOUT3,
    input UOUT4,
    input UOUT5,
    input UOUT6,
    input UOUT7,
    input UOUT8,
    input UOUT9,
    output UIN0,
    output UIN1,
    output UIN2,
    output UIN3,
    output UIN4,
    output UIN5,
    output UIN6,
    output UIN7,
    (* iopad_external_pin *)
    input UIN_top0,
    (* iopad_external_pin *)
    input UIN_top1,
    (* iopad_external_pin *)
    input UIN_top2,
    (* iopad_external_pin *)
    input UIN_top3,
    (* iopad_external_pin *)
    input UIN_top4,
    (* iopad_external_pin *)
    input UIN_top5,
    (* iopad_external_pin *)
    input UIN_top6,
    (* iopad_external_pin *)
    input UIN_top7,
    (* iopad_external_pin *)
    output UOUT_top0,
    (* iopad_external_pin *)
    output UOUT_top1,
    (* iopad_external_pin *)
    output UOUT_top2,
    (* iopad_external_pin *)
    output UOUT_top3,
    (* iopad_external_pin *)
    output UOUT_top4,
    (* iopad_external_pin *)
    output UOUT_top5,
    (* iopad_external_pin *)
    output UOUT_top6,
    (* iopad_external_pin *)
    output UOUT_top7,
    (* iopad_external_pin *)
    output UOUT_top8,
    (* iopad_external_pin *)
    output UOUT_top9
);
endmodule
(* blackbox *)
module boothmult(a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18,a19,a20,a21,a22,a23,a24,a25,a26,a27,a28,a29,a30,a31,b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,b16,b17,b18,b19,b20,b21,b22,b23,b24,b25,b26,b27,b28,b29,b30,b31,q0,q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11,q12,q13,q14,q15,q16,q17,q18,q19,q20,q21,q22,q23,q24,q25,q26,q27,q28,q29,q30,q31);
  input a0;
  input a1;
  input a2;
  input a3;
  input a4;
  input a5;
  input a6;
  input a7;
  input a8;
  input a9;
  input a10;
  input a11;
  input a12;
  input a13;
  input a14;
  input a15;
  input a16;
  input a17;
  input a18;
  input a19;
  input a20;
  input a21;
  input a22;
  input a23;
  input a24;
  input a25;
  input a26;
  input a27;
  input a28;
  input a29;
  input a30;
  input a31;
  input b0;
  input b1;
  input b2;
  input b3;
  input b4;
  input b5;
  input b6;
  input b7;
  input b8;
  input b9;
  input b10;
  input b11;
  input b12;
  input b13;
  input b14;
  input b15;
  input b16;
  input b17;
  input b18;
  input b19;
  input b20;
  input b21;
  input b22;
  input b23;
  input b24;
  input b25;
  input b26;
  input b27;
  input b28;
  input b29;
  input b30;
  input b31;
  output q0;
  output q1;
  output q2;
  output q3;
  output q4;
  output q5;
  output q6;
  output q7;
  output q8;
  output q9;
  output q10;
  output q11;
  output q12;
  output q13;
  output q14;
  output q15;
  output q16;
  output q17;
  output q18;
  output q19;
  output q20;
  output q21;
  output q22;
  output q23;
  output q24;
  output q25;
  output q26;
  output q27;
  output q28;
  output q29;
  output q30;
  output q31;
endmodule

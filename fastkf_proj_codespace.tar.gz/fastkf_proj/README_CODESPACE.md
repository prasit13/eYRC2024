# Fast-KF eFPGA — build the full spatial bitstream on a GitHub Codespace

The full **34-multiplier spatial `kf_copro`** maps to a ~1900-tile FABulous fabric. `nextpnr`
needs ~5 GB just to *load* that model and `router2` (the router that can actually route this
dense multiplier datapath) needs more — a 7.4 GB laptop OOMs. A **GitHub Codespace with a big
machine type** (docs §3.1.2 "Using FABulous in GitHub Codespaces") has the headroom.

This bundle is **source only** (no giant regenerated `pips.txt` / `bitStreamSpec.bin`); the build
script regenerates everything on the Codespace.

## Steps

1. **Create the Codespace** (your GitHub account):
   - Go to the FABulous repo → green **Code** button → **Codespaces** tab → **"New with options…"**.
   - **Machine type: 16-core / 32 GB** (or larger). *This is the whole point — do not pick 2/4-core.*
   - Region: nearest to you. Create.

2. **Drop this bundle into the Codespace** — either:
   - drag-and-drop `fastkf_proj.tar.gz` into the VS Code file explorer, then in the terminal:
     ```bash
     tar xzf fastkf_proj.tar.gz && cd fastkf_proj
     ```
   - or `git add` it to a repo you push, then clone inside the Codespace.

3. **Run the one-shot build** (≈45–70 min total; the P&R is the long part):
   ```bash
   bash build_on_codespace.sh
   ```
   It installs FABulous + OSS-CAD-Suite if missing, regenerates the fabric, synthesizes the
   design, routes with **router2**, and produces the bitstream.

4. **If P&R still congests** (watch `build/pnr.log` — the `arcs` column plateaus instead of
   reaching 0), give it more routing room and retry:
   ```bash
   python3 widen_fabric.py 84 32 6     # wider fabric, qmul cols spread out; UIN/UOUT unchanged
   bash build_on_codespace.sh
   ```
   You can go wider still (`96 32 8`) — 32 GB has room.

5. **Copy the results back to the laptop:**
   ```
   build/kf.fasm   build/kf.bin   build/kf.hex   build/pnr.log
   fabric.csv                       # <-- the FINAL one used (in case widen_fabric.py changed it)
   ```
   Also note the printed **`bitstream words (NWORDS …)`** and the **`eFPGA_top ports`** line.
   From `fabric.csv` I regenerate the matching fabric RTL locally (fabric-gen does NOT OOM — only
   P&R does), so I don't need the multi-MB `Fabric/eFPGA*.v` copied back.

## What happens after you bring `kf.hex` + NWORDS back

I wire the fast fabric into the CPU exactly like the existing time-shared KF:
- new `rtl/efpga/xif_copro_efpga_fastkf.v` (the reconfig wrapper, widths `UIN_top[511:0]` /
  `UOUT_top[639:0]`, `NWORDS` = the number you copied back),
- repoint `rtl/xif_copro.sv` at it, swap the fabric RTL into the filelist, load `kf.hex` at
  `BITS_BASE`, and run the ModelSim SoC sim to measure the per-sample cycle count → the speedup
  over the 3.48× time-shared version.

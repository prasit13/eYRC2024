#!/usr/bin/env python3
# widen_fabric.py -- escalation lever if router2 still congests on the default 60x32 fabric.
# Emits a WIDER fabric (more LUT4AB routing headroom, qmul columns spread further apart so the
# 96-pin multiplier tiles don't form routing "walls").  KEEPS exactly 2 CIO columns, so the
# UIN_top[511:0] / UOUT_top[639:0] widths -- and therefore the CV wrapper -- are UNCHANGED.
#
#   python3 widen_fabric.py [COLS] [ROWS] [NQMUL_COLS]
# defaults: 84 cols x 32 rows, 6 qmul columns  (~48% LC utilisation, lots of routing room)
import sys
COLS = int(sys.argv[1]) if len(sys.argv) > 1 else 84
ROWS = int(sys.argv[2]) if len(sys.argv) > 2 else 32
NQ   = int(sys.argv[3]) if len(sys.argv) > 3 else 6

# spread NQ qmul columns evenly across the logic area (cols 3..COLS-1)
lo, hi = 6, COLS - 3
qcols = {int(round(lo + (hi - lo) * i / (NQ - 1))) for i in range(NQ)} if NQ > 1 else {COLS // 2}

def tile(c):
    if c == 0:      return "W_IO"
    if c in (1, 2): return "CIO"
    if c in qcols:  return "qmul"
    return "LUT4AB"

nt = "NULL," + ",".join("N_term_single" for _ in range(1, COLS)) + ","
st = "NULL," + ",".join("S_term_single" for _ in range(1, COLS)) + ","
rows = "\n".join(",".join(tile(c) for c in range(COLS)) + "," for _ in range(ROWS))
params = ("\nFabricEnd,\n\nParametersBegin,\nConfigBitMode,frame_based\n"
          "GenerateDelayInSwitchMatrix,80\nMultiplexerStyle,custom\n"
          "Tile,./Tile/LUT4AB/LUT4AB.csv\nTile,./Tile/W_IO/W_IO.csv\nTile,./Tile/CIO/CIO.csv\n"
          "Tile,./Tile/qmul/qmul.csv\nTile,./Tile/N_term_single/N_term_single.csv\n"
          "Tile,./Tile/S_term_single/S_term_single.csv\nParametersEnd,\n")
open("fabric.csv", "w").write("FabricBegin,\n" + nt + "\n" + rows + "\n" + st + "\n" + params)

nl = sum(1 for _ in range(ROWS) for c in range(COLS) if tile(c) == "LUT4AB")
print(f"wrote fabric.csv: {COLS}x{ROWS}={COLS*ROWS} tiles | qmul cols {sorted(qcols)} "
      f"({len(qcols)*ROWS} qmul) | {nl} LUT4AB ({nl*8} LC) | util~{9390/(nl*8)*100:.0f}%  "
      f"(CIO=2 cols -> UIN_top[511:0]/UOUT_top[639:0] unchanged)")

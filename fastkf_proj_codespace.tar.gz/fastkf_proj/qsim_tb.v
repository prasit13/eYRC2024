`timescale 1ps/1ps
module qsim_tb;
  reg CLK=0,resetn=1,SWS=0; reg [31:0] SWD=0;
  wire [7:0] I_top,T_top; reg [7:0] O_top=0; wire [15:0] Ac,Bc; wire ca,rl;
  eFPGA_top dut(.A_config_C(Ac),.B_config_C(Bc),.I_top(I_top),.O_top(O_top),.T_top(T_top),
    .CLK(CLK),.resetn(resetn),.SelfWriteStrobe(SWS),.SelfWriteData(SWD),
    .Rx(1'b1),.ComActive(ca),.ReceiveLED(rl),.s_clk(1'b0),.s_data(1'b0));
  always #5000 CLK=~CLK;
  reg [7:0] bs[0:2423]; integer i;
  initial begin
    $readmemh("user_design/qt.hex",bs);
    #100; resetn=0; #20000; resetn=1; #20000; repeat(20)@(posedge CLK);
    for(i=0;i<2424;i=i+4) begin SWD<={bs[i],bs[i+1],bs[i+2],bs[i+3]};
      repeat(2)@(posedge CLK); SWS<=1; @(posedge CLK); SWS<=0; end
    repeat(60)@(posedge CLK);
    $display("After config: I_top = %b (result drives one of these)", I_top);
    $display((I_top!==8'b0 && I_top!==8'bx) ? "QMUL-TILE-SIM: PASS -- 3.0*5.0 result bit is HIGH" : "QMUL-TILE-SIM: result not high");
    $finish;
  end
endmodule

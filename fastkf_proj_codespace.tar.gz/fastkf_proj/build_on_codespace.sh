#!/usr/bin/env bash
# =============================================================================
# build_on_codespace.sh
# One-shot: build the FULL spatial fast-KF eFPGA bitstream on a big-RAM machine.
#
# WHY:  the 34-multiplier spatial kf_copro maps to a ~1900-tile FABulous fabric.
#       nextpnr needs ~5 GB just to LOAD that fabric model, and router2
#       (the congestion-aware router that can route this dense datapath) needs
#       more.  A 7.4 GB laptop OOMs.  A GitHub Codespace "16-core / 32 GB"
#       (docs section 3.1.2) has the headroom.  This script runs the whole
#       fabric-gen -> synth -> route -> bitstream flow there.
#
# RUN (from inside the extracted fastkf_proj/ directory):
#       bash build_on_codespace.sh
#
# OUTPUT (copy these back to the laptop):
#       build/kf.fasm   build/kf.bin   build/kf.hex   build/pnr.log
# =============================================================================
set -euo pipefail
cd "$(cd "$(dirname "$0")" && pwd)"
PROJ="$(pwd)"
echo "### project: $PROJ"

echo "== [0/6] ensure tools on PATH =="
if ! command -v FABulous >/dev/null 2>&1; then
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="$HOME/.local/bin:$PATH"
  uv tool install fabulous-fpga
fi
# nextpnr / yosys / bit_gen from the OSS-CAD-Suite that FABulous installs
if ! command -v nextpnr-generic >/dev/null 2>&1; then
  FABulous install oss-cad-suite || true
fi
for d in "$HOME/.FABulous/oss-cad-suite/bin" "$HOME/.local/share/uv/tools/fabulous-fpga/bin"; do
  [ -d "$d" ] && export PATH="$d:$PATH"
done
hash -r
echo "  FABulous : $(command -v FABulous)"
echo "  yosys    : $(command -v yosys)   ($(yosys --version 2>/dev/null | head -1))"
echo "  nextpnr  : $(command -v nextpnr-generic)  ($(nextpnr-generic --version 2>&1 | head -1))"
echo "  bit_gen  : $(command -v bit_gen || echo 'via FABulous bin')"
echo "  RAM      : $(free -h | awk '/Mem/{print $2" total, "$7" avail"}')"

echo "== [1/6] clean any stale generated files (force a clean regen) =="
find Tile -type f \( -name '*_switch_matrix.v' -o -name '*_ConfigMem.v' \
  -o -name '*_ConfigMem.csv' -o -name '*generated_switch_matrix*' -o -name '*.json' \) -delete 2>/dev/null || true
rm -f Fabric/eFPGA.v Fabric/eFPGA_top.v Fabric/models_pack.v \
      .FABulous/pips.txt .FABulous/bel.txt .FABulous/bel.v2.txt \
      .FABulous/bitStreamSpec.bin .FABulous/bitStreamSpec.csv 2>/dev/null || true
rm -rf build && mkdir -p build

echo "== [2/6] generate fabric + nextpnr model + eFPGA_top (~30-40 min) =="
printf 'load_fabric\nrun_FABulous_fabric\nexit\n' > gen.tcl
FABulous . -fs gen.tcl
test -s Fabric/eFPGA_top.v || { echo "FABRIC GEN FAILED"; exit 2; }
echo "  eFPGA_top ports:"; grep -aoE '(UIN_top|UOUT_top)[[:space:]]*\[[0-9]+:0\]' Fabric/eFPGA_top.v | sort -u

echo "== [3/6] synth user design (top_wrapper) -> build/kf.json =="
yosys -p "synth_fabulous -top top_wrapper -json build/kf.json -extra-plib user_design/custom_prims.v" \
  user_design/top_wrapper.v user_design/xif_copro_sync.v user_design/kf_copro.v user_design/qmw.v \
  2>&1 | tee build/synth.log | tail -30

echo "== [4/6] PLACE & ROUTE with router2 (this is the memory-hungry step) =="
FAB_ROOT="$PROJ" nextpnr-generic --uarch fabulous --router router2 \
  --json build/kf.json -o fasm=build/kf.fasm 2>&1 | tee build/pnr.log | tail -40
if [ ! -s build/kf.fasm ]; then
  echo "############################################################"
  echo "# ROUTE FAILED: no FASM produced. If it OOM'd, use a bigger #"
  echo "# Codespace machine.  If it congested (arcs plateau in      #"
  echo "# pnr.log), widen the fabric: run  python3 widen_fabric.py  #"
  echo "# then re-run this script.                                  #"
  echo "############################################################"
  exit 3
fi

echo "== [5/6] bit_gen -> bitstream =="
bit_gen -genBitstream build/kf.fasm .FABulous/bitStreamSpec.bin build/kf.bin
python3 Test/makehex.py build/kf.bin 16384 build/kf.hex

echo "== [6/6] DONE =="
ls -la build/kf.fasm build/kf.bin build/kf.hex
echo "bitstream words (NWORDS for the CV wrapper) = $(grep -c . build/kf.hex)"
echo "Copy build/kf.{fasm,bin,hex} + build/pnr.log back to the laptop."

 //Generative IO BEL for CIO_GenIO
 //This is a generated file, please don't edit!

module CIO_GenIO
    #(
        parameter NoConfigBits=0
    )
    (
        output  UIN0,
        output  UIN1,
        output  UIN2,
        output  UIN3,
        output  UIN4,
        output  UIN5,
        output  UIN6,
        output  UIN7,
        input  UOUT0,
        input  UOUT1,
        input  UOUT2,
        input  UOUT3,
        input  UOUT4,
        input  UOUT5,
        input  UOUT6,
        input  UOUT7,
        input  UOUT8,
        input  UOUT9,
        (* FABulous, EXTERNAL *) input  UIN_top0,
        (* FABulous, EXTERNAL *) input  UIN_top1,
        (* FABulous, EXTERNAL *) input  UIN_top2,
        (* FABulous, EXTERNAL *) input  UIN_top3,
        (* FABulous, EXTERNAL *) input  UIN_top4,
        (* FABulous, EXTERNAL *) input  UIN_top5,
        (* FABulous, EXTERNAL *) input  UIN_top6,
        (* FABulous, EXTERNAL *) input  UIN_top7,
        (* FABulous, EXTERNAL *) output  UOUT_top0,
        (* FABulous, EXTERNAL *) output  UOUT_top1,
        (* FABulous, EXTERNAL *) output  UOUT_top2,
        (* FABulous, EXTERNAL *) output  UOUT_top3,
        (* FABulous, EXTERNAL *) output  UOUT_top4,
        (* FABulous, EXTERNAL *) output  UOUT_top5,
        (* FABulous, EXTERNAL *) output  UOUT_top6,
        (* FABulous, EXTERNAL *) output  UOUT_top7,
        (* FABulous, EXTERNAL *) output  UOUT_top8,
        (* FABulous, EXTERNAL *) output  UOUT_top9
    );


assign UIN0 = UIN_top0;
assign UIN1 = UIN_top1;
assign UIN2 = UIN_top2;
assign UIN3 = UIN_top3;
assign UIN4 = UIN_top4;
assign UIN5 = UIN_top5;
assign UIN6 = UIN_top6;
assign UIN7 = UIN_top7;
assign UOUT_top0 = UOUT0;
assign UOUT_top1 = UOUT1;
assign UOUT_top2 = UOUT2;
assign UOUT_top3 = UOUT3;
assign UOUT_top4 = UOUT4;
assign UOUT_top5 = UOUT5;
assign UOUT_top6 = UOUT6;
assign UOUT_top7 = UOUT7;
assign UOUT_top8 = UOUT8;
assign UOUT_top9 = UOUT9;

endmodule


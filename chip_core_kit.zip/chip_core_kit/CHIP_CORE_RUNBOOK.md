# chip_core RTL→GDS — correct step-by-step runbook

The clean linear "happy path" for taking chip_core (CV32E40X + eFPGA_top macro + 8 SRAMs, GF180MCU)
through to a signed-off GDS. Do the steps **in order** — each one gates the next. When a step *fails*,
jump to the matching branch in `CHIP_CORE_DRC_DEBUG.md`; this doc is the path when things go right.

Built on verified facts (not assumptions):
- eFPGA_top is DRC/LVS/antenna-clean standalone → every chip_core issue is integration-level.
- The convergence blocker is **macro pin placement**, fixed in Step 1.
- SRAM has Metal3 power pins; Magic over-reports macro internals; `IO_PIN_ORDER_CFG`/`MAGIC_DRC_USE_GDS`
  are the real levers (`MAGIC_EXT_USE_GDS_BLACKBOX` is not a real variable).

---

## Step 0 — Environment + prerequisites (institute PC, ≥32 GB)

```bash
source $HOME/fabulous_offline_bundle/activate.sh
export PROJ=$HOME/fabulous_self PDK_ROOT=$PROJ/gf180mcu
cd $PROJ
TAIL="--pdk gf180mcuD --pdk-root $PDK_ROOT --manual-pdk --design-dir $PROJ \
  --skip Checker.SetupViolations --skip Checker.HoldViolations \
  --skip Checker.MaxSlewViolations --skip Checker.MaxCapViolations"
export CFG=work/librelane/chip_core_recon/config.yaml      # adjust tag if yours differs
export PDN=work/librelane/chip_core/pdn_cfg.tcl
export RECON=cv32e40x_updated_with_coproc_working_verilog_recon_efpga   # adjust to your RTL dir name
```
Prereq check (hardened ring tiles present for the stitch):
```bash
ls work/ip/efpga/tiles/    # expect: LUT4AB CIO W_IO N_term_single S_term_single
```

---

## Step 1 — Re-harden eFPGA_top with ALL signal pins on the WEST edge  *(the gating fix)*

The default I/O placer scatters the 590 pins on all 4 edges; in chip_core the ~209 east-edge pins then have
to cross the whole macro to reach the CPU → unroutable horizontal congestion. Force them all west (toward
the CPU).

**1a. Create `work/librelane/efpga_stitch/pin_order.cfg`:**
```
#W
UIN_top.*
UOUT_top.*
I_top.*
O_top.*
T_top.*
A_config_C.*
B_config_C.*
SelfWriteData.*
CLK
resetn
Rx
s_clk
s_data
SelfWriteStrobe
ComActive
ReceiveLED
#N
#E
#S
```

**1b. Regenerate the stitch config and add the pin-order keys:**
```bash
python3 work/gen_stitch.py "$RECON/rtl/efpga/fabric/eFPGA.v" \
        work/ip/efpga/tiles work/librelane/efpga_stitch/config.yaml
cat >> work/librelane/efpga_stitch/config.yaml <<'YAML'
IO_PIN_ORDER_CFG: dir::work/librelane/efpga_stitch/pin_order.cfg
ERRORS_ON_UNMATCHED_IO: none
YAML
```
> To make it survive future regenerations, add `"IO_PIN_ORDER_CFG: dir::work/librelane/efpga_stitch/pin_order.cfg",`
> and `"ERRORS_ON_UNMATCHED_IO: none",` to gen_stitch.py's emit list instead of appending.

**1c. Re-stitch (~4 h) and adopt the new macro:**
```bash
rm -rf runs/efpga_stitch
eval librelane work/librelane/efpga_stitch/config.yaml $TAIL --run-tag efpga_stitch
LEF=$(ls runs/efpga_stitch/*writelef*/eFPGA_top.lef | head -1)
cp runs/efpga_stitch/*magic-streamout*/eFPGA_top.gds work/ip/efpga/eFPGA_top.gds
cp "$LEF"                                            work/ip/efpga/eFPGA_top.lef
cp runs/efpga_stitch/*detailedrouting*/eFPGA_top.nl.v work/ip/efpga/eFPGA_top.nl.v
```

**Success check — every signal pin must be on the WEST edge:**
```bash
awk '/^ *PIN /{p=$2} /LAYER Metal3/{getline; if($1=="RECT"){x=($2+$4)/2; if(!s[p]){s[p]=1; print (x<60?"W":"OTHER")}}}' \
    work/ip/efpga/eFPGA_top.lef | sort | uniq -c
# want: almost all "W", no/few "OTHER"
```
DRC/LVS/antenna for the stitch should still be 0 (pin placement doesn't change internals).
*If the stitch itself congests → `CHIP_CORE_DRC_DEBUG.md` PHASE A0 note (move light config buses to #N/#S).*

---

## Step 2 — chip_core floorplan + PDN config

**2a. In `$CFG`, set the floorplan so the logic strip has room and routing fails fast if not:**
```yaml
GRT_ALLOW_CONGESTION: false
DIE_AREA:  [0, 0, 4900, 6320]
CORE_AREA: [20, 20, 4880, 6300]
PL_TARGET_DENSITY_PCT: 30
FP_MACRO_HORIZONTAL_HALO: 10
FP_MACRO_VERTICAL_HALO: 10
```
Macro placement — eFPGA right (so its west pin edge faces the CPU strip), SRAMs spread to ~150 µm channels:
```yaml
MACROS:
  eFPGA_top:
    instances:
      "u_cpu.xif_copro_i.xif_copro_verilog_i.efpga_i": {location: [1900, 75], orientation: N}
  gf180mcu_fd_ip_sram__sram512x8m8wm1:
    instances:
      "u_mem.g_bank[0].g_lane[0].u_sram": {location: [120, 120],  orientation: N}
      "u_mem.g_bank[0].g_lane[1].u_sram": {location: [700, 120],  orientation: N}
      "u_mem.g_bank[0].g_lane[2].u_sram": {location: [120, 720],  orientation: N}
      "u_mem.g_bank[0].g_lane[3].u_sram": {location: [700, 720],  orientation: N}
      "u_mem.g_bank[1].g_lane[0].u_sram": {location: [120, 1320], orientation: N}
      "u_mem.g_bank[1].g_lane[1].u_sram": {location: [700, 1320], orientation: N}
      "u_mem.g_bank[1].g_lane[2].u_sram": {location: [120, 1920], orientation: N}
      "u_mem.g_bank[1].g_lane[3].u_sram": {location: [700, 1920], orientation: N}
```

**2b. In `$PDN`, connect the SRAM via its Metal3 rail only (delete the Metal2 bridge):**
```tcl
# DELETE: add_pdn_connect -grid macro -layers "Metal2 $::env(PDN_VERTICAL_LAYER)"
# KEEP:
add_pdn_connect -grid macro -layers "Metal3 $::env(PDN_VERTICAL_LAYER)"
```

---

## Step 3 — Global-routing convergence gate  (~30 min, iterate here, NOT in the 5 h run)

```bash
rm -rf runs/chip_core_recon
eval librelane $CFG $TAIL --run-tag chip_core_recon --to OpenROAD.GlobalRouting
R=$(ls -td runs/chip_core_recon* | head -1)
grep -iE "congestion|overflow|GRT-00" $R/*globalrouting*/*.log | tail -40
```
**Success:** no overflow / "congestion: 0". Proceed to Step 4.
**Fail:** do **not** run the full route — fix and re-run this 30-min step:
- overflow over the eFPGA → Step 1 didn't put pins west (re-check 1c output).
- overflow at SRAM coords → widen channels (col2 700→760, row pitch 600→660) / halos →14.
- overflow along the eFPGA west edge → widen die X 4900→5400, eFPGA [1900,75]→[2300,75].
- spread/global overflow → `PL_TARGET_DENSITY_PCT` 30→22.
(Full branch logic: `CHIP_CORE_DRC_DEBUG.md` PHASE A4.)

---

## Step 4 — Full route + streamout (only after Step 3 is clean)

```bash
rm -rf runs/chip_core_recon
eval librelane $CFG $TAIL --run-tag chip_core_recon --to KLayout.StreamOut
R=$(ls -td runs/chip_core_recon* | head -1)
grep -iE "number of violations|completing" $R/*detailedrouting*/*.log | tail -5   # want ~0, not oscillating
grep -ch PSM-0069 $R/*generatepdn*/*.log                                          # power connected → want 0
ls -la $R/*klayout-streamout*/chip_core.gds
```
If it aborts on a timing/extraction step, add `--skip OpenROAD.RCX --skip OpenROAD.STAPostPNR
--skip OpenROAD.IRDropReport` and re-run.

---

## Step 5 — Signoff config (DRC / LVS / XOR)

In `$CFG` add:
```yaml
MAGIC_DRC_USE_GDS: false            # Magic checks abstract view → SRAM 5V / eFPGA internals not re-flagged
RUN_HEURISTIC_DIODE_INSERTION: true # antenna on the long CPU→eFPGA routes
HEURISTIC_ANTENNA_THRESHOLD: 90
RUN_FILL_INSERTION: true            # metal density floor near macro boundaries
PRIMARY_GDSII_STREAMOUT_TOOL: klayout   # XOR Via3 rendering diffs → use KLayout GDS as signoff
```
LVS power for the eFPGA black box — do NOT edit nl.v; declare the connection instead:
```yaml
PDN_MACRO_CONNECTIONS:
  - ".*u_sram VDD VSS VDD VSS"
  - ".*efpga_i VDD VSS VDD VSS"
# and remove eFPGA_top from IGNORE_DISCONNECTED_MODULES
```
Leave `KLAYOUT_DRC_OPTIONS` at `run_mode: deep`, `topcell: chip_core` (it correctly black-boxes the IP).

---

## Step 6 — Run DRC + LVS

```bash
eval librelane $CFG $TAIL --last-run --from Magic.WriteLEF --to Checker.LVS
R=$(ls -td runs/chip_core_recon* | head -1)
grep -oE "<category>[^<]+</category>" $R/*klayout-drc*/*.lyrdb 2>/dev/null | sed -E 's#</?category>##g' | sort | uniq -c | sort -rn
sed -n '/Subcircuit summary/,/Cell pin lists/p' $R/*netgen-lvs*/*.log | head -120
```
Expected: Magic DRC small (chip-level only), KLayout DRC ~0–50 (residual density), XOR 0, LVS 0
(or 2 waivable eFPGA supply pins). Any residual → `CHIP_CORE_DRC_DEBUG.md` PHASE C/D branches.

---

## Step 7 — Final signed-off views

```bash
R=$(ls -td runs/chip_core_recon* | head -1)
ls -la $R/final/gds/chip_core.gds $R/final/lef/chip_core.lef $R/final/nl/chip_core.nl.v
# adopt for chip_top (padframe) integration:
cp $R/final/gds/chip_core.gds work/ip/chip_core/chip_core.gds
cp $R/final/lef/chip_core.lef work/ip/chip_core/chip_core.lef
cp $R/final/nl/chip_core.nl.v work/ip/chip_core/chip_core.nl.v
```
Next stage = chip_top / padframe (see `RECON_RTL_TO_GDS_BIGMACHINE.md`).

---

## One-glance checklist

| Step | Action | Pass condition |
|---|---|---|
| 1 | Re-stitch eFPGA, all pins `#W` | pin check shows all "W"; stitch DRC/LVS/ant = 0 |
| 2 | Floorplan + drop Metal2 PDN bridge | config saved |
| 3 | GRT gate (30 min) | no overflow |
| 4 | Full route + streamout | DRT ~0, PSM-0069 = 0, GDS exists |
| 5 | Signoff config | keys set |
| 6 | DRC + LVS | Magic small, KLayout ~0–50, XOR 0, LVS 0 |
| 7 | Collect final GDS/LEF/nl | files present |

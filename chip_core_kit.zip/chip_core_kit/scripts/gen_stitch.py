#!/usr/bin/env python3
# eFPGA fabric stitch generator: reads eFPGA.v (the tile grid) and the 5 hardened
# tile LEFs, lays the 76 tiles out in a column/row grid, and emits a LibreLane
# config.yaml that places every tile macro -> produces the REAL eFPGA_top macro.
#
# CORRECTED: now also emits IO_PIN_ORDER_CFG so ALL eFPGA signal pins are placed on the
# WEST edge (facing the CPU in chip_core). Without this, the default placer scatters pins
# on all 4 edges and chip_core global routing congests trying to cross the macro.
import re, sys, os, collections
EFPGA_V, TILE_DIR, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
def lef_size(t):
    s=open(os.path.join(TILE_DIR,t,f"{t}.lef")).read()
    m=re.search(r"SIZE\s+([\d.]+)\s+BY\s+([\d.]+)", s); return float(m.group(1)), float(m.group(2))
TYPES=["LUT4AB","CIO","W_IO","N_term_single","S_term_single"]
W={t:lef_size(t)[0] for t in TYPES}; H={t:lef_size(t)[1] for t in TYPES}
grid={}
for x,y,t in re.findall(r"Tile_X(\d+)Y(\d+)_(LUT4AB|CIO|W_IO|N_term_single|S_term_single)\b", open(EFPGA_V).read()):
    grid[(int(x),int(y))]=t
xs=sorted({k[0] for k in grid}); ys=sorted({k[1] for k in grid})
GX=GY=80.0; MARGIN=150.0
colw={c:max(W[grid[(c,r)]] for r in ys if (c,r) in grid) for c in xs}
rowh={r:max(H[grid[(c,r)]] for c in xs if (c,r) in grid) for r in ys}
colx={}; x=MARGIN
for c in xs: colx[c]=x; x+=colw[c]+GX
DIE_W=x-GX+MARGIN
rowy={}; y=MARGIN
for r in ys: rowy[r]=y; y+=rowh[r]+GY
DIE_H=y-GY+MARGIN
bytype=collections.defaultdict(list)
for (c,r),t in grid.items(): bytype[t].append((f"eFPGA_inst.Tile_X{c}Y{r}_{t}", round(colx[c],2), round(rowy[r],2)))
P="cv32e40x_updated_with_coproc_working_verilog_recon_efpga/rtl/efpga/fabric"; IP="work/ip/efpga/tiles"
infra=["eFPGA_top","eFPGA","eFPGA_Config","ConfigFSM","Frame_Data_Reg","Frame_Select","config_UART","bitbang","models_pack"]
L=["# eFPGA fabric stitch: 76 tile macros placed + routed -> real eFPGA_top.",
   "DESIGN_NAME: eFPGA_top","VERILOG_FILES:"]
for m in infra: L.append(f'  - "dir::{P}/{m}.v"')
L+=['CLOCK_PORT: "CLK"','CLOCK_PERIOD: 40','FP_SIZING: absolute',
    f"DIE_AREA: [0, 0, {DIE_W:.2f}, {DIE_H:.2f}]", f"CORE_AREA: [20, 20, {DIE_W-20:.2f}, {DIE_H-20:.2f}]",
    "PL_TARGET_DENSITY_PCT: 25","ERROR_ON_SYNTH_CHECKS: false","RUN_LINTER: false","GRT_ALLOW_CONGESTION: true",
    "RUN_POST_GPL_DESIGN_REPAIR: false","DESIGN_REPAIR_BUFFER_INPUT_PORTS: false","RUN_POST_GRT_DESIGN_REPAIR: false",
    "RUN_CTS: false","RUN_POST_CTS_RESIZER_TIMING: false","FP_PDN_SKIPTRIM: true","PDN_CORE_RING: false",
    # Put ALL eFPGA signal pins on the WEST edge (facing the CPU in chip_core integration):
    "IO_PIN_ORDER_CFG: dir::work/librelane/efpga_stitch/pin_order.cfg",
    "ERRORS_ON_UNMATCHED_IO: none",
    # gf180 KLayout DRC needs an explicit top cell (tile macros leave orphan top cells):
    "KLAYOUT_DRC_OPTIONS:","  feol: true","  beol: true","  dummy: true","  dummy_no_sub_prev: true",
    "  offgrid: true","  conn_drc: true","  wedge: true","  run_mode: deep","  topcell: eFPGA_top",'PDN_MACRO_CONNECTIONS:','  - ".*Tile_X.* VDD VSS VDD VSS"',"MACROS:"]
for t in TYPES:
    L+=[f"  {t}:", f'    gds: ["dir::{IP}/{t}/{t}.gds"]', f'    lef: ["dir::{IP}/{t}/{t}.lef"]',
        f'    nl:  ["dir::{IP}/{t}/{t}.nl.v"]', "    instances:"]
    for path,xx,yy in bytype[t]: L.append(f'      "{path}": {{location: [{xx}, {yy}], orientation: N}}')
open(OUT,"w").write("\n".join(L)+"\n")
print(f"placed {sum(len(v) for v in bytype.values())} tiles; DIE {DIE_W:.0f}x{DIE_H:.0f}")
print("NOTE: pins forced WEST via work/librelane/efpga_stitch/pin_order.cfg (create it first)")

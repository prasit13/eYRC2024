# chip_core kit — what's here and where it goes

Drop these onto the institute PC under `$PROJ = $HOME/fabulous_self`. Follow
**CHIP_CORE_RUNBOOK.md** start to finish; use **CHIP_CORE_DRC_DEBUG.md** only when a step fails.

## Contents

```
README_INSTALL.md            <- this file
CHIP_CORE_RUNBOOK.md         <- the correct linear step-by-step (do this)
CHIP_CORE_DRC_DEBUG.md       <- branch-by-branch troubleshooting (when a step fails)
configs/
  efpga_stitch/pin_order.cfg   -> work/librelane/efpga_stitch/pin_order.cfg   (NEW, required Step 1)
  chip_core_recon/config.yaml  -> work/librelane/chip_core_recon/config.yaml  (REFERENCE — see note)
  chip_core/pdn_cfg.tcl        -> work/librelane/chip_core/pdn_cfg.tcl        (drop-in, safe)
  config_changes.txt           -> patch list if you prefer editing your own configs
scripts/
  gen_stitch.py                -> work/gen_stitch.py   (now emits IO_PIN_ORDER_CFG)
```

## Install (from inside the unzipped kit folder)

```bash
cd $HOME/fabulous_self
KIT=/path/to/chip_core_kit          # where you unzipped this

# docs
cp "$KIT"/CHIP_CORE_RUNBOOK.md "$KIT"/CHIP_CORE_DRC_DEBUG.md .

# Step-1 stitch pin order (NEW file) + the updated generator
mkdir -p work/librelane/efpga_stitch
cp "$KIT"/configs/efpga_stitch/pin_order.cfg work/librelane/efpga_stitch/pin_order.cfg
cp "$KIT"/scripts/gen_stitch.py work/gen_stitch.py      # back up your old one first if unsure

# SRAM PDN fix (safe drop-in; only the SRAM Metal2 bridge differs)
cp "$KIT"/configs/chip_core/pdn_cfg.tcl work/librelane/chip_core/pdn_cfg.tcl
```

## The chip_core config — IMPORTANT

`configs/chip_core_recon/config.yaml` is a **reference template**. Its `VERILOG_FILES`,
`VERILOG_INCLUDE_DIRS`, and the macro **instance hierarchy** come from the reference repo and may
not match your institute-PC directory names exactly.

- If unsure, **don't overwrite** your working config. Instead open `configs/config_changes.txt`
  and apply just the listed changes to your existing `chip_core_recon/config.yaml`.
- If your paths match the template, you can copy it directly:
  `cp "$KIT"/configs/chip_core_recon/config.yaml work/librelane/chip_core_recon/config.yaml`

Verify the instance paths against your design before the run:
```bash
grep -E "efpga_i|u_sram" work/librelane/chip_core_recon/config.yaml
```

## Order of operations (summary — full detail in the runbook)

1. **Step 1**: create pin_order.cfg (done above) → re-run `gen_stitch.py` → re-stitch eFPGA
   (~4 h) → verify all pins WEST → adopt new `eFPGA_top.{gds,lef,nl.v}`.
2. **Step 2**: apply chip_core floorplan + PDN changes.
3. **Step 3**: 30-min `--to OpenROAD.GlobalRouting` gate — must show no overflow before continuing.
4. **Step 4**: full `--to KLayout.StreamOut`.
5. **Step 5–6**: signoff config → DRC + LVS.
6. **Step 7**: collect final GDS/LEF/nl.

Do NOT run the 5-hour route until the 30-minute GRT gate (Step 3) is clean.

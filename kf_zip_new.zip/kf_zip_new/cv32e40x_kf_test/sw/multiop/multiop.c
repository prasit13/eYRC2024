// =====================================================================================
// multiop -- exercises the runtime-reconfigurable eFPGA coprocessor from the CPU.
//
// The four custom opcodes each drive a DIFFERENT operation on the SAME eFPGA fabric.
// When the CPU offloads one whose bitstream isn't currently loaded, the coprocessor
// streams the matching bitstream out of system memory (over its OBI master) and
// reconfigures the fabric at run time before computing the result. Switching opcodes
// therefore forces a reconfiguration; repeating an opcode does not.
//
//   custom-0 (0x0B) -> NOT     rd = ~rs1
//   custom-1 (0x2B) -> BITREV  rd = bit-reverse(rs1)
//   custom-2 (0x5B) -> BSWAP   rd = byte-reverse(rs1)
//   custom-3 (0x7B) -> XOR     rd = rs1 ^ rs2
//
// No printf/newlib I/O: results go straight to the testbench's memory-mapped
// virtual printer / status / exit registers, keeping the image tiny.
// =====================================================================================
#include <stdint.h>

#define MM_PRINT  (*(volatile uint32_t *)0x00800000u)   // write a byte -> stdout
#define MM_STATUS (*(volatile uint32_t *)0x008000c0u)    // 123456789=pass, 1=fail
#define MM_EXIT   (*(volatile uint32_t *)0x008000c4u)    // write -> $finish(value)

// ---- the four custom instructions ----
static inline uint32_t op_not(uint32_t a) {
    uint32_t r; asm volatile(".insn r 0x0B, 0x0, 0x00, %0, %1, zero" : "=r"(r) : "r"(a)); return r;
}
static inline uint32_t op_bitrev(uint32_t a) {
    uint32_t r; asm volatile(".insn r 0x2B, 0x7, 0x02, %0, %1, zero" : "=r"(r) : "r"(a)); return r;
}
static inline uint32_t op_bswap(uint32_t a) {
    uint32_t r; asm volatile(".insn r 0x5B, 0x0, 0x00, %0, %1, zero" : "=r"(r) : "r"(a)); return r;
}
static inline uint32_t op_xor(uint32_t a, uint32_t b) {
    uint32_t r; asm volatile(".insn r 0x7B, 0x0, 0x00, %0, %1, %2" : "=r"(r) : "r"(a), "r"(b)); return r;
}

// ---- golden (software) reference models ----
static uint32_t g_not(uint32_t a)   { return ~a; }
static uint32_t g_bswap(uint32_t a) { return (a>>24)|((a>>8)&0xff00)|((a<<8)&0xff0000)|(a<<24); }
static uint32_t g_xor(uint32_t a,uint32_t b){ return a^b; }
static uint32_t g_bitrev(uint32_t a){ uint32_t r=0; for(int i=0;i<32;i++){ r=(r<<1)|(a&1); a>>=1;} return r; }

// ---- tiny memory-mapped console ----
static void putc_(char c){ MM_PRINT = (uint32_t)c; }
static void puts_(const char *s){ while(*s) putc_(*s++); }
static void puthex(uint32_t v){
    putc_('0'); putc_('x');
    for(int i=28;i>=0;i-=4){ uint32_t n=(v>>i)&0xf; putc_(n<10?'0'+n:'a'+n-10); }
}

static int fails = 0;
static void check(const char *name, uint32_t got, uint32_t exp){
    puts_("  "); puts_(name); puts_(" got="); puthex(got); puts_(" exp="); puthex(exp);
    if(got==exp){ puts_("  PASS\n"); } else { puts_("  FAIL\n"); fails++; }
}

int main(void){
    const uint32_t x = 0x12345678u;
    const uint32_t y = 0x0f0f0f0fu;

    puts_("eFPGA runtime-reconfig coprocessor test (x="); puthex(x); puts_(")\n");

    puts_("[custom-0 NOT]    (reconfig)\n");  check("NOT   ", op_not(x),    g_not(x));
    puts_("[custom-1 BITREV] (reconfig)\n");  check("BITREV", op_bitrev(x), g_bitrev(x));
    puts_("[custom-2 BSWAP]  (reconfig)\n");  check("BSWAP ", op_bswap(x),  g_bswap(x));
    puts_("[custom-3 XOR]    (reconfig)\n");  check("XOR   ", op_xor(x,y),  g_xor(x,y));

    // repeat custom-1 immediately: should NOT reconfigure (already loaded), still correct
    puts_("[custom-1 BITREV] (no reconfig, repeat)\n");
    check("BITREV", op_bitrev(0xa5a5a5a5u), g_bitrev(0xa5a5a5a5u));
    // switch back to custom-0: forces a reconfiguration again
    puts_("[custom-0 NOT]    (reconfig back)\n");
    check("NOT   ", op_not(0xdeadbeefu), g_not(0xdeadbeefu));

    if(fails==0){ puts_("ALL OPS PASSED\n"); MM_STATUS = 123456789u; }
    else        { puts_("SOME OPS FAILED\n"); MM_STATUS = 1u; }

    MM_EXIT = (fails==0)?0u:1u;
    for(;;);
    return 0;
}

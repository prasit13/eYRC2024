// =====================================================================================
// kf.c -- run the Kalman-filter coprocessor on the CV32E40X.
//
// Streams a noisy altitude trace (TRUTH + Gaussian noise, precomputed in trace.h as
// Q16.16 fixed-point) through the coprocessor, ONE custom instruction per sample:
//
//     denoised = kf_step(raw_sample);   // .insn r 0x0B,0x0,0x00,rd,rs1,zero
//
// and shows that the denoised stream is closer to the true altitude than the raw stream.
// Output goes to the testbench virtual printer / status / exit registers.
// =====================================================================================
#include <stdint.h>
#include "trace.h"     // #define N ; static const int NOISY[N], TRUTH[N]  (all Q16.16)

#define MM_PRINT  (*(volatile uint32_t *)0x00800000u)   // write a byte -> stdout
#define MM_STATUS (*(volatile uint32_t *)0x008000c0u)   // 123456789 = pass, 1 = fail
#define MM_EXIT   (*(volatile uint32_t *)0x008000c4u)   // write -> $finish(value)

// the one coprocessor instruction: raw altitude (Q16.16) in -> denoised (Q16.16) out
static inline int kf_step(int y){
  int r;
  asm volatile(".insn r 0x0B,0x0,0x00,%0,%1,zero" : "=r"(r) : "r"(y));
  return r;
}

static void putc_(char c){ MM_PRINT = (uint32_t)c; }
static void puts_(const char *s){ while(*s) putc_(*s++); }
static void putdec(int v){                 // signed decimal
  char b[12]; int i=0; unsigned u;
  if(v<0){ putc_('-'); u=(unsigned)(-v); } else u=(unsigned)v;
  if(u==0){ putc_('0'); return; }
  while(u){ b[i++]='0'+(u%10); u/=10; }
  while(i) putc_(b[--i]);
}
static int ipart(int q){ return q>>16; }   // Q16.16 -> integer metres
static int absq(int q){ return q<0 ? -q : q; }

int main(void){
  long long raw_err=0, kf_err=0;           // sum of |.-truth| in Q16.16
  int k, r, d;

  puts_("Kalman denoise on CV32E40X (one kf_step per sample)\n");
  puts_("  k  raw   kf  true\n");
  for(k=0; k<N; k++){
    r = NOISY[k];
    d = kf_step(r);                         // <-- the coprocessor
    raw_err += absq(r - TRUTH[k]);
    kf_err  += absq(d - TRUTH[k]);
    if(k<10 || (k%8)==0){
      puts_("  "); putdec(k);
      puts_("  ");  putdec(ipart(r));
      puts_("  ");  putdec(ipart(d));
      puts_("  ");  putdec(ipart(TRUTH[k]));
      putc_('\n');
    }
  }
  puts_("total |error| (m):  raw="); putdec((int)(raw_err>>16));
  puts_("  kf=");                    putdec((int)(kf_err >>16));
  putc_('\n');

  if(kf_err < raw_err){ puts_("PASS: coprocessor reduced altitude error\n"); MM_STATUS=123456789u; MM_EXIT=0u; }
  else                { puts_("FAIL\n");                                      MM_STATUS=1u;         MM_EXIT=1u; }
  for(;;);
  return 0;
}

# =====================================================================================
# Wave preset for the Kalman-filter coprocessor on the CV32E40X.
# Shows the XIF handshake (issue/commit/result) and the coprocessor's internal state
# (estimate x, covariance P, gain K) so you can watch the filter converge.
#
# Used by:  make kf-vsim-run-gui   (vsim -do tcl/kf_waves.tcl)
# =====================================================================================

onfinish stop      ;# at the program's $finish, STOP (don't quit) so waves stay visible

set cop /tb_top/cv32e40x_tb_wrapper_i/xif_copro_i/kf_copro_i

add wave -divider "clock / reset"
add wave $cop/clk_i $cop/rst_ni

add wave -divider "XIF handshake"
add wave $cop/issue_valid_i $cop/issue_ready_o $cop/issue_resp_accept_o
add wave -radix hexadecimal $cop/issue_req_instr_i
add wave -radix decimal     $cop/issue_req_rs_i      ;# low 32 bits = raw altitude (Q16.16)
add wave $cop/commit_valid_i $cop/result_valid_o $cop/result_ready_i
add wave -radix decimal     $cop/result_data_o       ;# denoised altitude (Q16.16)
add wave $cop/busy $cop/done $cop/first

add wave -divider "state estimate  x = h, v, a  (Q16.16 ints)"
add wave -radix decimal $cop/x0 $cop/x1 $cop/x2

add wave -divider "covariance P (diagonal) and gain K"
add wave -radix decimal $cop/p00 $cop/p11 $cop/p22
add wave -radix decimal $cop/k0 $cop/k1 $cop/k2

# ---- analog views (min/max in raw Q16.16 ints): altitude ~1000..1060 m, covariance 0..200 ----
add wave -divider "ANALOG: denoised altitude x0"
add wave -format analog-step -height 100 -min 65536000 -max 69468160 -radix decimal $cop/x0
add wave -divider "ANALOG: covariance p00"
add wave -format analog-step -height 70  -min 0 -max 13107200 -radix decimal $cop/p00

configure wave -namecolwidth 240
configure wave -valuecolwidth 110
configure wave -timelineunits us

run -all            ;# runs to the program's $finish, then stops (GUI stays open)
wave zoom full

// Compiled FIRST so every module that lacks its own `timescale inherits a single,
// consistent simulation timescale. The FABulous fabric .v files carry no timescale
// directive; without this, iverilog can apply inconsistent timescales across the
// controller / fabric / OBI model, skewing the clocking. Simulation-only.
`timescale 1ns/1ps

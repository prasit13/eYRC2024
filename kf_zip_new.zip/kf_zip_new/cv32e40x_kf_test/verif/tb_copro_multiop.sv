// =====================================================================================
// Coprocessor-level testbench for the runtime-reconfigurable eFPGA coprocessor.
//
// It instantiates the REAL xif_copro_efpga (reconfig controller + OBI read master +
// eFPGA fabric) plus a small OBI memory model holding the 4 bitstreams, and drives the
// XIF issue->commit->result handshake for each custom opcode exactly as the CV32E40X
// would.  This proves the whole coprocessor path end-to-end (opcode detect -> stream
// bitstream over OBI -> reconfigure fabric -> compute) without the (much slower) full
// CPU.  Switching opcodes forces a reconfiguration; repeating one does not.
//
//   iverilog -g2012 -o build/copro.vvp -s tb_copro_multiop \
//       rtl/efpga/fabric/*.v rtl/efpga/xif_copro_efpga.v verif/tb_copro_multiop.sv
//   vvp build/copro.vvp
// =====================================================================================
`timescale 1ns/1ps
module tb_copro_multiop;
  localparam [31:0] BITS_BASE   = 32'h0010_0000;
  localparam [31:0] BITS_STRIDE = 32'h0000_2000;

  reg clk = 0, rst_ni = 0;
  always #5 clk = ~clk;

  // ---- XIF flattened signals ----
  reg         issue_valid;
  reg  [31:0] issue_instr;
  reg  [3:0]  issue_id;
  reg  [63:0] issue_rs;
  reg  [1:0]  issue_rs_valid;
  reg         commit_valid;
  reg         commit_kill;
  reg  [3:0]  commit_id;
  reg         result_ready;

  wire        issue_ready, issue_accept, issue_writeback;
  wire        result_valid;
  wire [3:0]  result_id;
  wire [31:0] result_data;
  wire [4:0]  result_rd;
  wire        config_busy;

  // ---- OBI read master <-> memory model ----
  wire        cfgm_req;
  wire [31:0] cfgm_addr;
  wire        cfgm_gnt;
  reg         cfgm_rvalid;
  reg  [31:0] cfgm_rdata;

  xif_copro_efpga #(
    .BITS_BASE(BITS_BASE), .BITS_STRIDE(BITS_STRIDE), .NWORDS(1446)
  ) dut (
    .clk_i(clk), .rst_ni(rst_ni),
    .cfgm_req_o(cfgm_req), .cfgm_gnt_i(cfgm_gnt), .cfgm_addr_o(cfgm_addr),
    .cfgm_rvalid_i(cfgm_rvalid), .cfgm_rdata_i(cfgm_rdata), .config_busy_o(config_busy),
    .compressed_valid_i(1'b0),
    .issue_valid_i(issue_valid), .issue_req_instr_i(issue_instr),
    .issue_req_mode_i(2'b0), .issue_req_id_i(issue_id),
    .issue_req_rs_i(issue_rs), .issue_req_rs_valid_i(issue_rs_valid),
    .commit_valid_i(commit_valid), .commit_kill_i(commit_kill), .commit_id_i(commit_id),
    .mem_ready_i(1'b0), .mem_resp_exc_i(1'b0), .mem_resp_exccode_i(6'b0), .mem_resp_dbg_i(1'b0),
    .mem_result_valid_i(1'b0), .mem_result_rdata_i(32'b0), .mem_result_err_i(1'b0), .mem_result_dbg_i(1'b0),
    .result_ready_i(result_ready),
    .compressed_ready_o(), .compressed_resp_instr_o(), .compressed_resp_accept_o(),
    .issue_ready_o(issue_ready), .issue_resp_accept_o(issue_accept),
    .issue_resp_writeback_o(issue_writeback), .issue_resp_dualwrite_o(), .issue_resp_dualread_o(),
    .issue_resp_loadstore_o(), .issue_resp_ecswrite_o(), .issue_resp_exc_o(),
    .mem_valid_o(), .mem_req_id_o(), .mem_req_mode_o(), .mem_req_we_o(), .mem_req_size_o(),
    .mem_req_be_o(), .mem_req_attr_o(), .mem_req_wdata_o(), .mem_req_last_o(), .mem_req_spec_o(),
    .mem_req_addr_o(),
    .result_valid_o(result_valid), .result_id_o(result_id), .result_data_o(result_data),
    .result_rd_o(result_rd), .result_we_o(), .result_ecsdata_o(), .result_ecswe_o(),
    .result_exc_o(), .result_exccode_o(), .result_err_o(), .result_dbg_o()
  );

  // ---- OBI memory model: 4 bitstreams, 8 KiB apart, little-endian bytes ----
  reg [7:0] cmem [0:32'h7FFF];
  initial begin
    $readmemh("bitstreams/not.bytes.hex",    cmem, 0*BITS_STRIDE);
    $readmemh("bitstreams/bitrev.bytes.hex", cmem, 1*BITS_STRIDE);
    $readmemh("bitstreams/bswap.bytes.hex",  cmem, 2*BITS_STRIDE);
    $readmemh("bitstreams/xor.bytes.hex",    cmem, 3*BITS_STRIDE);
  end
  wire [31:0] caddr = cfgm_addr - BITS_BASE;
  assign cfgm_gnt = cfgm_req;                   // always ready (combinational accept)
  always @(posedge clk or negedge rst_ni) begin
    if (!rst_ni) begin cfgm_rvalid <= 1'b0; cfgm_rdata <= 32'b0; end
    else begin
      cfgm_rvalid <= cfgm_req;                  // read data valid one cycle after accept
      if (cfgm_req)
        cfgm_rdata <= {cmem[caddr+3], cmem[caddr+2], cmem[caddr+1], cmem[caddr]};
    end
  end

  // golden models
  function [31:0] g_not;   input [31:0] a; g_not = ~a; endfunction
  function [31:0] g_bswap; input [31:0] a; g_bswap = {a[7:0],a[15:8],a[23:16],a[31:24]}; endfunction
  function [31:0] g_brev;  input [31:0] a; integer i; begin for(i=0;i<32;i=i+1) g_brev[i]=a[31-i]; end endfunction

  integer errors = 0;
  reg [31:0] r;


  task automatic run_op(input [127:0] name, input [31:0] instr,
                        input [31:0] rs1, input [31:0] rs2, input [31:0] exp);
    integer t;
    begin
      issue_instr = instr; issue_rs = {rs2, rs1}; issue_rs_valid = 2'b11; issue_id = 4'd7;
      issue_valid = 1'b1;
      t = 0;
      while (!(issue_ready && issue_accept) && t < 40000) begin @(negedge clk); t = t + 1; end
      if (t >= 40000) begin $display("  [!] %0s: issue never accepted", name); errors=errors+1; end
      @(negedge clk); issue_valid = 1'b0;
      commit_valid = 1'b1; commit_kill = 1'b0; commit_id = 4'd7; @(negedge clk); commit_valid = 1'b0;
      result_ready = 1'b1;
      t = 0; while (!result_valid && t < 2000) begin @(negedge clk); t = t + 1; end
      r = result_data;
      @(negedge clk); result_ready = 1'b0; repeat (2) @(negedge clk);
      if (r === exp) $display("  PASS %0s got=%08h exp=%08h (cfg_cycles~%0d)", name, r, exp, t);
      else begin     $display("  FAIL %0s got=%08h exp=%08h", name, r, exp); errors=errors+1; end
    end
  endtask

  localparam [31:0] X = 32'h1234_5678, Y = 32'h0f0f_0f0f;
  initial begin
    issue_valid=0; issue_instr=0; issue_id=0; issue_rs=0; issue_rs_valid=0;
    commit_valid=0; commit_kill=0; commit_id=0; result_ready=0;
    rst_ni=0; repeat (6) @(negedge clk); rst_ni=1; repeat (4) @(negedge clk);

    run_op("custom0 NOT",    32'h0000000B, X, Y, g_not(X));
    run_op("custom1 BITREV", 32'h0400702B, X, Y, g_brev(X));
    run_op("custom2 BSWAP",  32'h0000005B, X, Y, g_bswap(X));
    run_op("custom3 XOR",    32'h0000007B, X, Y, X ^ Y);

    $display("\n==================================================");
    if (errors==0) $display("  COPRO MULTIOP TEST: ALL PASSED");
    else           $display("  COPRO MULTIOP TEST: %0d FAILURE(S)", errors);
    $display("==================================================\n");
    $finish;
  end

  initial begin #20_000_000; $display("TIMEOUT"); $finish; end
endmodule

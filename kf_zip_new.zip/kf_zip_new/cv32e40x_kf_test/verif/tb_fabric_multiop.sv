// =====================================================================================
// Fabric-level unit testbench: validates RUNTIME RECONFIGURATION of a single eFPGA.
//
// It instantiates one eFPGA_top and, for each of the 4 operations, re-streams that op's
// bitstream into the fabric's SelfWrite config port (holding the mapped coproc in reset
// during the load, exactly as the real reconfig controller will), then drives the XIF
// issue->commit->result handshake and checks the result. Proving all 4 ops work on ONE
// fabric instance, switched at run time, is the core premise of the whole design.
//
// Run:
//   iverilog -g2012 -o build/fab.vvp -s tb_fabric_multiop \
//       rtl/efpga/fabric/*.v verif/tb_fabric_multiop.sv
//   vvp build/fab.vvp
// =====================================================================================
`timescale 1ns/1ps
module tb_fabric_multiop;
  localparam int NCFG = 1446;

  reg clk = 0, resetn = 0;
  always #5 clk = ~clk;

  // ---- fabric config port ----
  reg         cfg_strobe;
  reg  [31:0] cfg_data;

  // ---- flattened XIF signals (driven by this tb) ----
  reg         coproc_rstn;
  reg         issue_valid;
  reg  [31:0] issue_instr;
  reg  [3:0]  issue_id;
  reg  [63:0] issue_rs;
  reg  [1:0]  issue_rs_valid;
  reg         commit_valid;
  reg         commit_kill;
  reg  [3:0]  commit_id;
  reg         result_ready;

  // ---- pack into UIN_top exactly as rtl/efpga/xif_copro_efpga.v does ----
  wire [175:0] UIN_top;
  wire [219:0] UOUT_top;
  assign UIN_top[175:158] = 18'b0;
  assign UIN_top[0]       = coproc_rstn;
  assign UIN_top[1]       = 1'b0;            // compressed_valid
  assign UIN_top[2]       = issue_valid;
  assign UIN_top[34:3]    = issue_instr;
  assign UIN_top[36:35]   = 2'b0;            // mode
  assign UIN_top[40:37]   = issue_id;
  assign UIN_top[104:41]  = issue_rs;
  assign UIN_top[106:105] = issue_rs_valid;
  assign UIN_top[107]     = commit_valid;
  assign UIN_top[108]     = commit_kill;
  assign UIN_top[112:109] = commit_id;
  assign UIN_top[113]     = 1'b0;            // mem_ready
  assign UIN_top[114]     = 1'b0;            // mem_resp_exc
  assign UIN_top[120:115] = 6'b0;
  assign UIN_top[121]     = 1'b0;
  assign UIN_top[122]     = 1'b0;            // mem_result_valid
  assign UIN_top[154:123] = 32'b0;
  assign UIN_top[155]     = 1'b0;
  assign UIN_top[156]     = 1'b0;
  assign UIN_top[157]     = result_ready;

  // ---- unpack UOUT_top ----
  wire        issue_ready       = UOUT_top[34];
  wire        issue_accept      = UOUT_top[35];
  wire        result_valid      = UOUT_top[127];
  wire [3:0]  result_id         = UOUT_top[131:128];
  wire [31:0] result_data       = UOUT_top[163:132];
  wire [4:0]  result_rd         = UOUT_top[168:164];

  wire [27:0] eF_I_top, eF_T_top;
  wire [55:0] eF_A_cfg, eF_B_cfg;
  wire        eF_ComActive, eF_ReceiveLED;

  eFPGA_top dut (
    .A_config_C(eF_A_cfg), .B_config_C(eF_B_cfg),
    .I_top(eF_I_top), .O_top(28'b0), .T_top(eF_T_top),
    .UIN_top(UIN_top), .UOUT_top(UOUT_top),
    .CLK(clk), .resetn(resetn),
    .SelfWriteStrobe(cfg_strobe), .SelfWriteData(cfg_data),
    .Rx(1'b1), .ComActive(eF_ComActive), .ReceiveLED(eF_ReceiveLED),
    .s_clk(1'b0), .s_data(1'b0)
  );

  reg [31:0] bits [0:NCFG-1];
  integer errors = 0;

  // stream one full bitstream into the fabric (coproc held in reset throughout).
  // Mirrors the real controller: pulse the fabric resetn, then stream.
  task automatic configure(input [8*64:1] hexfile);
    integer i;
    begin
      coproc_rstn = 1'b0;
      resetn = 1'b0; repeat (4) @(negedge clk);   // S_RESET: config-FSM reset pulse
      resetn = 1'b1; repeat (2) @(negedge clk);
      $readmemh(hexfile, bits);
      @(negedge clk);
      for (i = 0; i < NCFG; i = i + 1) begin
        cfg_data = bits[i]; @(negedge clk); @(negedge clk);   // present + settle
        cfg_strobe = 1'b1;  @(negedge clk);                    // 1-cycle strobe
        cfg_strobe = 1'b0;  @(negedge clk);
      end
      repeat (16) @(negedge clk);   // let config FFs settle
      coproc_rstn = 1'b1;           // release the mapped coproc
      repeat (4) @(negedge clk);
    end
  endtask

  // drive one offloaded instruction through issue->commit->result, return result_data
  task automatic run_op(input [31:0] instr, input [31:0] rs1, input [31:0] rs2,
                        output [31:0] got);
    integer timeout;
    begin
      // issue
      issue_instr    = instr;
      issue_rs       = {rs2, rs1};
      issue_rs_valid = 2'b11;
      issue_id       = 4'd5;
      issue_valid    = 1'b1;
      // wait for accept
      timeout = 0;
      while (!(issue_ready && issue_accept) && timeout < 100) begin
        @(negedge clk); timeout = timeout + 1;
      end
      if (timeout >= 100) $display("    [!] issue not accepted (instr=%08h)", instr);
      @(negedge clk);
      issue_valid = 1'b0;
      // commit (same id)
      commit_valid = 1'b1; commit_kill = 1'b0; commit_id = 4'd5;
      @(negedge clk);
      commit_valid = 1'b0;
      // wait for result
      result_ready = 1'b1;
      timeout = 0;
      while (!result_valid && timeout < 100) begin @(negedge clk); timeout = timeout + 1; end
      got = result_data;
      @(negedge clk);
      result_ready = 1'b0;
      repeat (2) @(negedge clk);
    end
  endtask

  // golden models
  function [31:0] g_not;   input [31:0] a; g_not = ~a; endfunction
  function [31:0] g_bswap; input [31:0] a; g_bswap = {a[7:0],a[15:8],a[23:16],a[31:24]}; endfunction
  function [31:0] g_brev;  input [31:0] a; integer i; begin for(i=0;i<32;i=i+1) g_brev[i]=a[31-i]; end endfunction

  task automatic check(input [8*8:1] name, input [31:0] got, input [31:0] exp);
    begin
      if (got === exp) $display("    PASS %0s : got=%08h exp=%08h", name, got, exp);
      else begin       $display("    FAIL %0s : got=%08h exp=%08h", name, got, exp); errors=errors+1; end
    end
  endtask

  reg [31:0] r;
  localparam [31:0] X = 32'h1234_5678;
  localparam [31:0] Y = 32'h0F0F_0F0F;

  initial begin
    cfg_strobe=0; cfg_data=0; coproc_rstn=0;
    issue_valid=0; issue_instr=0; issue_id=0; issue_rs=0; issue_rs_valid=0;
    commit_valid=0; commit_kill=0; commit_id=0; result_ready=0;
    resetn=0; repeat (5) @(negedge clk); resetn=1; repeat (5) @(negedge clk);

    $display("\n[config #1 NOT]  streaming bitstream...");
    configure("bitstreams/not.words.hex");
    run_op(32'h0000000B, X, Y, r); check("NOT   ", r, g_not(X));

    $display("\n[config #2 BITREV] re-streaming...");
    configure("bitstreams/bitrev.words.hex");
    run_op(32'h0400702B, X, Y, r); check("BITREV", r, g_brev(X));

    $display("\n[config #3 BSWAP] re-streaming...");
    configure("bitstreams/bswap.words.hex");
    run_op(32'h0000005B, X, Y, r); check("BSWAP ", r, g_bswap(X));

    $display("\n[config #4 XOR] re-streaming...");
    configure("bitstreams/xor.words.hex");
    run_op(32'h0000007B, X, Y, r); check("XOR   ", r, X ^ Y);

    $display("\n==================================================");
    if (errors==0) $display("  FABRIC RECONFIG TEST: ALL 4 OPS PASSED");
    else           $display("  FABRIC RECONFIG TEST: %0d FAILURE(S)", errors);
    $display("==================================================\n");
    $finish;
  end

  initial begin #5_000_000; $display("TIMEOUT"); $finish; end
endmodule

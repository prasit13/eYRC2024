# CV32E40X ↔ Kalman‑Filter Coprocessor — interfacing, in detail

This document explains exactly **how the CV32E40X core talks to the Kalman‑filter
coprocessor** (`kf_copro`) in `cv32e40x_kf_test/`: the interface used (CORE‑V **XIF**), the
module hierarchy and wiring, the signal‑by‑signal connections, the issue→commit→result
handshake with timing, how a single `kf_step` instruction flows from C down to a register
writeback, and what had to change to attach this (soft) coprocessor.

---

## 1. The big picture

```
 tb_top
  └─ cv32e40x_tb_wrapper_i
       ├─ cv32e40x_core_i      (the RISC-V CPU)
       │        ▲  │
       │        │  │  cv32e40x_if_xif  "ext_if"  (the eXtension Interface, shared instance)
       │        │  ▼
       ├─ xif_copro_i          (flattens ext_if, ties off eFPGA ports)
       │        └─ kf_copro_i  (the Kalman filter: decode + datapath + state x,P)
       └─ ram_i (mm_ram)       (instruction/data memory + virtual printer/exit regs)
```

The CPU and the coprocessor never share a bus or memory for the offload itself — they
communicate purely over the **XIF interface instance `ext_if`**. The CPU offers each
custom instruction to the coprocessor; the coprocessor computes and hands a result back,
which the CPU writes into the destination register. From software it looks like a normal
instruction that returns a value.

The full hierarchical path to the coprocessor is
`/tb_top/cv32e40x_tb_wrapper_i/xif_copro_i/kf_copro_i`.

---

## 2. What the XIF (CORE‑V eXtension Interface) is

`rtl/cv32e40x_if_xif.sv` defines a SystemVerilog **`interface`** that bundles six
independent channels, each a `valid`/`ready`‑style handshake carrying a packed `struct`.
One instance, `ext_if`, is created in the wrapper and connected to **both** the core (via
its `cpu_*` modports) and the coprocessor (via its `coproc_*` modports) — the modports just
flip the input/output directions for the two sides.

Interface parameters used here (set where `ext_if` is instantiated):

| parameter | value | meaning |
|---|---|---|
| `X_NUM_RS` | 2 | source register operands the core can forward (rs1, rs2) |
| `X_ID_WIDTH` | 4 | width of the transaction `id` |
| `X_RFR_WIDTH` | 32 | register read width (operand width) |
| `X_RFW_WIDTH` | 32 | register writeback width (result width) |
| `X_MEM_WIDTH` | 32 | memory access width (XIF mem channel) |

The six channels:

| channel | direction (who drives valid) | purpose | used by KF? |
|---|---|---|---|
| **compressed** | CPU→coproc | expand a 16‑bit compressed custom instr | **no** (we use a 32‑bit R‑type) |
| **issue** | CPU→coproc | offer the instruction + source operands; coproc says accept/writeback | **yes** |
| **commit** | CPU→coproc | confirm or kill the offloaded instruction | **yes** |
| **mem** | coproc→CPU | coproc requests a load/store through the CPU LSU | **no** (KF touches no memory) |
| **mem_result** | CPU→coproc | returns load data for a coproc mem request | **no** |
| **result** | coproc→CPU | return the writeback value for `rd` | **yes** |

So the Kalman coprocessor lives entirely on three channels: **issue, commit, result.** The
other three are present (the port list is complete) but tied to inactive/constant values.

### The structs that matter for the KF

From `cv32e40x_if_xif.sv`:

`x_issue_req_t` (CPU → coproc, what's being offered):
```
instr     [31:0]                 the 32-bit instruction
mode      [1:0]                  privilege level
id        [3:0]                  transaction id (ties the 3 phases together)
rs        [X_NUM_RS-1:0][31:0]   source operands  (rs[0]=rs1, rs[1]=rs2)
rs_valid  [X_NUM_RS-1:0]         which operands are valid this cycle
ecs, ecs_valid                   (unused here)
```

`x_issue_resp_t` (coproc → CPU, the coproc's answer):
```
accept     is this my instruction?  (1 = I'll handle it)
writeback  will I write a result to rd?
dualwrite, dualread, loadstore, ecswrite, exc   (all 0 for the KF)
```

`x_commit_t` (CPU → coproc):
```
id           which offloaded instruction
commit_kill  1 = squash it (e.g. mispredict/flush); 0 = really execute
```

`x_result_t` (coproc → CPU, the writeback):
```
id        which instruction this result is for
data      [31:0]   the value to write into the register
rd        [4:0]    destination register number
we        write enable
ecsdata, ecswe, exc, exccode, err, dbg   (all 0 for the KF)
```

---

## 3. The wiring (`cv32e40x_tb_wrapper.sv`)

The wrapper creates the single interface instance and hands the matching modports to the
core and the coprocessor:

```systemverilog
cv32e40x_if_xif #(.X_NUM_RS(2), .X_MEM_WIDTH(32),
                  .X_RFR_WIDTH(32), .X_RFW_WIDTH(32), .X_MISA('0)) ext_if();

cv32e40x_core ... cv32e40x_core_i (
    ...
    .xif_compressed_if (ext_if),   // core drives cpu_compressed
    .xif_issue_if      (ext_if),   //  ...        cpu_issue
    .xif_commit_if     (ext_if),   //  ...        cpu_commit
    .xif_mem_if        (ext_if),   //  ...        cpu_mem
    .xif_mem_result_if (ext_if),   //  ...        cpu_mem_result
    .xif_result_if     (ext_if)    //  ...        cpu_result
);

xif_copro #(...) xif_copro_i (
    .clk_i, .rst_ni,
    .cfgm_* , .config_busy_o,      // eFPGA reconfig master — UNUSED here (tied off)
    .xif_compressed_if (ext_if),   // coproc drives coproc_compressed
    .xif_issue_if      (ext_if),   //  ...         coproc_issue
    .xif_commit_if     (ext_if),   //  ...         coproc_commit
    .xif_mem_if        (ext_if),
    .xif_mem_result_if (ext_if),
    .xif_result_if     (ext_if)
);
```

Same `ext_if` on both sides ⇒ the core's outputs are the coprocessor's inputs and vice
versa, with the modports enforcing the directions. The wrapper itself is unchanged from the
eFPGA build — only what's *inside* `xif_copro` changed.

---

## 4. `xif_copro.sv` — flattening the interface to plain signals

The CV32E40X interface is struct‑based (`xif_issue_if.issue_req.instr`, `…rs[1:0]`,
`xif_result_if.result.data`, …). The actual filter, `kf_copro`, is written with a **flat
Verilog port list** (one wire per field). `xif_copro.sv` is the thin adapter that connects
the two and ties off the channels/ports the KF doesn't use.

Key mappings (interface field → flat port on `kf_copro`):

| XIF interface member | `kf_copro` port | notes |
|---|---|---|
| `xif_issue_if.issue_valid` | `issue_valid_i` | issue handshake valid |
| `xif_issue_if.issue_ready` | `issue_ready_o` | coproc ready/accepting |
| `xif_issue_if.issue_req.instr` | `issue_req_instr_i` | the 32‑bit instruction |
| `xif_issue_if.issue_req.id` | `issue_req_id_i` | transaction id |
| `xif_issue_if.issue_req.rs[1:0]` | `issue_req_rs_i[63:0]` | rs1 = bits[31:0], rs2 = bits[63:32] |
| `xif_issue_if.issue_req.rs_valid[1:0]` | `issue_req_rs_valid_i[1:0]` | operand validity |
| `xif_issue_if.issue_resp.accept` | `issue_resp_accept_o` | "this is mine" |
| `xif_issue_if.issue_resp.writeback` | `issue_resp_writeback_o` | "I'll write rd" |
| `xif_commit_if.commit_valid` | `commit_valid_i` | commit phase |
| `xif_commit_if.commit.id` | `commit_id_i` | which instruction |
| `xif_commit_if.commit.commit_kill` | `commit_kill_i` | squash if 1 |
| `xif_result_if.result_valid` | `result_valid_o` | result ready |
| `xif_result_if.result_ready` | `result_ready_i` | core can take it |
| `xif_result_if.result.id` | `result_id_o` | echo the id |
| `xif_result_if.result.data` | `result_data_o` | **denoised altitude** |
| `xif_result_if.result.rd` | `result_rd_o` | destination register |
| `xif_result_if.result.we` | `result_we_o` | = 1 (do write) |

`localparam X_NUM_RS = 2` selects `issue_req.rs[X_NUM_RS-1:0]` and
`issue_req.rs_valid[X_NUM_RS-1:0]` so only rs1/rs2 are forwarded. The compressed and memory
channels are wired through too, but `kf_copro` drives their outputs to constants (no
compressed accept, `mem_valid_o=0`, etc.).

Because this is a **soft** coprocessor (not the eFPGA), `xif_copro.sv` also ties off the
eFPGA reconfiguration ports it still exposes (so the wrapper/`mm_ram` need no change):
```systemverilog
assign cfgm_req_o    = 1'b0;
assign cfgm_addr_o   = 32'b0;
assign config_busy_o = 1'b0;
```

---

## 5. How `kf_copro` recognises and answers the instruction

**Decode** (combinational): the coprocessor watches every offered instruction; it owns the
single opcode `0x0B` (funct3=0) and uses the `funct7` field to pick the operation —
`funct7=0` is `kf_step` (filter a sample), `funct7=1` is `kf_cfg` (write a model
coefficient at run time). This keeps it to one opcode while still allowing the paper's
Q/R/P0 to be re-tuned live:
```verilog
wire        ours    = (issue_req_instr_i[6:0]==7'h0B) & (issue_req_instr_i[14:12]==3'b000);
wire [6:0]  f7      = issue_req_instr_i[31:25];
wire        is_step = ours & (f7==7'd0);   // kf_step : rs1=raw altitude -> rd=denoised
wire        is_cfg  = ours & (f7==7'd1);   // kf_cfg  : rs2=index, rs1=value -> write coeff
wire        is_op   = is_step | is_cfg;
```
(`kf_cfg` indices: 0=R 1=Q00 2=Q01 3=Q02 4=Q11 5=Q12 6=Q22 7=P0H 8=P0V 9=P0A 10=DT 11=DT2
15=REINIT. The coefficients are reset-initialised registers, defaulting to the paper's
tuned values.)

**Issue response** (combinational):
```verilog
assign issue_ready_o          = ~busy & (is_op ? issue_req_rs_valid_i[0] : 1'b1);
assign issue_resp_accept_o    = is_op;     // "yes, this is my instruction"
assign issue_resp_writeback_o = is_op;     // "I will write rd"
```
So it accepts only when it's the KF opcode *and* the operand `rs1` is valid (`rs_valid[0]`)
and it isn't already busy. For any other instruction it asserts `issue_ready=1, accept=0`
(reject immediately, so the core never stalls on the KF and instead handles that instruction
itself / traps).

**Operands and result:**
- raw altitude sample = `issue_req_rs_i[31:0]` (rs1).
- destination register = `issue_req_instr_i[11:7]` (the `rd` field of the instruction) →
  driven back as `result_rd_o`.
- denoised altitude = `data_q` → `result_data_o`, with `result_we_o = 1`.

---

## 6. The handshake, phase by phase (with timing)

A `kf_step` flows through **three XIF transactions**, all carrying the same `id`:

**Phase 1 — ISSUE** (CPU → coproc): the core puts the instruction on the issue channel:
`issue_valid=1`, `issue_req.instr`, `issue_req.id`, `issue_req.rs[0]=rs1`,
`issue_req.rs_valid[0]=1`. The coproc answers combinationally with `issue_ready`,
`issue_resp.accept`, `issue_resp.writeback`. The transaction **completes on the cycle where
`issue_valid & issue_ready`**. On that cycle `kf_copro` latches `y=rs1`, runs the whole KF
update (predict+update), updates its persistent `x`,`P`, sets `busy`, and remembers
`id_q`, `rd_q`.

**Phase 2 — COMMIT** (CPU → coproc): once the core is sure the instruction is really going
to retire (not flushed by a branch mispredict, etc.) it pulses `commit_valid=1` with
`commit.id` = that id and `commit.commit_kill`=0. `kf_copro` matches the id and sets `done`.
(If `commit_kill=1`, it drops the instruction with no writeback.) Commit may arrive in the
same cycle as issue or later — `kf_copro` handles both.

**Phase 3 — RESULT** (coproc → CPU): `kf_copro` drives `result_valid=1` with `result.id`,
`result.data` (denoised altitude), `result.rd`, `result.we=1`. The core raises
`result_ready` when it can accept it. **On `result_valid & result_ready` the core writes
`result.data` into register `rd`**, and `kf_copro` clears `busy`/`done`, ready for the next
sample.

Cycle sketch (one `kf_step`, commit a cycle after issue):

```
cycle           :  T        T+1      T+2
issue_valid     : 1        0        0       (core offers the instr at T)
issue_ready     : 1        .        .       (coproc accepts at T -> latch rs1, compute)
busy            : 0→1      1        1→0
commit_valid    : 0        1        0       (core commits at T+1)
done            : 0        0→1      1→0
result_valid    : 0        0        1       (coproc returns denoised at T+2)
result_ready    : 1        1        1
  => register rd  written with the denoised altitude at T+2
```

Because the destination register isn't written until the result returns, the CV32E40X
**scoreboards `rd`**: any later instruction that reads `rd` is automatically stalled until
the writeback — which is exactly why, from C, `x = kf_step(y);` just works like a normal
instruction. `kf_copro` holds **one instruction in flight** (`busy`), so the core's next
offload waits for the current result; for a 100 Hz altimeter that's irrelevant (thousands
of idle cycles per sample).

---

## 7. How the CPU decides to offload at all

CV32E40X decodes every instruction with its own decoder. The custom opcode `0x0B`
(`custom-0`) is **not** part of the base ISA, so the decoder flags it for the eXtension
interface and offers it on the **issue** channel. The coprocessor's `issue_resp.accept`
then decides the outcome:

- `accept = 1` → the core treats it as a coprocessor instruction and expects a result;
- `accept = 0` → the core raises an **illegal‑instruction** exception.

`kf_copro` asserts `accept` exactly for `(instr & 0xFE00707F) == 0x0000000B`, so our
`kf_step` is accepted and anything else is cleanly rejected.

---

## 8. The software side

The single instruction is emitted with GCC's `.insn` directive:

```c
static inline int kf_step(int y){
    int r;
    asm volatile(".insn r 0x0B,0x0,0x00,%0,%1,zero" : "=r"(r) : "r"(y));
    return r;     // denoised altitude (Q16.16)
}
```

- `0x0B,0x0,0x00` = opcode, funct3, funct7 → assembles to an instruction that masks to
  `0x0000000B` (verified: `…058b`).
- `%0` = `rd` (output, the denoised value), `%1` = `rs1` (input, the raw sample), `rs2 = zero`.
- The compiler allocates the registers; the XIF carries `rs1` to the coproc and the result
  back into `rd`. The pipeline stall on the result is automatic.

Driver loop (`sw/kf/kf.c`): one offload per altimeter sample:
```c
for (k = 0; k < N; k++)
    denoised = kf_step(NOISY[k]);   // raw Q16.16 in -> denoised Q16.16 out
```

Re-tuning a coefficient at run time uses the same opcode with `funct7=1` (two operands —
value in `rs1`, index in `rs2`):
```c
static inline int kf_cfg(int value, int index){
    int r;
    asm volatile(".insn r 0x0B,0x0,0x01,%0,%1,%2" : "=r"(r) : "r"(value), "r"(index));
    return r;
}
// e.g. raise measurement-noise R to 16.0 (Q16.16) for more smoothing, then re-seed:
kf_cfg(16<<16, 0);    // index 0 = R
kf_cfg(0, 15);        // index 15 = REINIT (next kf_step re-initialises the filter)
```

---

## 9. The rest of the harness (for completeness)

`mm_ram` (`ram_i`) is the testbench memory + virtual peripherals; it has nothing to do with
the XIF offload, but the C program uses three memory‑mapped registers in it for I/O:

| address | function |
|---|---|
| `0x00800000` | virtual printer — write a byte = print a character |
| `0x008000c0` | test status — write `123456789` = pass, `1` = fail |
| `0x008000c4` | exit — write a value = end simulation (`$finish`) |

`mm_ram` still has a coprocessor read port (`cfgm_*`) from the eFPGA build; here it sees
`cfgm_req = 0` (tied off in `xif_copro.sv`) and stays idle.

---

## 10. What changed to attach this coprocessor

Starting from the working eFPGA CPU project, only three things changed:

1. **`rtl/xif_copro.sv`** now instantiates `kf_copro` (instead of `xif_copro_efpga`) and
   ties off the eFPGA OBI/`config_busy` ports. Its *external* port list is unchanged, so
   `cv32e40x_tb_wrapper.sv` and `mm_ram.sv` need no edits.
2. **`cv32e40x_manifest.flist`** — removed the eFPGA fabric files, added `rtl/kf_copro.v`.
3. **Software** — added `sw/kf/kf.c` (+ `sw/kf/trace.h`) and `kf-vsim-run` /
   `kf-vsim-run-gui` targets in `sw/Makefile`.

This is the general recipe for attaching *any* XIF coprocessor: swap the module inside
`xif_copro.sv`, fix the manifest, add a program + a run target.

---

## 11. Build & run

```bash
cd cv32e40x_kf_test/sw
make kf-vsim-run        # console: streams the trace, prints raw-vs-kf error, PASS
make kf-vsim-run-gui    # ModelSim GUI with the KF wave preset (tcl/kf_waves.tcl):
                        #   XIF issue/commit/result + internal x,P,K + analog convergence
```

Observed result (CV32E40X executing `kf_step` once per sample):
```
total |error| (m):  raw=133  kf=97
PASS: coprocessor reduced altitude error
ALL TESTS PASSED      (Errors: 0)
```

---

## 12. One‑page connection reference

```
 CPU (cv32e40x_core_i)              ext_if (cv32e40x_if_xif)         kf_copro_i
 ----------------------             ------------------------         ----------
 offers custom instr  ── issue_valid/req ─────────────────────────▶ issue_valid_i / issue_req_*_i
 reads coproc answer  ◀── issue_ready/resp ────────────────────────  issue_ready_o / issue_resp_*_o
 confirms instr       ── commit_valid/commit ───────────────────────▶ commit_valid_i / commit_*_i
 writes rd register   ◀── result_valid/result ──────────────────────  result_valid_o / result_*_o
                          result_ready ─────────────────────────────▶ result_ready_i
 (compressed, mem, mem_result channels present but inactive for the KF)

 operand path : rs1  → issue_req.rs[0] → issue_req_rs_i[31:0]   → KF input  y
 result path  : x⁺[0] → result_data_o   → result.data → register rd (denoised altitude)
 id path      : same 4-bit id carried through issue → commit → result
```

That's the complete interface story: the CV32E40X offers each `kf_step` over the XIF issue
channel with `rs1` as the raw altitude, commits it, and the coprocessor — holding the
filter's `x`/`P` state internally — returns the denoised altitude on the result channel,
which the core writes back into the destination register.


radix define my_sfixed -fixed -signed -fraction N
add wave -radix my_sfixed /tb_path/your_signal_name

# CV32E40X + Kalman‑filter coprocessor (altimeter denoising)

A **single‑custom‑opcode linear Kalman filter** attached to the CV32E40X RISC‑V core over
the CORE‑V **eXtension Interface (XIF)**. The CPU streams raw altimeter samples to the
coprocessor one instruction at a time and gets back a denoised altitude:

```
denoised = kf_step(raw_altitude);     // .insn r 0x0B,0x0,0x00,rd,rs1,zero
```

The filter is an n=3 constant‑acceleration model (`x = [altitude, velocity, acceleration]`)
with a scalar altitude measurement, in Q16.16 fixed‑point. Its state (`x`, covariance `P`)
lives **inside** the coprocessor, so the CPU only ever sends one number and reads one number
back. This is a **soft** coprocessor (plain RTL); it uses the same flattened‑XIF shape as
the eFPGA coprocessors, so it can later be mapped onto the fabric.

---

## Documentation

| read this | for |
|---|---|
| [CV_KF_INTERFACING.md](CV_KF_INTERFACING.md) | **how the CPU talks to the coprocessor** — the XIF channels, the module hierarchy/wiring, signal‑by‑signal connections, the issue→commit→result handshake with timing, and how one `kf_step` flows from C to a register writeback |
| [../kf_copro_test/KF_COPRO_EXPLAINED.md](../kf_copro_test/KF_COPRO_EXPLAINED.md) | **how the Kalman algorithm became the RTL** — beginner‑friendly: the math, the model, Q16.16 fixed‑point, and a table mapping every algorithm symbol to its Verilog variable, line by line |
| [README_CV32E40X_CORE.md](README_CV32E40X_CORE.md) | the upstream OpenHW Group CV32E40X core IP description (unmodified) |

---

## Quick start

**Full system — CV32E40X executing `kf_step` (ModelSim):**
```bash
cd sw
make kf-vsim-run        # console: streams a noisy trace, prints raw-vs-kf error + PASS
make kf-vsim-run-gui    # GUI with the KF wave preset (XIF handshake + internal x,P,K +
                        # analog views of the altitude estimate and covariance converging)
```
Expected:
```
total |error| (m):  raw=133  kf=97
PASS: coprocessor reduced altitude error
ALL TESTS PASSED      (Errors: 0)
```

**Standalone filter only — no CPU, runs in seconds (iverilog):**
```bash
cd ../kf_copro_test
iverilog -g2012 -o build/kf.vvp -s tb_kf_copro kf_copro.v tb_kf_copro.sv && vvp build/kf.vvp
```
This checks both that the filter **denoises** and that the fixed‑point hardware **matches a
floating‑point golden Kalman filter** to < 1e‑3.

---

## Layout

```
cv32e40x_kf_test/
├─ README.md                     ← you are here (entry point)
├─ CV_KF_INTERFACING.md          ← CPU ↔ coprocessor interface doc
├─ README_CV32E40X_CORE.md       ← upstream CV32E40X core IP description
├─ rtl/
│  ├─ kf_copro.v                 ← the Kalman-filter coprocessor (decode + datapath + x,P state)
│  ├─ xif_copro.sv               ← adapter: flattens the XIF interface, instantiates kf_copro
│  ├─ cv32e40x_if_xif.sv         ← the XIF interface definition
│  └─ cv32e40x_*.sv              ← the CV32E40X core
├─ tb/
│  ├─ tb_top.sv, cv32e40x_tb_wrapper.sv   ← testbench (core + coproc + memory)
│  └─ mm_ram.sv, dp_ram.sv                ← memory + virtual printer/exit
├─ sw/
│  ├─ kf/kf.c, kf/trace.h        ← test program: streams a noisy trace through kf_step
│  ├─ tcl/kf_waves.tcl           ← ModelSim wave preset for kf-vsim-run-gui
│  └─ Makefile                   ← `kf-vsim-run` / `kf-vsim-run-gui` targets
└─ cv32e40x_manifest.flist       ← RTL file list (eFPGA fabric removed, kf_copro.v added)

../kf_copro_test/                ← standalone filter: kf_copro.v, tb_kf_copro.sv,
                                   KF_COPRO_EXPLAINED.md, bin2hex/trace tools
```

---

## The instruction set (still ONE opcode — `funct7` selects the operation)

```
kf_step  rd, rs1        .insn r 0x0B, 0x0, 0x00, rd, rs1, zero
                        rs1 = raw altitude (Q16.16)  →  rd = denoised altitude (Q16.16)

kf_cfg   rd, rs1, rs2   .insn r 0x0B, 0x0, 0x01, rd, rs1, rs2
                        rs2 = coefficient index, rs1 = value (Q16.16)  →  rd = value (ack)
                        index: 0=R 1=Q00 2=Q01 3=Q02 4=Q11 5=Q12 6=Q22
                               7=P0H 8=P0V 9=P0A 10=DT 11=DT2 15=REINIT
```

Both use opcode `0x0B`; the `funct7` field (0 = step, 1 = cfg) selects the operation, so it
remains a single custom opcode. The first `kf_step` after reset (or after a `REINIT`)
auto‑initialises the filter to `x = [rs1, 0, 0]`, `P = P0`.

## Default tuning = the MAPCON‑2023 FMCW radar‑altimeter paper

The reset defaults of `rtl/kf_copro.v` are the paper's tuned values:
`P0 = diag(200,200,200)`, `Q = diag(0.05, 0.55, 0.001)`, `R = 8`, `dt = 0.02` (50 Hz).
The standalone test reproduces the paper's denoising (~30% RMS reduction, matching its
flight‑sortie figure). Re‑tune any coefficient **at run time** with `kf_cfg` (no rebuild),
or change the elaboration defaults (`DEF_*` parameters):

| want | change |
|---|---|
| more smoothing (quieter, slower) | smaller `Q00/Q11/Q22`, or larger `R` (`kf_cfg` idx 1/4/6 or 0) |
| faster reaction (less smoothing) | larger `Q`, or smaller `R` |
| match your sensor | `R = (noise σ)²` (`kf_cfg` idx 0) |
| match your sample rate | `DT = dt`, `DT2 = dt²/2` (`kf_cfg` idx 10/11) |
| initial trust in the first reading | `P0H/P0V/P0A` (`kf_cfg` idx 7/8/9), then `REINIT` (idx 15) |

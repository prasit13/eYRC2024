// =====================================================================================
// kf_copro -- single-opcode linear Kalman-filter coprocessor (altimeter denoising).
//
// Implements the linear Kalman filter from "Kalman Filter for Precise Altitude Estimation
// in FMCW Radar" (Jha et al., IEEE MAPCON 2023, DOI 10.1109/MAPCON58678.2023.10463967):
//   state x = [Altitude, Velocity, Acceleration] (n=3), scalar altitude measurement,
//   kinematic A = [[1,dt,dt^2/2],[0,1,dt],[0,0,1]], H = [1 0 0].
// The paper's tuned constants are the reset defaults (Q16.16):
//   P0 = diag(200,200,200) ,  Q = diag(0.05, 0.55, 0.001) ,  R = 8 ,  dt = 0.02 (50 Hz).
//
// ONE custom opcode (0x0B); the funct7 field selects the operation, so it stays a single
// opcode while still allowing run-time re-tuning (the paper tunes Q/R with a GA per sortie):
//
//   funct7=0  kf_step  rd, rs1        .insn r 0x0B,0x0,0x00,rd,rs1,zero
//             rs1 = raw altitude (Q16.16)  ->  rd = denoised altitude (Q16.16)
//
//   funct7=1  kf_cfg   rd, rs1, rs2   .insn r 0x0B,0x0,0x01,rd,rs1,rs2
//             rs2 = coefficient index, rs1 = value (Q16.16)  ->  rd = value (ack)
//             index: 0=R 1=Q00 2=Q01 3=Q02 4=Q11 5=Q12 6=Q22 7=P0H 8=P0V 9=P0A
//                    10=DT 11=DT2 15=REINIT(re-seed filter from current P0 on next sample)
//
// Filter state (x, P) is PERSISTENT across calls; the first kf_step after reset (or after a
// REINIT) auto-initialises x=[y,0,0], P=P0. Q16.16 signed fixed-point. Flattened-XIF port
// list matches xif_copro_verilog (drop-in / eFPGA-mappable).
// =====================================================================================
module kf_copro #(
  parameter XLEN = 32, parameter INPUT_BUFFER_DEPTH = 1, parameter FORWARDING = 1,
  // ---- reset-default model constants (Q16.16) = the MAPCON-2023 paper's tuned values ----
  parameter signed [31:0] DEF_DT  = 32'sd1311,     // dt   = 0.02   (50 Hz)
  parameter signed [31:0] DEF_DT2 = 32'sd13,       // dt^2/2 = 0.0002
  parameter signed [31:0] DEF_R   = 32'sd524288,   // R    = 8.0
  parameter signed [31:0] DEF_Q00 = 32'sd3277,     // Q diag 0.05
  parameter signed [31:0] DEF_Q01 = 32'sd0,
  parameter signed [31:0] DEF_Q02 = 32'sd0,
  parameter signed [31:0] DEF_Q11 = 32'sd36045,    // Q diag 0.55
  parameter signed [31:0] DEF_Q12 = 32'sd0,
  parameter signed [31:0] DEF_Q22 = 32'sd66,       // Q diag 0.001
  parameter signed [31:0] DEF_P0H = 32'sd13107200, // P0 diag 200.0
  parameter signed [31:0] DEF_P0V = 32'sd13107200,
  parameter signed [31:0] DEF_P0A = 32'sd13107200
) (
  input  wire        clk_i,
  input  wire        rst_ni,
  input  wire        compressed_valid_i,
  output wire        compressed_ready_o,
  output wire [31:0] compressed_resp_instr_o,
  output wire        compressed_resp_accept_o,
  input  wire        issue_valid_i,
  output wire        issue_ready_o,
  input  wire [31:0] issue_req_instr_i,
  input  wire [1:0]  issue_req_mode_i,
  input  wire [3:0]  issue_req_id_i,
  input  wire [63:0] issue_req_rs_i,
  input  wire [1:0]  issue_req_rs_valid_i,
  output wire        issue_resp_accept_o,
  output wire        issue_resp_writeback_o,
  output wire        issue_resp_dualwrite_o,
  output wire [2:0]  issue_resp_dualread_o,
  output wire        issue_resp_loadstore_o,
  output wire        issue_resp_ecswrite_o,
  output wire        issue_resp_exc_o,
  input  wire        commit_valid_i,
  input  wire        commit_kill_i,
  input  wire [3:0]  commit_id_i,
  output wire        mem_valid_o,
  input  wire        mem_ready_i,
  output wire [3:0]  mem_req_id_o,
  output wire [1:0]  mem_req_mode_o,
  output wire        mem_req_we_o,
  output wire [2:0]  mem_req_size_o,
  output wire [3:0]  mem_req_be_o,
  output wire [1:0]  mem_req_attr_o,
  output wire [31:0] mem_req_wdata_o,
  output wire        mem_req_last_o,
  output wire        mem_req_spec_o,
  output wire [31:0] mem_req_addr_o,
  input  wire        mem_resp_exc_i,
  input  wire [5:0]  mem_resp_exccode_i,
  input  wire        mem_resp_dbg_i,
  input  wire        mem_result_valid_i,
  input  wire [31:0] mem_result_rdata_i,
  input  wire        mem_result_err_i,
  input  wire        mem_result_dbg_i,
  output wire        result_valid_o,
  input  wire        result_ready_i,
  output wire [3:0]  result_id_o,
  output wire [31:0] result_data_o,
  output wire [4:0]  result_rd_o,
  output wire        result_we_o,
  output wire [5:0]  result_ecsdata_o,
  output wire [2:0]  result_ecswe_o,
  output wire        result_exc_o,
  output wire [5:0]  result_exccode_o,
  output wire        result_err_o,
  output wire        result_dbg_o
);

  // ---- Q16.16 helpers ----
  function automatic signed [31:0] fmul(input signed [31:0] a, input signed [31:0] b);
    reg signed [63:0] aa, bb, p; begin aa=a; bb=b; p=aa*bb; fmul=p>>>16; end
  endfunction
  function automatic signed [31:0] fdiv(input signed [31:0] num, input signed [31:0] den);
    reg signed [63:0] n, d; begin n=num; n=n<<<16; d=den; fdiv=n/d; end
  endfunction

  // ---- run-time model coefficients (registers; reset to the paper defaults) ----
  reg signed [31:0] DT, DT2, R, Q00, Q01, Q02, Q11, Q12, Q22, P0H, P0V, P0A;

  // ---- persistent filter state ----
  reg signed [31:0] x0, x1, x2;
  reg signed [31:0] p00, p01, p02, p11, p12, p22;
  reg        first;

  // ---- one outstanding instruction ----
  reg        busy, done;
  reg signed [31:0] data_q;
  reg [3:0]  id_q;
  reg [4:0]  rd_q;

  // ---- opcode/funct decode (single opcode 0x0B, funct3=0; funct7 selects op) ----
  wire        ours    = (issue_req_instr_i[6:0]==7'h0B) & (issue_req_instr_i[14:12]==3'b000);
  wire [6:0]  f7      = issue_req_instr_i[31:25];
  wire        is_step = ours & (f7==7'd0);
  wire        is_cfg  = ours & (f7==7'd1);
  wire        is_op   = is_step | is_cfg;

  // ---- combinational update temporaries ----
  reg signed [31:0] y, cfg_val; reg [3:0] cfg_idx;
  reg signed [31:0] nx0, nx1, nx2;
  reg signed [31:0] ap00, ap01, ap02, ap11, ap12, ap22;
  reg signed [31:0] pm00, pm01, pm02, pm11, pm12, pm22;
  reg signed [31:0] e_in, s_in, k0, k1, k2;
  reg signed [31:0] ux0, ux1, ux2;
  reg signed [31:0] np00, np01, np02, np11, np12, np22;

  // ---- issue response ----
  //  kf_step needs rs1 valid; kf_cfg needs rs1(value)+rs2(index) valid; else reject.
  assign issue_ready_o          = ~busy & (is_op ? (is_cfg ? (&issue_req_rs_valid_i[1:0])
                                                           : issue_req_rs_valid_i[0]) : 1'b1);
  assign issue_resp_accept_o    = is_op;
  assign issue_resp_writeback_o = is_op;
  assign issue_resp_dualwrite_o = 1'b0;
  assign issue_resp_dualread_o  = 3'b0;
  assign issue_resp_loadstore_o = 1'b0;
  assign issue_resp_ecswrite_o  = 1'b0;
  assign issue_resp_exc_o       = 1'b0;

  // ---- dead outputs ----
  assign compressed_ready_o       = compressed_valid_i;
  assign compressed_resp_instr_o  = 32'b0;
  assign compressed_resp_accept_o = 1'b0;
  assign mem_valid_o=1'b0; assign mem_req_id_o=4'b0; assign mem_req_mode_o=2'b0;
  assign mem_req_we_o=1'b0; assign mem_req_size_o=3'b0; assign mem_req_be_o=4'b0;
  assign mem_req_attr_o=2'b0; assign mem_req_wdata_o=32'b0; assign mem_req_last_o=1'b0;
  assign mem_req_spec_o=1'b0; assign mem_req_addr_o=32'b0;

  assign result_valid_o   = done;
  assign result_id_o      = id_q;
  assign result_data_o    = data_q;
  assign result_rd_o      = rd_q;
  assign result_we_o      = 1'b1;
  assign result_ecsdata_o = 6'b0; assign result_ecswe_o = 3'b0;
  assign result_exc_o     = 1'b0; assign result_exccode_o = 6'b0;
  assign result_err_o     = 1'b0; assign result_dbg_o = 1'b0;

  wire accept_hs  = issue_valid_i & issue_ready_o & is_op;
  wire commit_hit = commit_valid_i & (commit_id_i == id_q);

  always @(posedge clk_i) begin
    if (~rst_ni) begin
      busy<=1'b0; done<=1'b0; first<=1'b1;
      x0<=0; x1<=0; x2<=0; p00<=0; p01<=0; p02<=0; p11<=0; p12<=0; p22<=0;
      data_q<=0; id_q<=0; rd_q<=0;
      DT<=DEF_DT; DT2<=DEF_DT2; R<=DEF_R;
      Q00<=DEF_Q00; Q01<=DEF_Q01; Q02<=DEF_Q02; Q11<=DEF_Q11; Q12<=DEF_Q12; Q22<=DEF_Q22;
      P0H<=DEF_P0H; P0V<=DEF_P0V; P0A<=DEF_P0A;
    end else begin
      if (done & result_ready_i) begin done<=1'b0; busy<=1'b0; end

      if (accept_hs & ~busy) begin
        busy <= 1'b1;
        id_q <= issue_req_id_i;
        rd_q <= issue_req_instr_i[11:7];
        y       = issue_req_rs_i[31:0];
        cfg_val = issue_req_rs_i[31:0];
        cfg_idx = issue_req_rs_i[35:32];   // rs2 low nibble

        if (is_cfg) begin
          // ---- run-time coefficient write (or REINIT) ----
          case (cfg_idx)
            4'd0:  R   <= cfg_val;
            4'd1:  Q00 <= cfg_val;
            4'd2:  Q01 <= cfg_val;
            4'd3:  Q02 <= cfg_val;
            4'd4:  Q11 <= cfg_val;
            4'd5:  Q12 <= cfg_val;
            4'd6:  Q22 <= cfg_val;
            4'd7:  P0H <= cfg_val;
            4'd8:  P0V <= cfg_val;
            4'd9:  P0A <= cfg_val;
            4'd10: DT  <= cfg_val;
            4'd11: DT2 <= cfg_val;
            4'd15: first <= 1'b1;          // re-seed filter on next kf_step
            default: ;
          endcase
          data_q <= cfg_val;               // ack
        end else if (first) begin
          // ---- auto-initialise ----
          x0<=y; x1<=0; x2<=0;
          p00<=P0H; p01<=0; p02<=0; p11<=P0V; p12<=0; p22<=P0A;
          first<=1'b0;
          data_q<=y;
        end else begin
          // ---- PREDICT ----
          nx0 = x0 + fmul(DT,x1) + fmul(DT2,x2);
          nx1 = x1 + fmul(DT,x2);
          nx2 = x2;
          ap00 = p00 + fmul(DT,p01) + fmul(DT2,p02);
          ap01 = p01 + fmul(DT,p11) + fmul(DT2,p12);
          ap02 = p02 + fmul(DT,p12) + fmul(DT2,p22);
          ap11 = p11 + fmul(DT,p12);
          ap12 = p12 + fmul(DT,p22);
          ap22 = p22;
          pm00 = ap00 + fmul(DT,ap01) + fmul(DT2,ap02) + Q00;
          pm01 = ap01 + fmul(DT,ap02)                  + Q01;
          pm02 = ap02                                  + Q02;
          pm11 = ap11 + fmul(DT,ap12)                  + Q11;
          pm12 = ap12                                  + Q12;
          pm22 = ap22                                  + Q22;
          // ---- UPDATE (scalar measurement) ----
          e_in = y - nx0;
          s_in = pm00 + R;
          k0   = fdiv(pm00, s_in);
          k1   = fdiv(pm01, s_in);
          k2   = fdiv(pm02, s_in);
          ux0  = nx0 + fmul(k0, e_in);
          ux1  = nx1 + fmul(k1, e_in);
          ux2  = nx2 + fmul(k2, e_in);
          np00 = pm00 - fmul(k0, pm00);
          np01 = pm01 - fmul(k0, pm01);
          np02 = pm02 - fmul(k0, pm02);
          np11 = pm11 - fmul(k1, pm01);
          np12 = pm12 - fmul(k1, pm02);
          np22 = pm22 - fmul(k2, pm02);
          x0<=ux0; x1<=ux1; x2<=ux2;
          p00<=np00; p01<=np01; p02<=np02; p11<=np11; p12<=np12; p22<=np22;
          data_q <= ux0;
        end

        if (commit_valid_i & (commit_id_i == issue_req_id_i)) begin
          if (commit_kill_i) busy <= 1'b0; else done <= 1'b1;
        end
      end else if (busy & ~done & commit_hit) begin
        if (commit_kill_i) busy <= 1'b0; else done <= 1'b1;
      end
    end
  end
endmodule

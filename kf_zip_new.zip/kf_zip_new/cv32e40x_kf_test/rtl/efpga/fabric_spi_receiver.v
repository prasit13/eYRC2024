// SPI -> 32-bit fabric config-word receiver (greyhound-style external bitstream feed).
// SPI mode 0, MSB-first. Oversampled in the fabric clock domain (clk_i must be
// faster than sclk_i), so it is a single-clock, synthesizable design with no CDC
// hazards. Each completed 32-bit word is presented on data_o with a one-cycle
// strobe_o pulse, matching the eFPGA SelfWrite{Data,Strobe} handshake the on-chip
// ROM loader already drives.
module fabric_spi_receiver (
  input  wire        clk_i,
  input  wire        rst_ni,
  input  wire        sclk_i,    // SPI clock   (fpga_sclk)
  input  wire        cs_n_i,    // SPI select  (fpga_cs_n, active low)
  input  wire        mosi_i,    // SPI data in (fpga_mosi)
  output reg         strobe_o,  // -> eFPGA_top.SelfWriteStrobe (1-cycle pulse)
  output reg  [31:0] data_o,    // -> eFPGA_top.SelfWriteData
  output reg         busy_o     // high while a transfer is in progress
);
  // 3-deep synchronizers for the asynchronous SPI inputs
  reg [2:0] sclk_s, cs_s, mosi_s;
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      sclk_s <= 3'b000; cs_s <= 3'b111; mosi_s <= 3'b000;
    end else begin
      sclk_s <= {sclk_s[1:0], sclk_i};
      cs_s   <= {cs_s[1:0],   cs_n_i};
      mosi_s <= {mosi_s[1:0], mosi_i};
    end
  end
  wire sclk_rise = (sclk_s[2:1] == 2'b01);
  wire cs_active = ~cs_s[2];

  reg [31:0] shreg;
  reg [5:0]  bitcnt;
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      shreg <= 32'b0; bitcnt <= 6'd0; strobe_o <= 1'b0; data_o <= 32'b0; busy_o <= 1'b0;
    end else begin
      strobe_o <= 1'b0;          // default: strobe low
      busy_o   <= cs_active;
      if (!cs_active) begin
        bitcnt <= 6'd0;          // idle / between words
      end else if (sclk_rise) begin
        shreg <= {shreg[30:0], mosi_s[2]};
        if (bitcnt == 6'd31) begin
          bitcnt   <= 6'd0;
          data_o   <= {shreg[30:0], mosi_s[2]};  // completed word
          strobe_o <= 1'b1;                       // one-cycle config strobe
        end else begin
          bitcnt <= bitcnt + 6'd1;
        end
      end
    end
  end
endmodule

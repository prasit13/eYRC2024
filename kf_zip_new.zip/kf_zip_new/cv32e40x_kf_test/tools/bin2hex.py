#!/usr/bin/env python3
"""Convert a FABulous .bin bitstream into the two hex formats this project needs.

A FABulous bitstream is a sequence of 32-bit config words. genBitstream/the ROM
generator define  word_k = (b[4k]<<24)|(b[4k+1]<<16)|(b[4k+2]<<8)|b[4k+3]
i.e. the first byte of each 4-byte group is the MSB ("big-endian" word packing).
That is exactly the value the fabric expects on SelfWriteData.

Outputs (given <stem>):
  <stem>.words.hex : one 8-hex-digit word per line == word_k.
                     For $readmemh into a reg [31:0] array (direct SelfWrite streaming).
  <stem>.bytes.hex : one byte per line, ordered so that a little-endian 32-bit read
                     from a byte memory ({mem[a+3],mem[a+2],mem[a+1],mem[a]})
                     reconstructs word_k. Used to preload the bitstream into the SoC
                     byte-addressable RAM, where the coprocessor's OBI master reads it.
"""
import sys

def main():
    if len(sys.argv) != 3:
        print("usage: bin2hex.py <in.bin> <out_stem>")
        sys.exit(1)
    data = open(sys.argv[1], "rb").read()
    if len(data) % 4:
        data += b"\x00" * (4 - len(data) % 4)
    nwords = len(data) // 4
    stem = sys.argv[2]

    with open(stem + ".words.hex", "w") as fw, open(stem + ".bytes.hex", "w") as fb:
        for k in range(nwords):
            b0, b1, b2, b3 = data[4*k], data[4*k+1], data[4*k+2], data[4*k+3]
            word = (b0 << 24) | (b1 << 16) | (b2 << 8) | b3
            fw.write(f"{word:08x}\n")
            # little-endian byte order so dp_ram read == word_k
            fb.write(f"{b3:02x}\n{b2:02x}\n{b1:02x}\n{b0:02x}\n")
    print(f"{sys.argv[1]}: {nwords} words -> {stem}.words.hex (+ .bytes.hex)")

if __name__ == "__main__":
    main()

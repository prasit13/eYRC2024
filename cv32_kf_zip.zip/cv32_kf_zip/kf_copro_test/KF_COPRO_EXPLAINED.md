# The Kalman‑Filter Coprocessor, explained from scratch

This document explains, for someone new to both Kalman filters and RTL, **how the
altimeter‑denoising Kalman filter algorithm is turned into the Verilog in
[`kf_copro.v`](kf_copro.v)** — what every variable means, what numbers are used, and how
each line of code maps back to the math.

---

## 1. The problem

An altimeter reports altitude, but every reading has noise — it jitters around the true
height. We want a **smooth, accurate altitude** out of a **noisy stream of samples**, in
real time, sample by sample. A **Kalman filter (KF)** is the standard optimal way to do
this: it blends a *model of how the vehicle moves* with the *noisy measurements*.

---

## 2. A Kalman filter in plain English

The filter always carries two things:

- an **estimate** of the state (what we think is true right now), and
- an **uncertainty** about that estimate (how much we trust it).

Every time a new measurement arrives it does two phases:

1. **Predict** — use a motion model to guess where the state went, and *increase* the
   uncertainty (time passed, so we're less sure).
2. **Update** — compare the prediction with the new measurement and take a **weighted
   average** of the two. The weight is the **Kalman gain `K`**: if the measurement is
   noisy (`R` large) we lean on the prediction; if the prediction is uncertain (`P`
   large) we lean on the measurement. Then *decrease* the uncertainty (we just learned
   something).

Repeat forever, once per sample. That weighted averaging is what removes the noise.

---

## 3. Our model: "constant acceleration", measuring only altitude

We describe the vehicle with a **state vector of 3 numbers**:

```
x = [ h ]   altitude
    [ v ]   vertical velocity
    [ a ]   vertical acceleration
```

Why three? Because a good motion model for a smoothly moving object is "altitude changes
by velocity, velocity changes by acceleration." That lets the filter *anticipate* motion
instead of just averaging, which denoises far better than a plain moving average.

**How the state evolves over one time step `dt`** (basic kinematics):

```
h_next = h + v·dt + a·(dt²/2)
v_next =     v     + a·dt
a_next =                 a
```

Written as a matrix `x⁻ = A·x`, that is the **state‑transition matrix**:

```
      [ 1   dt   dt²/2 ]
A  =  [ 0    1    dt   ]
      [ 0    0     1   ]
```

We only **measure** altitude, not velocity or acceleration. The **measurement matrix** is
therefore:

```
C = [ 1  0  0 ]      (measurement y = C·x = h)
```

Two noise descriptions complete the model:

- **`R`** — measurement‑noise *variance*. Because we measure a single number (altitude),
  **`R` is just one scalar** (e.g. if the altimeter noise has standard deviation 3 m,
  then `R = 3² = 9`).
- **`Q`** — process‑noise covariance (3×3). It says "how wrong might my motion model be?"
  Bigger `Q` ⇒ trust the model less ⇒ track faster but smooth less.

And the running uncertainty is the **covariance matrix `P`** (3×3, symmetric).

---

## 4. The five equations (and the key simplification)

Per sample `y` (one raw altitude reading):

```
Predict:   x⁻ = A x                     (predicted state)
           P⁻ = A P Aᵀ + Q              (predicted covariance)

Update:    e  = y − C x⁻ = y − h⁻       (innovation: measurement minus prediction)
           S  = C P⁻ Cᵀ + R = P⁻[0][0] + R     (innovation covariance)
           K  = P⁻ Cᵀ / S = P⁻[:,0] / S        (Kalman gain, a 3‑vector)
           x⁺ = x⁻ + K e                (corrected state)
           P⁺ = (I − K C) P⁻            (corrected covariance)
```

**The simplification that makes this cheap in hardware:** in the general Kalman filter the
gain needs a *matrix inverse* `[C P⁻ Cᵀ + R]⁻¹`. But because we measure only one quantity,
`C P⁻ Cᵀ + R` is a **1×1 matrix — a single number `S`**. So the "inverse" is just **one
division** (`1/S`). No systolic array, no Gauss‑Jordan — just a divider. That's the whole
reason this fits a small coprocessor.

The denoised altitude we hand back each sample is `x⁺[0]` (the corrected `h`).

---

## 5. Numbers in hardware: Q16.16 fixed‑point

Hardware (especially a small fabric) has no floating‑point. We represent every real number
as a **32‑bit integer scaled by 2¹⁶ = 65536** — this is **Q16.16** (16 integer bits, 16
fractional bits):

```
stored_integer = round(real_value × 65536)
real_value     = stored_integer / 65536
```

Examples used in the code:

| real | Q16.16 integer | where |
|---|---|---|
| 1.0  | 65536    | `DT` (dt = 1 sample) |
| 0.5  | 32768    | `DT2` (dt²/2) |
| 9.0  | 589824   | `R` |
| 100.0| 6553600  | `P0H/P0V/P0A` (initial uncertainty) |
| 0.01 | 655      | `Q22` (process noise on acceleration) |

Range ≈ ±32768 with resolution ≈ 1/65536 ≈ 0.0000153 — plenty for altitudes of tens to
hundreds of metres.

**Arithmetic must keep the scale correct:**

- **Multiply** — multiplying two Q16.16 numbers gives a result scaled by 2³², so we shift
  right by 16 to get back to Q16.16. That is the helper `fmul`:
  ```verilog
  function fmul(a, b);  // (a × b) >> 16, done in 64 bits so nothing overflows
      aa = a; bb = b; p = aa * bb; fmul = p >>> 16;
  ```
- **Divide** — to compute `num/den` and *keep* 16 fractional bits we first shift the
  numerator left by 16. That is `fdiv`:
  ```verilog
  function fdiv(num, den);  // (num << 16) / den, in 64 bits
      n = num; n = n <<< 16; d = den; fdiv = n / d;
  ```

(64‑bit intermediates `aa,bb,p,n,d` are used so the temporary products/shifts don't
overflow before being rescaled back to 32 bits.)

---

## 6. Variable map: algorithm symbol → RTL signal

**State held *persistently* between calls** (this is the filter's memory):

| math | RTL signal | meaning |
|---|---|---|
| `x[0]=h` | `x0` | altitude estimate |
| `x[1]=v` | `x1` | velocity estimate |
| `x[2]=a` | `x2` | acceleration estimate |
| `P[0][0]` | `p00` | covariance (symmetric, so only 6 of 9 stored) |
| `P[0][1]` | `p01` | |
| `P[0][2]` | `p02` | |
| `P[1][1]` | `p11` | |
| `P[1][2]` | `p12` | |
| `P[2][2]` | `p22` | |
| — | `first` | 1 until the first sample initialises the filter |

**Constants (parameters, baked in as Q16.16):**

| math | RTL parameter | default |
|---|---|---|
| `dt` | `DT` | 1.0 |
| `dt²/2` | `DT2` | 0.5 |
| `R` | `R` | 9.0 |
| `Q` (6 unique) | `Q00,Q01,Q02,Q11,Q12,Q22` | constant‑accel shape × 0.01 |
| `P₀` diagonal | `P0H,P0V,P0A` | 100.0 each |

**Per‑sample scratch values (recomputed each `kf_step`):**

| math | RTL signal |
|---|---|
| `y` (input sample) | `y` |
| `x⁻` (predicted state) | `nx0,nx1,nx2` |
| `A·P` (intermediate) | `ap00,ap01,ap02,ap11,ap12,ap22` |
| `P⁻` (predicted covariance) | `pm00,pm01,pm02,pm11,pm12,pm22` |
| `e` (innovation) | `e_in` |
| `S` (innovation covariance) | `s_in` |
| `K` (Kalman gain) | `k0,k1,k2` |
| `x⁺` (corrected state) | `ux0,ux1,ux2` |
| `P⁺` (corrected covariance) | `np00,np01,np02,np11,np12,np22` |

---

## 7. One `kf_step`, walked through the RTL

When the CPU offloads a `kf_step`, the coprocessor latches the raw sample and runs the math
below (all in the clocked `always` block). The first sample is special.

**First sample — auto‑initialise** (`if (first)`): there's nothing to predict from yet, so
we seed the state with the measurement and a large uncertainty, and return the sample
unchanged:
```verilog
x0 <= y; x1 <= 0; x2 <= 0;                 // x = [y, 0, 0]
p00 <= P0H; ... p22 <= P0A;                // P = P0 (large diagonal)
first <= 0;  data_q <= y;                   // output = y
```
This is exactly your "initial state vector `[alt,0,0]`".

**Every later sample — predict, then update:**

*Predict the state* `x⁻ = A x` → `nx*`:
```verilog
nx0 = x0 + fmul(DT,x1) + fmul(DT2,x2);   // h + v·dt + a·dt²/2
nx1 = x1 + fmul(DT,x2);                   // v + a·dt
nx2 = x2;                                 // a
```

*Predict the covariance* `P⁻ = A P Aᵀ + Q`. This is done in two stages. First `A·P` (only
the rows we need), into `ap*`:
```verilog
ap00 = p00 + fmul(DT,p01) + fmul(DT2,p02);
ap01 = p01 + fmul(DT,p11) + fmul(DT2,p12);
ap02 = p02 + fmul(DT,p12) + fmul(DT2,p22);
ap11 = p11 + fmul(DT,p12);
ap12 = p12 + fmul(DT,p22);
ap22 = p22;
```
Then `(A·P)·Aᵀ + Q`, into the upper triangle of `P⁻` (`pm*`). Because `Aᵀ`'s columns are
`A`'s rows, multiplying by `Aᵀ` is the same pattern of "add dt·(next) and dt²/2·(next)":
```verilog
pm00 = ap00 + fmul(DT,ap01) + fmul(DT2,ap02) + Q00;
pm01 = ap01 + fmul(DT,ap02)                  + Q01;
pm02 = ap02                                  + Q02;
pm11 = ap11 + fmul(DT,ap12)                  + Q11;
pm12 = ap12                                  + Q12;
pm22 = ap22                                  + Q22;
```
(`P` is symmetric, so computing 6 elements gives the whole 3×3.)

*Update with the measurement* (the scalar‑measurement form):
```verilog
e_in = y - nx0;            // innovation  e = y − h⁻
s_in = pm00 + R;           // S = P⁻[0][0] + R   (a single number)
k0   = fdiv(pm00, s_in);   // gain  K = P⁻[:,0] / S
k1   = fdiv(pm01, s_in);
k2   = fdiv(pm02, s_in);
ux0  = nx0 + fmul(k0, e_in);   // x⁺ = x⁻ + K·e
ux1  = nx1 + fmul(k1, e_in);
ux2  = nx2 + fmul(k2, e_in);
```
Notice the **one division per gain element** — and `pm01 = pm10`, `pm02 = pm20` by symmetry,
so `K = P⁻[:,0]/S` uses `pm00,pm01,pm02`.

*Shrink the covariance* `P⁺ = (I − K C) P⁻`. With `C = [1 0 0]`, this reduces to the simple
rule `P⁺[i][j] = P⁻[i][j] − K[i]·P⁻[0][j]`, and `P⁻[0][j]` is exactly `pm00,pm01,pm02`:
```verilog
np00 = pm00 - fmul(k0, pm00);
np01 = pm01 - fmul(k0, pm01);
np02 = pm02 - fmul(k0, pm02);
np11 = pm11 - fmul(k1, pm01);
np12 = pm12 - fmul(k1, pm02);
np22 = pm22 - fmul(k2, pm02);
```

*Commit the new state and output:*
```verilog
x0<=ux0; x1<=ux1; x2<=ux2;                 // new estimate (kept for next call)
p00<=np00; ... p22<=np22;                  // new covariance (kept for next call)
data_q <= ux0;                             // denoised altitude returned to the CPU
```

That's the entire filter: ~25 multiplies, ~20 add/subs, **3 divides** (one reciprocal `1/S`
reused), over 9 stored state numbers.

---

## 8. How the CPU talks to it (one instruction)

The coprocessor exposes a single custom RISC‑V instruction over the eXtension Interface
(XIF):

```
kf_step  rd, rs1     →   .insn r 0x0B, 0x0, 0x00, rd, rs1, zero
                         rs1 = raw altitude (Q16.16) ,  rd = denoised altitude (Q16.16)
```

- **Decode:** `is_op = ((issue_req_instr_i & 0xFE00707F) == 0x0000000B)` — recognises this
  one opcode/funct combination.
- **Operands/result:** the raw sample arrives in `issue_req_rs_i[31:0]` (`rs1`); the result
  goes back in `data_q` → `result_data_o` (`rd`).
- **Persistent state:** `x*`/`p*` are *not* cleared between instructions, so the CPU only
  ever sends one number and gets one number back — the filter's memory lives in the
  coprocessor.
- **Handshake (`busy`/`done`):** standard XIF flow — the core *issues* the instruction
  (accepted when `issue_ready_o & issue_resp_accept_o`), later *commits* it, and the
  coprocessor raises `result_valid_o` with the answer. `busy` means "one instruction in
  flight"; `done` means "result ready." The CPU instruction simply stalls until the result
  is ready, so from software it looks like a normal instruction that returns a value.

So the software loop is just:
```c
denoised = kf_step(raw_sample);   // one custom instruction per altimeter reading
```

---

## 9. How we know it's correct

[`tb_kf_copro.sv`](tb_kf_copro.sv) builds a smooth altitude profile plus Gaussian noise and,
for each sample, drives `kf_step` over the XIF and compares the result against:

- **the noisy input** — to show the filter **reduces noise** (RMS error drops), and
- **a floating‑point golden Kalman filter** with the *same* parameters — to show the
  fixed‑point hardware **computes the right math**.

Measured result:
```
RMS error raw (noisy)      = 3.0435
RMS error kf  (hardware)   = 2.0428     ← ~33% less noise
RMS error kf  (golden flt) = 2.0428
max |hardware − golden|    = 0.00064    ← fixed-point matches float to <1e-3
PASS
```

---

## 10. Knobs you can turn

| want | change |
|---|---|
| more smoothing (quieter, slower to react) | smaller `Q` (e.g. scale `Q00..Q22` down) |
| faster reaction (less smoothing) | larger `Q` |
| match your sensor's noise | set `R = (noise σ)²` |
| match your sample rate | set `DT = dt`, `DT2 = dt²/2` |
| finer resolution | use more fractional bits (e.g. Q8.24) in `fmul`/`fdiv` and the params |
| trust first reading more/less | change `P0H/P0V/P0A` (smaller = trust the init more) |

That's the whole design: a textbook linear Kalman filter, specialised to a 3‑state
constant‑acceleration model with a scalar altitude measurement, implemented in Q16.16 fixed
point as a single‑instruction coprocessor whose internal registers *are* the filter's state.

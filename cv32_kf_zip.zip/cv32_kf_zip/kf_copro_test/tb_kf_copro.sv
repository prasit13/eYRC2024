// =====================================================================================
// tb_kf_copro -- functional test of the single-opcode Kalman-filter coprocessor.
//
// Generates a smooth "true" altitude profile + Gaussian measurement noise, then for each
// sample drives kf_copro over the XIF issue->commit->result handshake (one kf_step per
// sample) and compares against:
//   (a) the noisy input  -> shows the filter REDUCES noise (RMS down), and
//   (b) a floating-point golden Kalman filter with identical parameters -> shows the
//       fixed-point hardware TRACKS the reference math.
//
// Run:
//   iverilog -g2012 -o build/kf.vvp -s tb_kf_copro kf_copro.v tb_kf_copro.sv && vvp build/kf.vvp
// =====================================================================================
`timescale 1ns/1ps
module tb_kf_copro;
  localparam int  N  = 300;
  localparam real PI = 3.14159265358979;

  // model parameters (must match kf_copro defaults)
  localparam real DT=1.0, DT2=0.5, R=9.0;
  localparam real Q00r=0.0025, Q01r=0.005, Q02r=0.005, Q11r=0.01, Q12r=0.01, Q22r=0.01;
  localparam real P0=100.0;
  localparam real NOISE_STD=3.0;

  reg clk=0, rst_ni=0;
  always #5 clk=~clk;

  // ---- flattened XIF signals ----
  reg         issue_valid;
  reg  [31:0] issue_instr;
  reg  [3:0]  issue_id;
  reg  [63:0] issue_rs;
  reg  [1:0]  issue_rs_valid;
  reg         commit_valid, commit_kill;
  reg  [3:0]  commit_id;
  reg         result_ready;
  wire        issue_ready, issue_accept, result_valid;
  wire [31:0] result_data;
  wire [3:0]  result_id;
  wire [4:0]  result_rd;

  kf_copro dut (
    .clk_i(clk), .rst_ni(rst_ni),
    .compressed_valid_i(1'b0), .compressed_ready_o(), .compressed_resp_instr_o(), .compressed_resp_accept_o(),
    .issue_valid_i(issue_valid), .issue_ready_o(issue_ready), .issue_req_instr_i(issue_instr),
    .issue_req_mode_i(2'b0), .issue_req_id_i(issue_id), .issue_req_rs_i(issue_rs),
    .issue_req_rs_valid_i(issue_rs_valid), .issue_resp_accept_o(issue_accept),
    .issue_resp_writeback_o(), .issue_resp_dualwrite_o(), .issue_resp_dualread_o(),
    .issue_resp_loadstore_o(), .issue_resp_ecswrite_o(), .issue_resp_exc_o(),
    .commit_valid_i(commit_valid), .commit_kill_i(commit_kill), .commit_id_i(commit_id),
    .mem_valid_o(), .mem_ready_i(1'b0), .mem_req_id_o(), .mem_req_mode_o(), .mem_req_we_o(),
    .mem_req_size_o(), .mem_req_be_o(), .mem_req_attr_o(), .mem_req_wdata_o(), .mem_req_last_o(),
    .mem_req_spec_o(), .mem_req_addr_o(), .mem_resp_exc_i(1'b0), .mem_resp_exccode_i(6'b0), .mem_resp_dbg_i(1'b0),
    .mem_result_valid_i(1'b0), .mem_result_rdata_i(32'b0), .mem_result_err_i(1'b0), .mem_result_dbg_i(1'b0),
    .result_valid_o(result_valid), .result_ready_i(result_ready), .result_id_o(result_id),
    .result_data_o(result_data), .result_rd_o(result_rd), .result_we_o(),
    .result_ecsdata_o(), .result_ecswe_o(), .result_exc_o(), .result_exccode_o(), .result_err_o(), .result_dbg_o()
  );

  // ---- fixed-point conversions (Q16.16) ----
  function automatic [31:0] to_fix(input real r); to_fix = $rtoi(r*65536.0); endfunction
  function automatic real   to_real(input [31:0] q); to_real = $itor($signed(q))/65536.0; endfunction

  // ---- crude Gaussian noise: sum of 12 uniforms - 6 ~ N(0,1) ----
  function automatic real gauss(input real std);
    integer i; real s;
    begin s=0.0; for(i=0;i<12;i=i+1) s=s+(($urandom%100000)/100000.0); gauss=(s-6.0)*std; end
  endfunction

  // ---- drive one kf_step over XIF, return raw Q16.16 result ----
  task automatic kf_step(input [31:0] y_fix, output [31:0] out_fix);
    integer t;
    begin
      issue_instr=32'h0000000B; issue_rs={32'b0,y_fix}; issue_rs_valid=2'b01; issue_id=4'd3; issue_valid=1'b1;
      t=0; while(!(issue_ready && issue_accept) && t<100) begin @(negedge clk); t=t+1; end
      @(negedge clk); issue_valid=1'b0;
      commit_valid=1'b1; commit_kill=1'b0; commit_id=4'd3; @(negedge clk); commit_valid=1'b0;
      result_ready=1'b1;
      t=0; while(!result_valid && t<100) begin @(negedge clk); t=t+1; end
      out_fix=result_data;
      @(negedge clk); result_ready=1'b0; @(negedge clk);
    end
  endtask

  // ---- floating-point golden Kalman filter state ----
  real gx0,gx1,gx2, gp00,gp01,gp02,gp11,gp12,gp22;
  real gnx0,gnx1,gnx2, gap00,gap01,gap02,gap11,gap12,gap22, gpm00,gpm01,gpm02,gpm11,gpm12,gpm22;
  real ge,gs,gk0,gk1,gk2;

  task automatic golden_step(input real y, input int k, output real est);
    begin
      if (k==0) begin
        gx0=y; gx1=0; gx2=0;
        gp00=P0; gp01=0; gp02=0; gp11=P0; gp12=0; gp22=P0;
        est=y;
      end else begin
        gnx0=gx0+DT*gx1+DT2*gx2; gnx1=gx1+DT*gx2; gnx2=gx2;
        gap00=gp00+DT*gp01+DT2*gp02; gap01=gp01+DT*gp11+DT2*gp12; gap02=gp02+DT*gp12+DT2*gp22;
        gap11=gp11+DT*gp12;          gap12=gp12+DT*gp22;          gap22=gp22;
        gpm00=gap00+DT*gap01+DT2*gap02+Q00r; gpm01=gap01+DT*gap02+Q01r; gpm02=gap02+Q02r;
        gpm11=gap11+DT*gap12+Q11r;           gpm12=gap12+Q12r;          gpm22=gap22+Q22r;
        ge=y-gnx0; gs=gpm00+R; gk0=gpm00/gs; gk1=gpm01/gs; gk2=gpm02/gs;
        gx0=gnx0+gk0*ge; gx1=gnx1+gk1*ge; gx2=gnx2+gk2*ge;
        gp00=gpm00-gk0*gpm00; gp01=gpm01-gk0*gpm01; gp02=gpm02-gk0*gpm02;
        gp11=gpm11-gk1*gpm01; gp12=gpm12-gk1*gpm02; gp22=gpm22-gk2*gpm02;
        est=gx0;
      end
    end
  endtask

  integer k;
  real truth, noisy, kf_out, gold_out;
  real raw_sq, kf_sq, gold_sq, maxdiff, d;
  reg [31:0] yfix, ofix;

  initial begin
    issue_valid=0; issue_instr=0; issue_id=0; issue_rs=0; issue_rs_valid=0;
    commit_valid=0; commit_kill=0; commit_id=0; result_ready=0;
    rst_ni=0; repeat(6) @(negedge clk); rst_ni=1; repeat(2) @(negedge clk);

    raw_sq=0.0; kf_sq=0.0; gold_sq=0.0; maxdiff=0.0;
    $display(" k     truth     noisy   kf(hw)  golden");
    for (k=0; k<N; k=k+1) begin
      truth = 100.0 + 40.0*$sin(2.0*PI*k/150.0);     // smooth altitude profile
      noisy = truth + gauss(NOISE_STD);              // + measurement noise

      yfix = to_fix(noisy);
      kf_step(yfix, ofix);                            // <-- hardware coprocessor
      kf_out = to_real(ofix);

      golden_step(noisy, k, gold_out);                // <-- float reference

      raw_sq  = raw_sq  + (noisy   -truth)*(noisy   -truth);
      kf_sq   = kf_sq   + (kf_out  -truth)*(kf_out  -truth);
      gold_sq = gold_sq + (gold_out-truth)*(gold_out-truth);
      d = kf_out-gold_out; if (d<0.0) d=-d; if (d>maxdiff) maxdiff=d;

      if (k<8 || k%50==0)
        $display("%3d  %8.3f  %8.3f  %7.3f  %7.3f", k, truth, noisy, kf_out, gold_out);
    end

    $display("\n================ RESULTS (N=%0d) ================", N);
    $display(" RMS error  raw (noisy)      = %8.4f", $sqrt(raw_sq /N));
    $display(" RMS error  kf  (hardware)   = %8.4f", $sqrt(kf_sq  /N));
    $display(" RMS error  kf  (golden flt) = %8.4f", $sqrt(gold_sq/N));
    $display(" max |hardware - golden|     = %8.5f  (fixed-point quantisation)", maxdiff);
    if ($sqrt(kf_sq/N) < $sqrt(raw_sq/N) && maxdiff < 1.0) begin
      $display(" PASS: filter denoises (RMS down %0.1f%%) and tracks the golden model",
               100.0*(1.0-$sqrt(kf_sq/N)/$sqrt(raw_sq/N)));
    end else begin
      $display(" FAIL: denoise=%b  track=%b", $sqrt(kf_sq/N)<$sqrt(raw_sq/N), maxdiff<1.0);
    end
    $display("================================================\n");
    $finish;
  end

  initial begin #2_000_000; $display("TIMEOUT"); $finish; end
endmodule

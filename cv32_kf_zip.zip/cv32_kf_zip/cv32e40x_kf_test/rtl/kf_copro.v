// =====================================================================================
// kf_copro -- single-opcode linear Kalman-filter coprocessor (altimeter denoising).
//
// ONE custom instruction does everything:
//
//     kf_step  rd, rs1      // rs1 = raw altitude sample y_k  ->  rd = denoised altitude
//     encoding: .insn r 0x0B, 0x0, 0x00, rd, rs1, zero   (instr & 0xFE00707F == 0x0000000B)
//
// Model: constant-acceleration, state x = [h, v, a]^T (n=3), scalar measurement of h.
//   x- = A x+ ;  P- = A P+ A^T + Q ;  e = y - h- ;  S = P-[0][0] + R
//   K  = P-[:,0] / S ;  x+ = x- + K e ;  P+ = (I - K C) P- ,  C = [1 0 0]
// Scalar measurement => S is a number => the gain needs ONE division, no matrix inverse.
//
// The filter STATE (x, P) is PERSISTENT across calls -- the CPU only passes the new
// sample and reads back the estimate. The first call after reset auto-initialises to
// x = [y0, 0, 0], P = P0 and returns y0. The model constants (A via DT/DT2, Q, R, P0)
// are baked in as parameters.
//
// Arithmetic is Q16.16 signed fixed-point. The whole update is computed on an accepted
// instruction (a few cycles of latency hidden behind the XIF result handshake). The
// flattened XIF port list matches xif_copro_verilog, so this is drop-in for xif_copro.sv
// and mappable to the eFPGA later (rename module to xif_copro_verilog).
//
// This file is for FUNCTIONAL TESTING of the filter (not yet optimised for the fabric).
// =====================================================================================
module kf_copro #(
  parameter XLEN = 32, parameter INPUT_BUFFER_DEPTH = 1, parameter FORWARDING = 1,
  // ---- Q16.16 model constants (defaults: dt=1 sample-unit, R=9 (noise std 3)) ----
  parameter signed [31:0] DT   = 32'sd65536,   // 1.0
  parameter signed [31:0] DT2  = 32'sd32768,   // dt^2/2 = 0.5
  parameter signed [31:0] R    = 32'sd589824,  // 9.0  (measurement noise variance)
  // process-noise Q (symmetric, constant-acceleration shape * q), defaults ~ q=0.1
  parameter signed [31:0] Q00  = 32'sd164,     // 0.0025
  parameter signed [31:0] Q01  = 32'sd328,     // 0.005
  parameter signed [31:0] Q02  = 32'sd328,     // 0.005
  parameter signed [31:0] Q11  = 32'sd655,     // 0.01
  parameter signed [31:0] Q12  = 32'sd655,     // 0.01
  parameter signed [31:0] Q22  = 32'sd655,     // 0.01
  // initial covariance P0 (diagonal, high uncertainty = 100.0)
  parameter signed [31:0] P0H  = 32'sd6553600, // 100.0
  parameter signed [31:0] P0V  = 32'sd6553600, // 100.0
  parameter signed [31:0] P0A  = 32'sd6553600  // 100.0
) (
  input  wire        clk_i,
  input  wire        rst_ni,
  // ---- compressed interface (unused) ----
  input  wire        compressed_valid_i,
  output wire        compressed_ready_o,
  output wire [31:0] compressed_resp_instr_o,
  output wire        compressed_resp_accept_o,
  // ---- issue interface ----
  input  wire        issue_valid_i,
  output wire        issue_ready_o,
  input  wire [31:0] issue_req_instr_i,
  input  wire [1:0]  issue_req_mode_i,
  input  wire [3:0]  issue_req_id_i,
  input  wire [63:0] issue_req_rs_i,
  input  wire [1:0]  issue_req_rs_valid_i,
  output wire        issue_resp_accept_o,
  output wire        issue_resp_writeback_o,
  output wire        issue_resp_dualwrite_o,
  output wire [2:0]  issue_resp_dualread_o,
  output wire        issue_resp_loadstore_o,
  output wire        issue_resp_ecswrite_o,
  output wire        issue_resp_exc_o,
  // ---- commit interface ----
  input  wire        commit_valid_i,
  input  wire        commit_kill_i,
  input  wire [3:0]  commit_id_i,
  // ---- memory request interface (unused) ----
  output wire        mem_valid_o,
  input  wire        mem_ready_i,
  output wire [3:0]  mem_req_id_o,
  output wire [1:0]  mem_req_mode_o,
  output wire        mem_req_we_o,
  output wire [2:0]  mem_req_size_o,
  output wire [3:0]  mem_req_be_o,
  output wire [1:0]  mem_req_attr_o,
  output wire [31:0] mem_req_wdata_o,
  output wire        mem_req_last_o,
  output wire        mem_req_spec_o,
  output wire [31:0] mem_req_addr_o,
  input  wire        mem_resp_exc_i,
  input  wire [5:0]  mem_resp_exccode_i,
  input  wire        mem_resp_dbg_i,
  // ---- memory result interface (unused) ----
  input  wire        mem_result_valid_i,
  input  wire [31:0] mem_result_rdata_i,
  input  wire        mem_result_err_i,
  input  wire        mem_result_dbg_i,
  // ---- result interface ----
  output wire        result_valid_o,
  input  wire        result_ready_i,
  output wire [3:0]  result_id_o,
  output wire [31:0] result_data_o,
  output wire [4:0]  result_rd_o,
  output wire        result_we_o,
  output wire [5:0]  result_ecsdata_o,
  output wire [2:0]  result_ecswe_o,
  output wire        result_exc_o,
  output wire [5:0]  result_exccode_o,
  output wire        result_err_o,
  output wire        result_dbg_o
);
  localparam [31:0] KF_INSTR = 32'h0000000B;  // custom-0, funct3=0, funct7=0
  localparam [31:0] KF_MASK  = 32'hFE00707F;

  // ---- Q16.16 helpers ----
  function automatic signed [31:0] fmul(input signed [31:0] a, input signed [31:0] b);
    reg signed [63:0] aa, bb, p;
    begin aa = a; bb = b; p = aa * bb; fmul = p >>> 16; end   // (a*b) >> 16
  endfunction
  function automatic signed [31:0] fdiv(input signed [31:0] num, input signed [31:0] den);
    reg signed [63:0] n, d;
    begin n = num; n = n <<< 16; d = den; fdiv = n / d; end   // (num<<16)/den
  endfunction

  // ---- persistent filter state ----
  reg signed [31:0] x0, x1, x2;                       // [h, v, a]
  reg signed [31:0] p00, p01, p02, p11, p12, p22;     // P (symmetric, 6 unique)
  reg        first;                                   // 1 until the first sample initialises

  // ---- one outstanding instruction (issue->commit->result), like xif_copro_verilog ----
  reg        busy, done;
  reg signed [31:0] data_q;     // result (denoised altitude)
  reg [3:0]  id_q;
  reg [4:0]  rd_q;

  wire is_op = ((issue_req_instr_i & KF_MASK) == KF_INSTR);

  // ---- combinational update temporaries ----
  reg signed [31:0] y;
  reg signed [31:0] nx0, nx1, nx2;
  reg signed [31:0] ap00, ap01, ap02, ap11, ap12, ap22;
  reg signed [31:0] pm00, pm01, pm02, pm11, pm12, pm22;
  reg signed [31:0] e_in, s_in, k0, k1, k2;
  reg signed [31:0] ux0, ux1, ux2;
  reg signed [31:0] np00, np01, np02, np11, np12, np22;

  // ---- issue response (combinational predecode) ----
  assign issue_ready_o          = ~busy & (is_op ? issue_req_rs_valid_i[0] : 1'b1);
  assign issue_resp_accept_o    = is_op;
  assign issue_resp_writeback_o = is_op;
  assign issue_resp_dualwrite_o = 1'b0;
  assign issue_resp_dualread_o  = 3'b0;
  assign issue_resp_loadstore_o = 1'b0;
  assign issue_resp_ecswrite_o  = 1'b0;
  assign issue_resp_exc_o       = 1'b0;

  // ---- compressed / memory / dead outputs (tied off) ----
  assign compressed_ready_o       = compressed_valid_i;
  assign compressed_resp_instr_o  = 32'b0;
  assign compressed_resp_accept_o = 1'b0;
  assign mem_valid_o    = 1'b0;  assign mem_req_id_o   = 4'b0;  assign mem_req_mode_o = 2'b0;
  assign mem_req_we_o   = 1'b0;  assign mem_req_size_o = 3'b0;  assign mem_req_be_o   = 4'b0;
  assign mem_req_attr_o = 2'b0;  assign mem_req_wdata_o= 32'b0; assign mem_req_last_o = 1'b0;
  assign mem_req_spec_o = 1'b0;  assign mem_req_addr_o = 32'b0;

  // ---- result ----
  assign result_valid_o   = done;
  assign result_id_o      = id_q;
  assign result_data_o    = data_q;
  assign result_rd_o      = rd_q;
  assign result_we_o      = 1'b1;
  assign result_ecsdata_o = 6'b0;  assign result_ecswe_o = 3'b0;
  assign result_exc_o     = 1'b0;  assign result_exccode_o = 6'b0;
  assign result_err_o     = 1'b0;  assign result_dbg_o = 1'b0;

  wire accept_hs  = issue_valid_i & issue_ready_o & is_op;
  wire commit_hit = commit_valid_i & (commit_id_i == id_q);

  always @(posedge clk_i) begin
    if (~rst_ni) begin
      busy <= 1'b0; done <= 1'b0; first <= 1'b1;
      x0 <= 0; x1 <= 0; x2 <= 0;
      p00 <= 0; p01 <= 0; p02 <= 0; p11 <= 0; p12 <= 0; p22 <= 0;
      data_q <= 0; id_q <= 0; rd_q <= 0;
    end else begin
      // 1) result consumed -> free the slot
      if (done & result_ready_i) begin done <= 1'b0; busy <= 1'b0; end

      // 2) accept a new kf_step (slot free)
      if (accept_hs & ~busy) begin
        busy <= 1'b1;
        id_q <= issue_req_id_i;
        rd_q <= issue_req_instr_i[11:7];
        y     = issue_req_rs_i[31:0];

        if (first) begin
          // ---- auto-initialise: x = [y,0,0], P = P0 ; return y ----
          x0 <= y;  x1 <= 0;  x2 <= 0;
          p00 <= P0H; p01 <= 0; p02 <= 0; p11 <= P0V; p12 <= 0; p22 <= P0A;
          first <= 1'b0;
          data_q <= y;
        end else begin
          // ---- PREDICT: x- = A x+ ----
          nx0 = x0 + fmul(DT,x1) + fmul(DT2,x2);
          nx1 = x1 + fmul(DT,x2);
          nx2 = x2;
          // ---- PREDICT: P- = A P A^T + Q  (upper triangle; A=[[1,DT,DT2],[0,1,DT],[0,0,1]]) ----
          ap00 = p00 + fmul(DT,p01) + fmul(DT2,p02);
          ap01 = p01 + fmul(DT,p11) + fmul(DT2,p12);
          ap02 = p02 + fmul(DT,p12) + fmul(DT2,p22);
          ap11 = p11 + fmul(DT,p12);
          ap12 = p12 + fmul(DT,p22);
          ap22 = p22;
          pm00 = ap00 + fmul(DT,ap01) + fmul(DT2,ap02) + Q00;
          pm01 = ap01 + fmul(DT,ap02)                  + Q01;
          pm02 = ap02                                  + Q02;
          pm11 = ap11 + fmul(DT,ap12)                  + Q11;
          pm12 = ap12                                  + Q12;
          pm22 = ap22                                  + Q22;
          // ---- UPDATE: scalar measurement, C = [1 0 0] ----
          e_in = y - nx0;            // innovation
          s_in = pm00 + R;           // innovation covariance (scalar)
          k0   = fdiv(pm00, s_in);   // gain K = P-[:,0] / S
          k1   = fdiv(pm01, s_in);
          k2   = fdiv(pm02, s_in);
          ux0  = nx0 + fmul(k0, e_in);
          ux1  = nx1 + fmul(k1, e_in);
          ux2  = nx2 + fmul(k2, e_in);
          // ---- UPDATE: P+ = (I - K C) P-  =>  P+[i][j] = P-[i][j] - K[i]*P-[0][j] ----
          np00 = pm00 - fmul(k0, pm00);
          np01 = pm01 - fmul(k0, pm01);
          np02 = pm02 - fmul(k0, pm02);
          np11 = pm11 - fmul(k1, pm01);
          np12 = pm12 - fmul(k1, pm02);
          np22 = pm22 - fmul(k2, pm02);
          // commit state
          x0 <= ux0; x1 <= ux1; x2 <= ux2;
          p00 <= np00; p01 <= np01; p02 <= np02; p11 <= np11; p12 <= np12; p22 <= np22;
          data_q <= ux0;             // denoised altitude
        end

        // commit may arrive same cycle as issue
        if (commit_valid_i & (commit_id_i == issue_req_id_i)) begin
          if (commit_kill_i) busy <= 1'b0;
          else               done <= 1'b1;
        end
      // 3) commit for an already-held instruction
      end else if (busy & ~done & commit_hit) begin
        if (commit_kill_i) busy <= 1'b0;
        else               done <= 1'b1;
      end
    end
  end
endmodule

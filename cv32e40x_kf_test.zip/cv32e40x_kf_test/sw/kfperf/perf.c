// =====================================================================================
// perf.c -- cycle-count comparison: PURE-SOFTWARE Kalman filter vs the COPROCESSOR.
//
// Runs the SAME constant-acceleration KF over the noisy trace two ways and times each with
// the mcycle CSR:
//   (1) pure software  -- predict+update in C (rv32im hardware mul + iterative div)
//   (2) coprocessor    -- one kf_step custom instruction per sample
// Prints cycles/sample for each and the speed-up. This is the software baseline for the
// eFPGA-vs-software study (the eFPGA-mapped coprocessor latency comes from the fabric flow).
// =====================================================================================
#include <stdint.h>
#include "trace.h"     // #define N ; static const int NOISY[N], TRUTH[N]  (Q16.16)

#define MM_PRINT  (*(volatile uint32_t *)0x00800000u)
#define MM_STATUS (*(volatile uint32_t *)0x008000c0u)
#define MM_EXIT   (*(volatile uint32_t *)0x008000c4u)

static void putc_(char c){ MM_PRINT=(uint32_t)c; }
static void puts_(const char*s){ while(*s) putc_(*s++); }
static void putu(unsigned v){ char b[12]; int i=0; if(!v){putc_('0');return;} while(v){b[i++]='0'+v%10;v/=10;} while(i)putc_(b[--i]); }

static inline uint32_t rdcycle(void){ uint32_t c; asm volatile("csrr %0, mcycle":"=r"(c)); return c; }

// ---- the coprocessor instruction ----
static inline int kf_step(int y){ int r; asm volatile(".insn r 0x0B,0x0,0x00,%0,%1,zero":"=r"(r):"r"(y)); return r; }

// ---- pure-software KF (Q16.16), same model + paper constants as kf_copro.v ----
static inline int fmul(int a,int b){ return (int)(((long long)a*(long long)b)>>16); }
static inline int fdiv(int n,int d){ long long t=(long long)n<<16; return (int)(t/d); }

#define DT 1311
#define DT2 13
#define R  524288
#define Q00 3277
#define Q11 36045
#define Q22 66
#define P0  13107200

static int sx0,sx1,sx2,sp00,sp01,sp02,sp11,sp12,sp22, sfirst;
static void sw_reset(void){ sfirst=1; }
static int kf_sw_step(int y){
  if(sfirst){ sfirst=0; sx0=y;sx1=0;sx2=0; sp00=P0;sp01=0;sp02=0;sp11=P0;sp12=0;sp22=P0; return y; }
  int nx0=sx0+fmul(DT,sx1)+fmul(DT2,sx2), nx1=sx1+fmul(DT,sx2), nx2=sx2;
  int ap00=sp00+fmul(DT,sp01)+fmul(DT2,sp02);
  int ap01=sp01+fmul(DT,sp11)+fmul(DT2,sp12);
  int ap02=sp02+fmul(DT,sp12)+fmul(DT2,sp22);
  int ap11=sp11+fmul(DT,sp12), ap12=sp12+fmul(DT,sp22), ap22=sp22;
  int pm00=ap00+fmul(DT,ap01)+fmul(DT2,ap02)+Q00;
  int pm01=ap01+fmul(DT,ap02)+0;
  int pm02=ap02+0;
  int pm11=ap11+fmul(DT,ap12)+Q11;
  int pm12=ap12+0;
  int pm22=ap22+Q22;
  int e=y-nx0, s=pm00+R;
  int k0=fdiv(pm00,s), k1=fdiv(pm01,s), k2=fdiv(pm02,s);
  sx0=nx0+fmul(k0,e); sx1=nx1+fmul(k1,e); sx2=nx2+fmul(k2,e);
  sp00=pm00-fmul(k0,pm00); sp01=pm01-fmul(k0,pm01); sp02=pm02-fmul(k0,pm02);
  sp11=pm11-fmul(k1,pm01); sp12=pm12-fmul(k1,pm02); sp22=pm22-fmul(k2,pm02);
  return sx0;
}

int main(void){
  volatile int sink=0;
  uint32_t c0,c1, sw_cyc, hw_cyc;
  int k;

  asm volatile("csrw mcountinhibit, zero");   // CV32E40X resets this to inhibit; enable mcycle

  puts_("KF performance: pure software vs coprocessor (cycles via mcycle)\n");

  // ---- pure software ----
  sw_reset();
  c0=rdcycle();
  for(k=0;k<N;k++) sink ^= kf_sw_step(NOISY[k]);
  c1=rdcycle();
  sw_cyc = c1-c0;

  // ---- coprocessor ----
  c0=rdcycle();
  for(k=0;k<N;k++) sink ^= kf_step(NOISY[k]);
  c1=rdcycle();
  hw_cyc = c1-c0;

  puts_("samples         : "); putu(N); putc_('\n');
  puts_("software  total : "); putu(sw_cyc); puts_(" cyc  ("); putu(sw_cyc/N); puts_(" /sample)\n");
  puts_("coproc    total : "); putu(hw_cyc); puts_(" cyc  ("); putu(hw_cyc/N); puts_(" /sample)\n");
  if(hw_cyc){ puts_("speed-up (x100) : "); putu((sw_cyc*100u)/hw_cyc); putc_('\n'); }

  MM_STATUS=123456789u; MM_EXIT=0u;
  (void)sink;
  for(;;);
  return 0;
}

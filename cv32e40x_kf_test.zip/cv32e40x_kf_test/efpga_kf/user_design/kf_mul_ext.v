// Minimal combinational user_design: the KFMUL multiply is a HARD tile driven via EXTERNAL
// A/B/Q ports, so the fabric LUT logic does nothing here. This just yields a valid bitstream
// (KFMUL OUT_reg stays at its default 0 = combinational).
module kf_mul_ext(input wire clk, input wire [15:0] io_in, output wire [15:0] io_out, output wire [15:0] io_oeb);
  assign io_out = io_in;        // pure wire pass-through (combinational, won't fold to const)
  assign io_oeb = 16'hFFFF;
endmodule

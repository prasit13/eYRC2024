
//Warning: The primitive KFMUL_DSP was added by FABulous automatically.
(* blackbox, keep *)
module KFMUL_DSP (
    (* iopad_external_pin *)
    input A0,
    (* iopad_external_pin *)
    input A1,
    (* iopad_external_pin *)
    input A2,
    (* iopad_external_pin *)
    input A3,
    (* iopad_external_pin *)
    input A4,
    (* iopad_external_pin *)
    input A5,
    (* iopad_external_pin *)
    input A6,
    (* iopad_external_pin *)
    input A7,
    (* iopad_external_pin *)
    input A8,
    (* iopad_external_pin *)
    input A9,
    (* iopad_external_pin *)
    input A10,
    (* iopad_external_pin *)
    input A11,
    (* iopad_external_pin *)
    input A12,
    (* iopad_external_pin *)
    input A13,
    (* iopad_external_pin *)
    input A14,
    (* iopad_external_pin *)
    input A15,
    (* iopad_external_pin *)
    input A16,
    (* iopad_external_pin *)
    input A17,
    (* iopad_external_pin *)
    input A18,
    (* iopad_external_pin *)
    input A19,
    (* iopad_external_pin *)
    input A20,
    (* iopad_external_pin *)
    input A21,
    (* iopad_external_pin *)
    input A22,
    (* iopad_external_pin *)
    input A23,
    (* iopad_external_pin *)
    input A24,
    (* iopad_external_pin *)
    input A25,
    (* iopad_external_pin *)
    input A26,
    (* iopad_external_pin *)
    input A27,
    (* iopad_external_pin *)
    input A28,
    (* iopad_external_pin *)
    input A29,
    (* iopad_external_pin *)
    input A30,
    (* iopad_external_pin *)
    input A31,
    (* iopad_external_pin *)
    input B0,
    (* iopad_external_pin *)
    input B1,
    (* iopad_external_pin *)
    input B2,
    (* iopad_external_pin *)
    input B3,
    (* iopad_external_pin *)
    input B4,
    (* iopad_external_pin *)
    input B5,
    (* iopad_external_pin *)
    input B6,
    (* iopad_external_pin *)
    input B7,
    (* iopad_external_pin *)
    input B8,
    (* iopad_external_pin *)
    input B9,
    (* iopad_external_pin *)
    input B10,
    (* iopad_external_pin *)
    input B11,
    (* iopad_external_pin *)
    input B12,
    (* iopad_external_pin *)
    input B13,
    (* iopad_external_pin *)
    input B14,
    (* iopad_external_pin *)
    input B15,
    (* iopad_external_pin *)
    input B16,
    (* iopad_external_pin *)
    input B17,
    (* iopad_external_pin *)
    input B18,
    (* iopad_external_pin *)
    input B19,
    (* iopad_external_pin *)
    input B20,
    (* iopad_external_pin *)
    input B21,
    (* iopad_external_pin *)
    input B22,
    (* iopad_external_pin *)
    input B23,
    (* iopad_external_pin *)
    input B24,
    (* iopad_external_pin *)
    input B25,
    (* iopad_external_pin *)
    input B26,
    (* iopad_external_pin *)
    input B27,
    (* iopad_external_pin *)
    input B28,
    (* iopad_external_pin *)
    input B29,
    (* iopad_external_pin *)
    input B30,
    (* iopad_external_pin *)
    input B31,
    (* iopad_external_pin *)
    output Q0,
    (* iopad_external_pin *)
    output Q1,
    (* iopad_external_pin *)
    output Q2,
    (* iopad_external_pin *)
    output Q3,
    (* iopad_external_pin *)
    output Q4,
    (* iopad_external_pin *)
    output Q5,
    (* iopad_external_pin *)
    output Q6,
    (* iopad_external_pin *)
    output Q7,
    (* iopad_external_pin *)
    output Q8,
    (* iopad_external_pin *)
    output Q9,
    (* iopad_external_pin *)
    output Q10,
    (* iopad_external_pin *)
    output Q11,
    (* iopad_external_pin *)
    output Q12,
    (* iopad_external_pin *)
    output Q13,
    (* iopad_external_pin *)
    output Q14,
    (* iopad_external_pin *)
    output Q15,
    (* iopad_external_pin *)
    output Q16,
    (* iopad_external_pin *)
    output Q17,
    (* iopad_external_pin *)
    output Q18,
    (* iopad_external_pin *)
    output Q19,
    (* iopad_external_pin *)
    output Q20,
    (* iopad_external_pin *)
    output Q21,
    (* iopad_external_pin *)
    output Q22,
    (* iopad_external_pin *)
    output Q23,
    (* iopad_external_pin *)
    output Q24,
    (* iopad_external_pin *)
    output Q25,
    (* iopad_external_pin *)
    output Q26,
    (* iopad_external_pin *)
    output Q27,
    (* iopad_external_pin *)
    output Q28,
    (* iopad_external_pin *)
    output Q29,
    (* iopad_external_pin *)
    output Q30,
    (* iopad_external_pin *)
    output Q31,
    input CLK
);
    parameter OUT_reg = 0;
endmodule

// KFMUL_DSP -- WIDE combinational 32x32 Q16.16 Booth-Wallace multiply BEL.
//   A[31:0], B[31:0] in, Q=(A*B)>>>16 out -- ALL ports EXTERNAL (bypass the switch matrix,
//   exported straight to eFPGA_top), so the user_design is purely combinational (nothing for
//   synth_fabulous to fold). ConfigBits[0]=OUT_reg pipelines Q (1 stage) to protect host fmax.
(* FABulous, BelMap,
OUT_reg=0
*)
module KFMUL_DSP #(parameter NoConfigBits = 1) (
    (* FABulous, EXTERNAL *) input  A0,
    (* FABulous, EXTERNAL *) input  A1,
    (* FABulous, EXTERNAL *) input  A2,
    (* FABulous, EXTERNAL *) input  A3,
    (* FABulous, EXTERNAL *) input  A4,
    (* FABulous, EXTERNAL *) input  A5,
    (* FABulous, EXTERNAL *) input  A6,
    (* FABulous, EXTERNAL *) input  A7,
    (* FABulous, EXTERNAL *) input  A8,
    (* FABulous, EXTERNAL *) input  A9,
    (* FABulous, EXTERNAL *) input  A10,
    (* FABulous, EXTERNAL *) input  A11,
    (* FABulous, EXTERNAL *) input  A12,
    (* FABulous, EXTERNAL *) input  A13,
    (* FABulous, EXTERNAL *) input  A14,
    (* FABulous, EXTERNAL *) input  A15,
    (* FABulous, EXTERNAL *) input  A16,
    (* FABulous, EXTERNAL *) input  A17,
    (* FABulous, EXTERNAL *) input  A18,
    (* FABulous, EXTERNAL *) input  A19,
    (* FABulous, EXTERNAL *) input  A20,
    (* FABulous, EXTERNAL *) input  A21,
    (* FABulous, EXTERNAL *) input  A22,
    (* FABulous, EXTERNAL *) input  A23,
    (* FABulous, EXTERNAL *) input  A24,
    (* FABulous, EXTERNAL *) input  A25,
    (* FABulous, EXTERNAL *) input  A26,
    (* FABulous, EXTERNAL *) input  A27,
    (* FABulous, EXTERNAL *) input  A28,
    (* FABulous, EXTERNAL *) input  A29,
    (* FABulous, EXTERNAL *) input  A30,
    (* FABulous, EXTERNAL *) input  A31,
    (* FABulous, EXTERNAL *) input  B0,
    (* FABulous, EXTERNAL *) input  B1,
    (* FABulous, EXTERNAL *) input  B2,
    (* FABulous, EXTERNAL *) input  B3,
    (* FABulous, EXTERNAL *) input  B4,
    (* FABulous, EXTERNAL *) input  B5,
    (* FABulous, EXTERNAL *) input  B6,
    (* FABulous, EXTERNAL *) input  B7,
    (* FABulous, EXTERNAL *) input  B8,
    (* FABulous, EXTERNAL *) input  B9,
    (* FABulous, EXTERNAL *) input  B10,
    (* FABulous, EXTERNAL *) input  B11,
    (* FABulous, EXTERNAL *) input  B12,
    (* FABulous, EXTERNAL *) input  B13,
    (* FABulous, EXTERNAL *) input  B14,
    (* FABulous, EXTERNAL *) input  B15,
    (* FABulous, EXTERNAL *) input  B16,
    (* FABulous, EXTERNAL *) input  B17,
    (* FABulous, EXTERNAL *) input  B18,
    (* FABulous, EXTERNAL *) input  B19,
    (* FABulous, EXTERNAL *) input  B20,
    (* FABulous, EXTERNAL *) input  B21,
    (* FABulous, EXTERNAL *) input  B22,
    (* FABulous, EXTERNAL *) input  B23,
    (* FABulous, EXTERNAL *) input  B24,
    (* FABulous, EXTERNAL *) input  B25,
    (* FABulous, EXTERNAL *) input  B26,
    (* FABulous, EXTERNAL *) input  B27,
    (* FABulous, EXTERNAL *) input  B28,
    (* FABulous, EXTERNAL *) input  B29,
    (* FABulous, EXTERNAL *) input  B30,
    (* FABulous, EXTERNAL *) input  B31,
    (* FABulous, EXTERNAL *) output  Q0,
    (* FABulous, EXTERNAL *) output  Q1,
    (* FABulous, EXTERNAL *) output  Q2,
    (* FABulous, EXTERNAL *) output  Q3,
    (* FABulous, EXTERNAL *) output  Q4,
    (* FABulous, EXTERNAL *) output  Q5,
    (* FABulous, EXTERNAL *) output  Q6,
    (* FABulous, EXTERNAL *) output  Q7,
    (* FABulous, EXTERNAL *) output  Q8,
    (* FABulous, EXTERNAL *) output  Q9,
    (* FABulous, EXTERNAL *) output  Q10,
    (* FABulous, EXTERNAL *) output  Q11,
    (* FABulous, EXTERNAL *) output  Q12,
    (* FABulous, EXTERNAL *) output  Q13,
    (* FABulous, EXTERNAL *) output  Q14,
    (* FABulous, EXTERNAL *) output  Q15,
    (* FABulous, EXTERNAL *) output  Q16,
    (* FABulous, EXTERNAL *) output  Q17,
    (* FABulous, EXTERNAL *) output  Q18,
    (* FABulous, EXTERNAL *) output  Q19,
    (* FABulous, EXTERNAL *) output  Q20,
    (* FABulous, EXTERNAL *) output  Q21,
    (* FABulous, EXTERNAL *) output  Q22,
    (* FABulous, EXTERNAL *) output  Q23,
    (* FABulous, EXTERNAL *) output  Q24,
    (* FABulous, EXTERNAL *) output  Q25,
    (* FABulous, EXTERNAL *) output  Q26,
    (* FABulous, EXTERNAL *) output  Q27,
    (* FABulous, EXTERNAL *) output  Q28,
    (* FABulous, EXTERNAL *) output  Q29,
    (* FABulous, EXTERNAL *) output  Q30,
    (* FABulous, EXTERNAL *) output  Q31,
    (* FABulous, EXTERNAL, SHARED_PORT *) input UserCLK,
    (* FABulous, GLOBAL *) input [NoConfigBits-1:0] ConfigBits
);
    function [63:0] bw_mul;
        input signed [31:0] a, b;
        integer i; reg [34:0] bb; reg [2:0] sel; reg signed [63:0] a64, a264, ppb, acc;
        begin
            a64  = {{32{a[31]}}, a};
            a264 = {{31{a[31]}}, a, 1'b0};
            bb   = {b[31], b[31], b, 1'b0};
            acc  = 64'd0;
            for (i = 0; i < 17; i = i + 1) begin
                sel = bb[2*i+2 -: 3];
                case (sel)
                    3'b001, 3'b010: ppb =  a64;
                    3'b011:         ppb =  a264;
                    3'b100:         ppb = -a264;
                    3'b101, 3'b110: ppb = -a64;
                    default:        ppb = 64'd0;
                endcase
                acc = acc + (ppb <<< (2*i));
            end
            bw_mul = acc;
        end
    endfunction
    wire signed [31:0] A = {A31,A30,A29,A28,A27,A26,A25,A24,A23,A22,A21,A20,A19,A18,A17,A16,A15,A14,A13,A12,A11,A10,A9,A8,A7,A6,A5,A4,A3,A2,A1,A0};
    wire signed [31:0] B = {B31,B30,B29,B28,B27,B26,B25,B24,B23,B22,B21,B20,B19,B18,B17,B16,B15,B14,B13,B12,B11,B10,B9,B8,B7,B6,B5,B4,B3,B2,B1,B0};
    wire signed [63:0] p = bw_mul(A, B);
    wire        [31:0] Qc = p[47:16];
    reg         [31:0] Qr;
    always @(posedge UserCLK) Qr <= Qc;
    wire        [31:0] Qo = ConfigBits[0] ? Qr : Qc;
    assign {Q31,Q30,Q29,Q28,Q27,Q26,Q25,Q24,Q23,Q22,Q21,Q20,Q19,Q18,Q17,Q16,Q15,Q14,Q13,Q12,Q11,Q10,Q9,Q8,Q7,Q6,Q5,Q4,Q3,Q2,Q1,Q0} = Qo;
endmodule
